let n = 10;
{
    let n = 2;
    console.log(n);
}
console.log(n);

//const 
const pi=3.14;

// Arrow function
const add = (a, b) => a + b;

const fetchdata=async()=>{
    const data=await fetch('https://api.example.com/data');
    return data.json();
};
console.log(fetchdata)

//Destructing Object 

const obj={name:"Rupali" , age:22};
const {name,age}=obj;
console.log(name,age);

//Sepread Operator

const n1=[1,2,3];
const n2=[...n1,4,5];
console.log(n2);

var a = [1,2,3,-1];
console.log(Math.min(a)); //NaN
console.log(Math.min(...a));

var  a=["a","b","c"];
for(const a1 of a)
{
    console.log(a1);
    
}

//Map 

const map=new Map();
map.set("a",1);
map.set("b",2);
console.log(map);
//using array
let m = new Map([
    ["k1", 11],
    ["k2", 12],
    ["k3", 13]
]);
console.log(m);
//set
const set = new Set([1, 2, 3, 3]);
console.log(set);

//Promise
const fetch = () => {
    return new Promise((resolve, reject) => {
        setTimeout(() => 
            resolve("Data fetched"), 2000);
    });
};

fetch().then(data => 
    console.log(data));

function myData()
{
    return new Promise((resolve,reject)=>{
        setTimeout(() => {
            const data={name:"Rupali"};
            resolve(data);
        }, 2000);
    });
}
myData()
    .then((data)=>{
        console.log("Data : ",data);
    })
    .catch((error)=>{
        console.error("Error : ",error);
        
    });