// let key word and const  with templet literal
let str = "Hello Good Morning";
const name = "Rupali";
console.log(`${str} Welcome ${name}`);

//Arrow Function 
const add = (a, b) => a + b;
console.log(add(5, 3));       
console.log(`Sum is  : ${add(10, 20)}`);

//Default Parameter

const sub = (a = 20, b = 0) => a - b;
console.log(sub(10));
console.log(`Subtracion id ${sub(70, 40)}`);

//Spread Operator

const arr = [1, 2, 3, 4];
const arr1 = [...arr, 5, 6];
console.log(`Spread operator : ${arr1}`);

//Rest operator
const sum = (...arr) => arr.reduce((acumlator, currentvalue) => acumlator + currentvalue, 0);
console.log(`Rest Operator : ${sum(1, 2, 3, 4, 5, 6)}`);

//Destructing 
const person = { fname: "Rupali", lname: "Zalavadiya", age: 22 };
const { fname, age } = person;
console.log(`Destrucure : \n Name :  ${fname} Age : ${age}`);

const a1 = [10, 20, 40, 50];
const [first, second, ...rest] = a1;
console.log(`First: ${first}, Second: ${second}, Rest: ${rest}`);

class Person {
    constructor(nm, age1) {
        this.nm = nm;
        this.age1 = age1;
    }
    ShowDetail() {
        console.log(`Your Name is ${this.nm} And Your Age is : ${this.age1}`);
    }
    ShowData() {
        console.log("Demo of Async await using class method and promise....");
    }
}
const data = new Person("Ruchita", 21);
data.ShowDetail();

//Map & Set 
const stud = new Map();
stud.set("Roll No", 1);
stud.set("Class", "A");
console.log("Map Detail : ", stud);
stud.clear();
console.log("Map Clear :", stud);

//Set  with for of loop
const n1 = new Set([1, 2, 3, 4, 5]);
console.log("Print Set Data Using For of Loop : ")
for (const no of n1) {
    console.log(no);
}
//Promise : 

const fetchdata = new Promise((resolve, reject) => {
    setTimeout(() => {
        resolve("Data Fatched .... :");
        data.ShowDetail();
    }, 1000);
});
fetchdata.then((data) => console.log(data))
    .catch((error) => console.error())
    .finally(() => console.log("Promise Task Completed ...."));

//async and await 
function fetchData() {
    return new Promise((resolve, reject) => {
        setTimeout(() => {
            resolve("Data Fatched .... :");
            data.ShowData();
        }, 3000);
    });
}
async function getData() {
    console.log("Fetching Data Using Async and Await......");
    const data = await fetchData();
    console.log(data)
}
getData();

//Call back Function

function Multiplication(a,b,callback)
{
    const result=a*b;
    callback(result);
}
function ShowResult(result){
    console.log(`Multiplication is  : ${result}`);
}
Multiplication(12,10,ShowResult);

