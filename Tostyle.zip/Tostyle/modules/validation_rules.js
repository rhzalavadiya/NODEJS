const { email } = require("../language/arbic");
const { signUp, verifyOtp, editProfile, forgotPassword, changePassword, AddPost } = require("./V1/user/Models/userModel");

const checkValidationRules={
    login:{
        email:'required|email',
        password:'required|min:4',
    },
    signUp:{
        user_name:"required",
        email:"required|email",
        phone_no:"required|string|min:10|regex:/^[0-9]+$/",
        password:"required|min:4",

    },
    verifyOtp:{
        verify_with:"required|email", 
        otp:"required",
    },
    editProfile:{
        dob:"required", 
        full_name:"required",
    },
    forgotPassword:{
        email:"required|email",
    },
    changePassword:{
        OldPassword:"required|min:4",
        NewPassword:"required|min:4",
    },
    AddPost:{
        user_id:"required", 
        description:"required", 
        expire_time:"required", 
        post_type:"required", 
        category_id:"required",
    },
}
module.exports = checkValidationRules