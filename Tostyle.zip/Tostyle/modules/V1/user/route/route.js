const User=require("../Controllers/User");
const customeRoute=(app)=>{
    app.post("/v1/user/signup",User.signUp);
    app.post("/v1/user/addpost",User.AddPost);
    app.post("/v1/user/verifyOtp",User.verifyOtp);
    app.post("/v1/user/editProfile",User.editProfile);
    app.post("/v1/user/addcomment",User.addComment);
    app.post("/v1/user/addrate",User.addRate);
    app.post("/v1/user/login",User.login);
    app.post("/v1/user/forgotpassword",User.forgotPassword);
    app.post("/v1/user/setpassword",User.setPassword);
    app.post("/v1/user/changepassword",User.changePassword);
    app.get("/v1/user/trendingpost",User.trendingPost);
    app.get("/v1/user/postcompare",User.PostCompare);
    app.get("/v1/user/savepost",User.savePost);
    app.get("/v1/user/filterpost",User.filterPost);
    app.get("/v1/user/category",User.category);
    app.get("/v1/user/displayPost/:post_type?",User.displayPost);
    app.get("/v1/user/userprofile/",User.UserProfile);
    app.post("/v1/user/subpostrate/",User.subPostRate);
    app.post("/v1/user/addcategory/",User.addCategory);
    app.post("/v1/user/logout/",User.Logout);

}
module.exports=customeRoute;