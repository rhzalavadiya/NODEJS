const con = require("../../../../config/database");
const responseCode = require("../../../../utillities/responseErrorCode");
const common = require("../../../../utillities/common");
const constant = require("../../../../config/constant");
const md5 = require("md5");
const { log, error, Console } = require("console");
const { verify } = require("crypto");
const e = require("express");
class UserModel {
    constructor() { }
    // signup
    async signUp(requestData, callback) {
        try {
            const {
                user_name, email, phone_no, password,
                device_type, device_token, os_version, app_version
            } = requestData;

            if (!user_name || !email || !password || !phone_no) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Missing required fields"
                });
            }

            console.log("Signup Request For User:", user_name);

            const userData = {
                user_name,
                email,
                phone_no,
                password: md5(password)
            };
            // insert in user data
            const insertQuery = "INSERT INTO tbl_user SET ?";
            console.log(insertQuery)
            const [userResult] = await con.query(insertQuery, userData);
            // console.log(userResult);

            if (!userResult.insertId) {
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to insert user data."
                }, null);
            }

            console.log("User Registered With ID:", userResult.insertId);
            const user_id = userResult.insertId;

            const deviceData = {
                user_id,
                device_type,
                device_token: "Device" + common.generateToken(4),
                os_version,
                app_version
            };
            // insert device data
            const insertDevice = "INSERT INTO tbl_device SET ?";
            await con.query(insertDevice, deviceData);

            console.log("Device Data Inserted For User ID:", user_id);
            // sending otp
            await this.sendOtp(user_id, requestData);
            return callback({
                code: responseCode.SUCCESS,
                message: "OTP Sent Successfully. Please verify to complete signup.",
            });

        } catch (error) {
            console.error("Signup Error:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Signup process failed."
            });
        }
    }
    //send otp
    async sendOtp(user_id, requestData) {
        try {
            const otp = common.generateOtp();
            const contact = requestData.email || requestData.phone_no;
            if (!contact) {
                throw new Error("No valid contact value provided.");
            }
            const otpData = { user_id, otp, verify_with: contact };
            const insertOtp = "INSERT INTO tbl_otp SET ?";
            await con.query(insertOtp, otpData);
            console.log("OTP Inserted With User_id:", user_id);
            return {
                code: responseCode.SUCESS,
                message: "OTP sent successfully"
            };
        } catch (error) {
            console.error("OTP Sending Error:", error);
            return {
                code: responseCode.OPERATION_FAILED,
                message: "Failed to send OTP"
            };
        }
    }
    // verify otp 
    async verifyOtp(requestData, callback) {
        try {
            const { verify_with, otp } = requestData;
            // console.log(requestData);

            if (!verify_with || !otp) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Missing Value..."
                });
            }

            console.log("Verify OTP With:", verify_with);
            const otpQuery = "SELECT * FROM tbl_otp WHERE verify_with=? AND otp=? AND is_verify='0'";
            // Pass an array of parameters matching the placeholders
            const [result] = await con.query(otpQuery, [verify_with, otp]);
            //console.log(result[0]);
            const user_id = result[0].user_id;
            //console.log(user_id);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Invalid OTP...."
                });
            }
            const updateOtpQuery = "UPDATE tbl_otp SET is_verify='1' WHERE verify_with=? AND otp=?";
            await con.query(updateOtpQuery, [verify_with, otp]);

            const step = "SELECT is_step FROM tbl_user WHERE user_id=?";
            const [stepcnt] = await con.query(step, [user_id]);
            //console.log(stepcnt[0]);
            const { is_step } = stepcnt[0];
            if (is_step !== '3') {
                const updateQuery = "UPDATE tbl_user SET is_step='2' WHERE user_id=?";
                // Ensure the parameter is provided in an array
                await con.query(updateQuery, [user_id]);
            }
            return callback({
                code: responseCode.SUCESS,
                message: "OTP Verified Successfully"
            });
        } catch (error) {
            console.error("Error during OTP Verification:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Failed OTP Verification"
            });
        }
    }
    //Edit Prfile .....
    async editProfile(requestData, callback) {
        try {
            const { user_name, dob, full_name, description, profile_pic, is_step } = requestData;

            if (!user_name) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Missing Value..."
                });
            }

            console.log("Edit Profile For Request:", user_name);
            console.log(requestData);

            // Correctly using con.query (not awaitcon.query)
            const checkQuery = "SELECT user_id, is_step FROM tbl_user WHERE user_name=?";
            const [status] = await con.query(checkQuery, [user_name]);
            console.log(status[0]);

            if (!status || status.length === 0) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "User Not Found."
                });
            }

            if (status[0].is_step < '2') {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Please Complete OTP Verification..."
                });
            }

            const user_id = status[0].user_id;

            // Create an updateData object with the fields you want to update
            const updateData = {
                dob,
                full_name,
                description,
                profile_pic,
                is_step // This can be used to mark the new step (e.g., '3')
            };

            const updateQuery = "UPDATE tbl_user SET ? WHERE user_name = ?";
            await con.query(updateQuery, [updateData, user_name]);
            console.log("User updated with user_name:", user_name);

            // Generate and update device token if step is 3
            if (updateData.is_step === '3') {
                const token = "User" + common.generateToken(4);
                const updateTokenQuery = "UPDATE tbl_device SET token = ? WHERE user_id = ?";
                await con.query(updateTokenQuery, [token, user_id]);
                console.log("Device token updated for user_id:", user_id);
            }

            return callback({
                code: responseCode.SUCCESS,
                message: "User Profile Updated Successfully."
            });

        } catch (error) {
            console.error("Error during profile update:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: error.message || "Failed to update user profile."
            });
        }
    }
    // Login 

    async login(requestData, callback) {
        try {
            // Destructure required fields from requestData
            const { email, password } = requestData;
            console.log("Login request for user:", email);

            // Validate required fields
            if (!email || !password) {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    message: "Email and password are required"
                });
            }

            // Hash the provided password
            const hashedPassword = md5(password);

            // Login query to fetch the user by email and hashed password
            const loginQuery = "SELECT * FROM tbl_user WHERE email = ? AND password = ?";
            const [userResult] = await con.query(loginQuery, [email, hashedPassword]);
            //console.log(userResult[0]);
            if (!userResult || userResult.length === 0) {
                return callback({
                    code: responseCode.NOT_REGISTERED,
                    message: "Invalid email or password"
                });
            }
            const { user_id, is_step } = userResult[0];
            //   console.log(user_id);
            //   console.log(is_step)
            // Check if OTP verification has been completed (i.e. is_step should be '3')
            if (is_step === 3) {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    message: "Please complete OTP verification before logging in"
                });
            }

            // Generate tokens
            const token = "USER" + common.generateToken(4);
            const device_token = "DEVICE" + common.generateToken(4);

            // Update device information in tbl_device
            const updateDeviceQuery = "UPDATE tbl_device SET token = ?, device_token = ? WHERE user_id = ?";
            await con.query(updateDeviceQuery, [token, device_token, user_id]);

            console.log("Device token updated for user_id:", user_id);
            return callback({
                code: responseCode.SUCCESS,
                message: "Login Successfully"
            });

        } catch (error) {
            console.error("Error during login:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Database error occurred"
            });
        }
    }
    async forgotPassword(requestData, callback) {
        try {
            if (!requestData.email) {
                console.log(requestData);
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Missig Value..."
                });
            }
            console.log("Forgot Password Request user  : ", requestData.email || requestData.phone_no);
            const frogotPwd = "SELECT user_id,user_name FROM tbl_user where email=?";
            const [result] = await con.query(frogotPwd, [requestData.email]);
            console.log(result[0]);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Email Not Found..."
                });
            }
            const { user_id } = result[0];
            console.log(user_id);
            await this.sendOtp(user_id, requestData);
            return callback({
                code: responseCode.SUCCESS,
                message: "OTP Sent Successfully. Please verify to complete Process",
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Database error occurred"
            });
        }
    }
    async setPassword(requestData, callback) {
        const { otp, email, password } = requestData;
        try {
            if (!requestData) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Missing Value...."
                });
            }
            const checkOTPQuery = "SELECT user_id FROM tbl_otp WHERE verify_with=? AND otp=? AND is_verify=1";
            console.log("Executing OTP verification query:", checkOTPQuery);
            const [otpResult] = await con.query(checkOTPQuery, [requestData.email, requestData.otp]);
            console.log("OTP Query Result:", otpResult);
            if (!otpResult || otpResult.length === 0) {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    message: "Database Error"
                });
            }

            //console.log("OTP Verified, proceeding to update password.");

            const user_id = otpResult[0].user_id;
            const newpassword = md5(requestData.password); // Ensure you hash passwords
            const updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE user_id=?";

            // Execute password update query
            await con.query(updatePasswordQuery, [newpassword, user_id]);

            return callback({
                code: responseCode.SUCCESS,
                message: "Password updated successfully."
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Database error occurred."
            });
        }
    }
    async changePassword(requestData, callback) {
        try {
            const { user_name, OldPassword, NewPassword } = requestData;
            const data = {
                user_name,
                OldPassword: md5(OldPassword),
                NewPassword: md5(NewPassword)
            };
            if (!requestData) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Missing Value....."
                });
            }
            console.log("Change Password Request:", user_name);
            const checkPasswordQuery = "SELECT * FROM tbl_user WHERE user_name=?";
            const [result] = await con.query(checkPasswordQuery, [data.user_name]);

            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NOT_APPROVE,
                    message: "User not found."
                });
            }
            const user = result[0];
            if (user.type !== "S") {
                console.log("User logged in with social account");
                return callback({
                    code: responseCode.NOT_APPROVE,
                    message: "Login with social ID"
                });
            }

            if (data.OldPassword !== user.password) {
                return callback({
                    code: responseCode.NOT_APPROVE,
                    message: "Old password is incorrect!"
                });
            }

            if (data.NewPassword === user.password) {
                return callback({
                    code: responseCode.NOT_APPROVE,
                    message: "Old password and new password cannot be the same!"
                });
            }

            const updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE user_name=?";
            const [updateResult] = await con.query(updatePasswordQuery, [data.NewPassword, data.user_name]);

            if (updateResult.affectedRows === 0) {
                console.log("Password update failed");
                return callback({
                    code: responseCode.NOT_APPROVE,
                    message: "Password update failed"
                });
            }

            console.log("Password changed successfully for user:", data.user_name);
            return callback({
                code: responseCode.SUCCESS,
                message: "Password changed successfully"
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Database error occurred."
            });
        }
    }
    async trendingPost(requestData, callback) {
        try {
            console.log("Fetching trending Post : ");
            const query = `SELECT sp.image_name as Trending_post FROM tbl_post as p INNER JOIN tbl_sub_post as sp on sp.post_id=p.post_id GROUP BY sp.post_id ORDER BY p.avg_rate`;
            const [result] = await con.query(query);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }

            return callback({
                code: responseCode.SUCCESS,
                message: "Trending Posts retrieved successfully.",
                data: result
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Database error occurred."
            });
        }
    }
    async filterPost(requestData, callback) {
        let { filter_type, post_type, follow_id } = requestData;
        try {
            let query = "";
            console.log("Fetching New Post : ");
            if (filter_type === "New") {
                if (post_type === "TostyleMe") {
                    query = `SELECT sp.image_name as Post_image, p.post_type as Post_Type FROM tbl_post as p INNER JOIN tbl_sub_post as sp ON sp.post_id = p.post_id WHERE p.post_type = 'TostyleMe' GROUP BY sp.post_id ORDER BY p.create_at`;
                }
                else if (post_type === "TostyleVideo") {
                    query = `SELECT sp.image_name as Post_image,p.post_type as Post_Type FROM tbl_post as p INNER JOIN tbl_sub_post as sp on sp.post_id=p.post_id WHERE p.post_type='TostyleVideo' GROUP BY sp.post_id ORDER BY p.create_at`;
                }
                else if (post_type === "TostyleCompare") {
                    query = `SELECT sp.image_name as Post_image,p.post_type as Post_Type FROM tbl_post as p INNER JOIN tbl_sub_post as sp on sp.post_id=p.post_id WHERE p.post_type='TostyleCompare' GROUP BY sp.post_id ORDER BY p.create_at`;
                }
                else {
                    //Console.log("CALL TO ALL");
                    query = `SELECT sp.image_name as Post_image, p.post_type as Post_Type FROM tbl_post as p INNER JOIN tbl_sub_post as sp on sp.post_id = p.post_id GROUP BY sp.post_id ORDER BY p.create_at`;
                }
            }
            else if (filter_type === "Following") {
                if (post_type === "TostyleMe") {
                    query = "SELECT p.post_id, sp.image_name, p.post_type FROM tbl_post as p INNER JOIN tbl_sub_post as sp on sp.post_id=p.post_id INNER JOIN tbl_user as u on u.user_id=p.user_id where p.post_type='TostyleMe' and u.user_id=(select following from tbl_following where following='" + requestData.follow_id + "') GROUP BY sp.post_id";
                }
                else if (post_type === "TostyleVideo") {
                    query = "SELECT p.post_id, sp.image_name, p.post_type FROM tbl_post as p INNER JOIN tbl_sub_post as sp on sp.post_id=p.post_id INNER JOIN tbl_user as u on u.user_id=p.user_id where p.post_type='TostyleVideo' and u.user_id=(select following from tbl_following where following='" + requestData.follow_id + "') GROUP BY sp.post_id";
                }
                else if (post_type === "TostyleCompare") {
                    query = "SELECT p.post_id, sp.image_name, p.post_type FROM tbl_post as p INNER JOIN tbl_sub_post as sp on sp.post_id=p.post_id INNER JOIN tbl_user as u on u.user_id=p.user_id where p.post_type='TostyleCompare' and u.user_id=(select following from tbl_following where following='" + requestData.follow_id + "') GROUP BY sp.post_id";
                }
                else { //Console.log("CALL TO ALL");
                    query = "SELECT p.post_id, sp.image_name, p.post_type FROM tbl_post as p INNER JOIN tbl_sub_post as sp on sp.post_id=p.post_id INNER JOIN tbl_user as u on u.user_id=p.user_id WHERE u.user_id=(select following from tbl_following where following='" + requestData.follow_id + "') GROUP BY sp.post_id";
                }
            }
            else if (filter_type === "Expire") {
                if (post_type === "TostyleMe") {
                    query = `SELECT p.post_id, sp.image_name, p.post_type FROM tbl_post as p INNER JOIN tbl_sub_post as sp on sp.post_id=p.post_id WHERE  p.post_type='TostyleMe' AND expire_time>= CURRENT_TIMESTAMP() GROUP BY sp.post_id`;
                }
                else if (post_type === "TostyleVideo") {
                }
                else if (post_type === "TostyleCompare") {
                    query = `SELECT p.post_id, sp.image_name, p.post_type FROM tbl_post as p INNER JOIN tbl_sub_post as sp on sp.post_id=p.post_id WHERE  p.post_type='TostyleCompare' AND expire_time>= CURRENT_TIMESTAMP() GROUP BY sp.post_id`;
                }
                else if (requestData.post_type === "Tostyleall") {//Console.log("CALL TO ALL");
                    query = `SELECT p.post_id, sp.image_name, p.post_type FROM tbl_post as p INNER JOIN tbl_sub_post as sp on sp.post_id=p.post_id WHERE  expire_time>= CURRENT_TIMESTAMP() GROUP BY sp.post_id`;
                }
            }
            console.log(query);
            const [result] = await con.query(query);
            console.log("Query result:", result);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "New Posts retrieved successfully.",
                data: result
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Database error occurred."
            });
        }
    }
    async category(requestData, callback) {
        try {
            console.log("Fetching tCategory : ");
            const query = `SELECT name FROM tbl_category`;
            const [result] = await con.query(query);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }

            return callback({
                code: responseCode.SUCCESS,
                message: "Category retrieved successfully.",
                data: result
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Database error occurred."
            });
        }
    }
    async AddPost(requestData, callback) {
        try {
            const {
                user_id, description, expire_time, post_type, category_id, duration, image_name
            } = requestData;
            if (!user_id || !description || !post_type || !category_id || !expire_time || !image_name) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Missing required fields"
                });
            }
            const postData = {
                user_id, description, expire_time, post_type, category_id, duration
            };
            const insertQuery = "INSERT INTO tbl_post SET ?";
            console.log(insertQuery)
            const [postResult] = await con.query(insertQuery, postData);
            // console.log(userResult);

            if (!postResult.insertId) {
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to insert post data."
                }, null);
            }
            console.log("Post Add With ID:", postResult.insertId);
            const post_id = postResult.insertId;
            const imageNames = image_name.split(','); // Split image names by comma

            for (const image of imageNames) {
                const imageData = { post_id, image_name: image.trim() };
                const insertImgQuery = "INSERT INTO tbl_sub_post SET ?";
                await con.query(insertImgQuery, imageData);
            }

            console.log("post image data add with ID:", post_id);
            return callback({
                code: responseCode.SUCCESS,
                message: "Post Data Add Successfully",
            });


        } catch (error) {
            console.error("Signup Error:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Post Can Not be Upload"
            });
        }
    }
    async displayPost(requestData, callback) {
        try {
            if (!requestData) {
                let GetPosts = "SELECT u.profile_pic,u.user_name,u.description,u.follower,u.following,p.post_id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.post_id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.user_id ";
                const [result] = await con.query(GetPosts)
                if (result <= 0) {
                    return callback({
                        code: responseCode.NO_DATA_FOUND,
                        message: "no data found",
                    })
                }
                return callback({
                    code: responseCode.success,
                    message: "data found",
                    data: result
                })
            } else {
                let GetPosts = "SELECT u.profile_pic,u.user_name,u.description,u.follower,u.following,p.post_id,(SELECT GROUP_CONCAT(image_name) FROM tbl_sub_post WHERE post_id=p.post_id) as images FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.user_id WHERE  p.post_type='TostyleCompare'";
                const [result] = await con.query(GetPosts)
                if (result <= 0) {
                    return callback({
                        code: responseCode.NO_DATA_FOUND,
                        message: "no data found",
                    })
                }
                return callback({
                    code: responseCode.SUCESS,
                    message: "data found",
                    data: result
                })
            }
        } catch (error) {
            console.error("Signup Error:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Databse Error"
            });
        }
    }
    async UserProfile(requestData, callback) {
        try {
            console.log("Fetching User Data : ");
            const query = `SELECT u.profile_pic, u.user_name,u.description,u.follower,u.following,u.avg_rate FROM tbl_user as u  WHERE u.user_id=?`;
            const [result] = await con.query(query, [requestData.user_id]);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }

            return callback({
                code: responseCode.SUCCESS,
                message: "User Data retrieved successfully.",
                data: result
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Database error occurred."
            });
        }
    }
    async UserProfileType(requestData, callback) {
        try {
            let query = "";
            const { post_type, user_id } = requestData;
            if (post_type === "TostyleMe") {
                query = `SELECT u.user_id,(SELECT GROUP_CONCAT(image_name) from tbl_sub_post where post_id=p.post_id)as image ,p.post_type FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.user_id WHERE u.user_id=? and p.post_type='TostyleMe'`;
            }
            else if (post_type === "TostyleVideo") {
                query = `SELECT u.user_id,(SELECT GROUP_CONCAT(image_name) from tbl_sub_post where post_id=p.post_id)as image ,p.post_type FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.user_id WHERE u.user_id=? and p.post_type='TostyleVideo'`;
            }
            else if (post_type === "TostyleCompare") {
                query = `SELECT u.user_id,(SELECT GROUP_CONCAT(image_name) from tbl_sub_post where post_id=p.post_id)as image ,p.post_type FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.user_id WHERE u.user_id=? and p.post_type='TostyleCompare'`;
            }
            else {
                //Console.log("CALL TO ALL");
                query = `SELECT u.user_id,(SELECT GROUP_CONCAT(image_name) from tbl_sub_post where post_id=p.post_id)as image ,p.post_type FROM tbl_user as u INNER JOIN tbl_post as p on p.user_id=u.user_id WHERE u.user_id=?`;
            }
            console.log(query);
            const [result] = await con.query(query, [requestData.user_id]);
            console.log("Query result:", result);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "New Posts retrieved successfully.",
                data: result
            });

        } catch (error) {

        }
    }
    async savePost(requestData, callback) {
        try {
            console.log("Fetching Save Post : ");
            const query = `SELECT p.post_id,sp.image_name,s.user_id FROM tbl_save as s INNER JOIN tbl_post as p on s.post_id=p.post_id INNER JOIN tbl_sub_post as sp on sp.post_id=p.post_id WHERE s.user_id=1 GROUP BY sp.post_id`;
            const [result] = await con.query(query);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }

            return callback({
                code: responseCode.SUCCESS,
                message: "Save Posts retrieved successfully.",
                data: result
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Database error occurred."
            });
        }
    }
    async addComment(requestData, callback) {
        try {
            const {
                comment, user_id, post_id
            } = requestData;

            if (!user_id || !post_id || !comment) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Missing required fields"
                });
            }
            const insertQuery = "INSERT INTO tbl_comment SET ?";
            console.log(insertQuery)
            const [userResult] = await con.query(insertQuery, requestData);
            // console.log(userResult);

            if (!userResult.insertId) {
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to insert  data."
                }, null);
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Commented on post.",
            });

        } catch (error) {
            console.error(" Error:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "comment can not post failed."
            });
        }
    }
    async addRate(requestData, callback) {
        try {
            const {
                rate, user_id, post_id
            } = requestData;

            if (!user_id || !post_id || !rate) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Missing required fields"
                });
            }
            const insertQuery = "INSERT INTO tbl_post_rate SET ?";
            console.log(insertQuery)
            const [userResult] = await con.query(insertQuery, requestData);
            // console.log(userResult);

            if (!userResult.insertId) {
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to insert  data."
                }, null);
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "rate on post.",
            });

        } catch (error) {
            console.error(" Error:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "comment can not post failed."
            });
        }
    }
    async subPostRate(requestData, callback) {
        try {
            const {
                rate, user_id, sub_post_id
            } = requestData;

            if (!user_id || !sub_post_id || !rate) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    message: "Missing required fields"
                });
            }
            const insertQuery = "INSERT INTO tbl_sub_post_rate SET ?";
            console.log(insertQuery)
            const [userResult] = await con.query(insertQuery, requestData);
            // console.log(userResult);

            if (!userResult.insertId) {
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to insert  data."
                }, null);
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "rate on post.",
            });

        } catch (error) {
            console.error(" Error:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "comment can not post failed."
            });
        }
    }
    async PostCompare(requestData, callback) {
        try {
            const{post_id}=requestData;
            console.log("Fetching Post : ");
            const query = `SELECT s.image_name, ROW_NUMBER() OVER(ORDER BY s.avg_rate DESC) AS Rank FROM tbl_sub_post AS s INNER JOIN tbl_post AS p ON s.post_id = p.post_id WHERE p.post_type = 'TostyleCompare' AND s.post_id=?`;
            const [result] = await con.query(query,[requestData.post_id]);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }

            return callback({
                code: responseCode.SUCCESS,
                message: " Posts Ranking retrieved successfully.",
                data: result
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Database error occurred."
            });
        }
    }
    async addCategory(requestData,callback) {
        try {
            const {
                name
            } = requestData;

            if (!name) {
                return callback ({
                    code: responseCode.REQUEST_ERROR,
                    message: "Missing required fields"
                });
            }
            const insertQuery = "INSERT INTO tbl_category SET ?";
            //console.log(insertQuery)
            const [userResult] = await con.query(insertQuery, requestData);
            // console.log(userResult);

            if (!userResult.insertId) {
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to insert  data."
                }, null);
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Category Add Successfully",
            });

        } catch (error) {
            console.error(" Error:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Databse Error."
            });
        }
    }
    async Logout(requestData,callback){
        try {
            const {user_name}=requestData;
            console.log("Logout Request for : ",user_name);
            const query="SELECT u.user_id,u.user_name,d.token,d.device_token FROM tbl_user as u INNER JOIN tbl_device as d on u.user_id=d.user_id WHERE u.user_name=?";
            const [result] = await con.query(query,[requestData.user_name]);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            console.log("User Logout With ID:", result[0].user_id);
            const user_id = result[0].user_id;
            const updatetoken="UPDATE tbl_device SET token=NULL, device_token=NULL WHERE user_id=?";
            const [status] = await con.query(updatetoken,[user_id]);
            //console.log(status);
            
            if (status.affectedRows === 0) {
                console.log("Token update failed");
                return callback({
                    code: responseCode.NOT_APPROVE,
                    message: "Token update failed"
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Logout Successfully",
                //data: result
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "Database error occurred."
            });
        }
    }

}

module.exports = new UserModel();