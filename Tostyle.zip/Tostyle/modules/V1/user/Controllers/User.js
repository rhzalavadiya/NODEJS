const responseCode = require("../../../../utillities/responseErrorCode");
const constant = require("../../../../config/constant");
const common = require("../../../../utillities/common");
const userModel = require("../Models/userModel");
const middleware = require("../../../../middeleware/validators");
const validationRules = require("../../../validation_rules");
const { request } = require("express");
const message = require("../../../../language/arbic");
const { t } = require('localizify');
class User {
    constructor() { }
    signUp(req, res) {
        const requestData = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.signUp
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keywords)
        if (valid) {
            userModel.signUp(requestData, (_responseData) => {
                common.response(res, _responseData);
            });
        }
    }
    addComment(req, res) {
        const requestData = req.body;
        userModel.addComment(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    addRate(req, res) {
        const requestData = req.body;
        userModel.addRate(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    subPostRate(req, res) {
        const requestData = req.body;
        userModel.subPostRate(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    verifyOtp(req, res) {
        const requestData = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.verifyOtp
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keywords)
        if (valid) {
            userModel.verifyOtp(requestData, (_responseData) => {
                common.response(res, _responseData);
                // res.json(_responseData);
            });
        }
    }
    login(req, res) {
        const requestData = req.body;

        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.login
        console.log(rules)
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keywords)
        if (valid) {
            userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });
            /*userModel.login(request,function(request,_responseData){
                console.log(message);
                middleware.sendResponse(req,res,_responseData);
            })*/
        }
    }
    editProfile(req, res) {
        const requestData = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'full_name': t('rest_keywords_password')
        }

        const rules = validationRules.editProfile
        console.log(rules)
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keywords)
        if (valid) {
            userModel.editProfile(requestData, (_responseData) => {
                common.response(res, _responseData);
                //res.json(_responseData);
            });
        }
    }
    forgotPassword(req, res) {
        const requestData = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.forgotPassword
        console.log(rules)
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keywords)
        if (valid) {
            userModel.forgotPassword(requestData, (_responseData) => {
                common.response(res, _responseData);
                // res.json(_responseData);
            });
        }
    }
    setPassword(req, res) {
        const requestData = req.body;
        userModel.setPassword(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    changePassword(req, res) {
        const requestData = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.changePassword
        console.log(rules)
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keywords)
        if (valid) {
        userModel.changePassword(requestData, (_responseData) => {
            common.response(res,_responseData);
            //res.json(_responseData);
        });
    }
    }
    trendingPost(req, res) {
        const requestData = req.body;
        userModel.trendingPost(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    PostCompare(req, res) {
        const requestData = req.body;
        userModel.PostCompare(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    savePost(req, res) {
        const requestData = req.body;
        userModel.savePost(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    filterPost(req, res) {
        const requestData = req.body;
        userModel.filterPost(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    category(req, res) {
        const requestData = req.body;
        userModel.category(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    AddPost(req, res) {
        const requestData = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.AddPost
        console.log(rules)
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keywords)
        if (valid) {
        userModel.AddPost(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    }
    displayPost(req, res) {
        let requestData = req.params.post_type;
        userModel.displayPost(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    UserProfile(req, res) {
        let requestData = req.body;
        userModel.UserProfile(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    UserProfileType(req, res) {
        let requestData = req.body;
        userModel.UserProfileType(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    Logout(req, res) {
        let requestData = req.body;
        userModel.Logout(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }

    addCategory(req, res) {
        let requestData = req.body;
        userModel.addCategory(requestData, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
}

module.exports = new User;