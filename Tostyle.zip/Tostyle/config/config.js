const env={
    serverListen:3000,
    version :"1.0.0",
    apiKey:"ToStyleModule"
};
module.exports=env;