const Validator =require('Validator');
const {default:localizify} = require('localizify');
const en=require('../language/english');
const ar=require('../language/arbic');
const hn=require('../language/hindi');
const {t} = require('localizify');
const con=require('../config/database');
const middleware={
    checkValidationRules:function(req,res,request,rules,message,keywords){
        const v = Validator.make(request,rules,message,keywords);
        if(v.fails()){
            const errors = v.getErrors();
            console.log(errors);

            var error = "";
            for(var key in errors){
                error = errors[key][0];
                break;
            }
            responseData = {
                code:"0",
                message:error
            }

            // middleware(response_data,function(response){
                // res.status(200);
                // res.send(response);
            // });
            res.status(200).send(responseData);
            return false;
        }else{
            return true;
        }
    },
    sendResponse:function(req,res,code,message,data){
        console.log(req.language);
        this.getMessage(req.language,message,function(translateMessage){
            console.log(translateMessage);
            if (data==null) {
                responseData={
                    code:code,
                    message:translateMessage,
                    data:data
                }
                res.status(200).send(responseData);
            }
            else{
                responseData={
                    code:code,
                    message:translateMessage,
                    data:data
                }
                res.status(200).send(responseData);
            }
        })
    },
    getMessage:function(language,message,callback){
        localizify .add('en',en)
        .add('ar',ar)
        .add('hn',hn)
        .setLocale(language);
        console.log(message);
        let translateMessage=t(message.keywords);
        if(message.content){
            Object.keys(message.content).forEach(key =>{
                translateMessage=translateMessage.replace(`{${key}}`,message.content[key]);
            });
        }
        callback(translateMessage);
    },
    extractHeaderLanguage:function(req,res,callback){
        var headerlang = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "") 
         ? req.headers['accept-language'] : 'en';

         req.lang = headerlang;

         req.language = ( headerlang == 'en') ? en  :( headerlang == 'hn') ? hn :  ar ;         

         localizify
         .add('en',en)
        .add('ar',ar)
        .add('hn',hn)
         .setLocale( req.language);
         
         callback();
    },
}
module.exports=middleware;