const{fetch}=require('undici')
async function fetchData()
{
    try{
        const response=await fetch("https://official-joke-api.appspot.com/random_joke");
        if(!response){
            throw new Error("Error");
        }
        const data=await response.json()
        console.log(data.setup);
        console.log(data.punchline);
    }
    catch(error){
        console.log(error);
    }
}
fetchData()