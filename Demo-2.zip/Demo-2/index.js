const express = require('express');
const fs = require('fs').promises;
const app = express();

app.use(express.json());
//sigup api
app.post('/register', async function (req, res) {
    try {
        const { name, email, password, confirmPassword, image, gender, mobile } = req.body;

        // Validate password and confirmPassword match
        if (password !== confirmPassword) {
            return res.send({
                code: "0",
                message: "Passwords do not match",
            });
        }

        // Create response data
        const responseData = `
            Name: ${name}
            Email: ${email}
            Password:${password}
            Gender: ${gender}
            Mobile: ${mobile}
            Image: ${image}
        `;

        // Save the data to a text file
        //await fs.writeFile('registration_data.txt', responseData);
        await fs.appendFile('registration_data.txt', responseData);

        // Send a successful response
        res.send({
            code: "1",
            message: "Registration successful",
        });
    } catch (error) {
        console.error('Error occurred:', error);

        // Send error response
        res.send({
            code: "0",
            message: "Error",
            data: "Some error occurred",
        });
    }
});
/*
// Login Endpoint
app.post('/login', async function (req, res) {
    try {
        const { email,password} = req.body;
        const Data=req.body

        // Read the registration data from the text file
        const fileContent = await fs.readFile('registration_data.txt', 'utf8');

        // Check if the email exists in the registration data
        const emailExists = fileContent.includes(`Email: ${email}`);
        const passwordExists = fileContent.includes(`Password:${password}`);
        
        if (emailExists && passwordExists) {
            res.send({
                code: "1",
                message: "Success",
                Data: {
                email: email,
                password:password,
            },
            });
        } else {
            // If the email does not match, send error response
            res.send({
                code: "0",
                message: "Error",
                Data: null,
            });
        }
    } catch (error) {
        console.error('Error occurred:', error);

        // Handle errors (e.g., file not found or other issues)
        res.send({
            code: "0",
            message: "Error",
            Data: null,
        });
    }
});*/

// Login Endpoint WITH PROMISE 
app.post('/login', function (req, res) {
    const { email, password } = req.body;

    new Promise((resolve, reject) => {
        fs.readFile('registration_data.txt', 'utf8', (error, fileContent) => {
            if (error) {
                return reject(error);
            }
            resolve(fileContent);
        });
    })
        .then((fileContent) => {
            const emailExists = fileContent.includes(`Email: ${email}`);
            const passwordExists = fileContent.includes(`Password:${password}`);

            if (emailExists && passwordExists) {
                res.send({
                    code: "1",
                    message: "Success",
                    Data: {
                        email: email,
                        password: password,
                    },
                });
            } else {
                res.send({
                    code: "0",
                    message: "Invalid email or password",
                    Data: null,
                });
            }
        })
        .catch((error) => {
            console.error('Error occurred:', error);
            res.send({
                code: "0",
                message: "Error occurred while processing your request",
                Data: null,
            });
        });
});
//Add place


function appendPlaceToFile(placeData, callback) {
    // Using appendFile in an asynchronous way
    fs.appendFile('places.txt', placeData, 'utf8', callback);  // Directly pass callback to fs.appendFile
}

app.post('/addplace', function (req, res) {
    var { placeid, placename } = req.body;

    // Ensure both placeid and placename are provided
    if (placeid && placename) {
        var response = {
            "code": "1",
            "message": "Add Place successful",
            "data": {
                "placeid": placeid,
                "placename": placename
            },
        };

        // Format the place data for storage
        const placeData = `Place ID: ${placeid}, \nPlace Name: ${placename}\n\n`;

        // Call appendPlaceToFile function with a callback
        appendPlaceToFile(placeData, function (err) {
            if (err) {
                console.log("Error writing to file:", err);
                return res.send({
                    "code": "0",
                    "message": "Place Not Added due to error in file write"
                });
            }

            // Send the response back to the client after successfully appending the data to the file
            res.send(response);
        });
    } else {
        var response = {
            "code": "0",
            "message": "Place Not Added",
        };
        res.send(response);
    }  
});


try {
    app.listen(3033);
    console.log("Connected");
} catch (error) {
    console.log("Error:", error);
}

