function fetchData()
{
    return new Promise((resolve,reject)=>{
        console.log("fetching Data...");
        setTimeout(()=>{
            const success=true;
            if(success)
            {
                resolve("Data Found...")
            }
            else{
                reject("Failed...")
            }
        },2000);
    })
}
fetchData()
    .then((result)=>{
        console.log(result);
    })
    .catch((error)=>{
        console.log(error);
    })
    .finally(()=>{
        console.log("Completed...");
    });