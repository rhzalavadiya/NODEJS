const fs=require('fs').promises;
(async()=>{
    try{
        await fs.writeFile('demo.txt',"Hello Rupali");
        console.log("File Writen Done...");

        const data=await fs.readFile('demo.txt','utf-8')
        console.log(data);

        await fs.appendFile('demo.txt','\nMore Data');
        console.log("Append Done");

       
         await fs.unlink('demo.txt');
        console.log("delete Done");
    }
    catch(error){
        console.log(error);
    }
})();