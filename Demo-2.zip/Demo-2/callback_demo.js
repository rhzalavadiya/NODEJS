function fetchData(callback)
{
    console.log("Faching Data.....");
    setTimeout(() => {
        const data="Rupali";
        console.log("Data Fetched....");
        callback(data);
    }, 2000);
}
function processData(data)
{
    console.log("Processed Data...");
    console.log(data);
}
function main()
{
    console.log("Start Program...");
    fetchData(processData);
    console.log("Cotinues...");
}
main()