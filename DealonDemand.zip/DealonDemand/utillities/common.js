const httpStatus=require("http-status-codes");
const database=require("../config/database");
const responseCode=require("./response-error-code");
const { text } = require("express");
class common{

    response(res,message,statusCode=httpStatus.OK){
        res.status(statusCode);
        res.json(this.message);
    }

    generateOTP(){
        return Math.floor(100000 + Math.random() * 900000).toString();
    }
    generateToken(length=5){
        const possible="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let token="";
        for(let i=0;i<length;i++){
            token+=possible.charAt(Math.floor(Math.random()*possible.length));
        }
        return token;
    }
    getUserDetail(user_id,login_user_id,callback){
        const context =this;
        const select="select * from tbl_user where user_id=? and is_delete=0";
        database.query(select,user_id,function(error,user){
            if(error){
                callback(error,[]);
            }
            else{
                if(user.length>0){
                    callback(undefined,user[0]);
                }
                else{
                    callback(("No Data Found"),[]);
                }
            }
        });
    }
    sendOTP(user_id, request_data, callback) {
        const otp = this.generateOTP();
        console.log("Generated OTP:", otp);

        let contact = null;
        if (request_data.email) {
            contact = request_data.email;
        } else if (request_data.phone_no) {
            contact = request_data.phone_no;
        }

        if (!contact) {
            return callback({
                code: responseCode.OPERATION_FAILED,
                message: "No valid contact information provided."
            });
        }

        const otpData = {
            user_id: user_id,
            otp: otp,
            verify_with: contact,
            //is_verify: 0 // Not verified yet
        };

        const insertOtp = "INSERT INTO tbl_otp SET ?";
        database.query(insertOtp, otpData, (otpError) => {
            if (otpError) {
                console.error("OTP insertion error:", otpError);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to insert OTP data."
                });
            }

            return callback({
                code: responseCode.SUCCESS,
                message: "OTP Sent Successfully. Please verify to complete ."
            });
        });
    }
}
module.exports=new common;