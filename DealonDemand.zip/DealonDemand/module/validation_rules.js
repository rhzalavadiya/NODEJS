const { email } = require("../language/arbic");
const { addpost } = require("./v1/user/models/User-model");

const checkValidationRules = {
    login: {
        email: 'required|email',
        password: 'required|min:4',
    },
    signUp: {
        user_name: "required",
        country_code_id: "required",
        email: "required|email",
        phone_no: "required|string|min:10|regex:/^[0-9]+$/",
        password: "required|min:4",
        referal_id: "required",

    },
    verifyOtp: {
        verify_with: "required",
        otp: "required",
    },
    editProfile: {
        first_name: "required",
        last_name: "required",
        description: "required", // Fixed typo
        location: "required",
        latitude: "required",
        longitude: "required",
    },
    forgotPassword: {
        email: "email",
        phone_no: "numeric|string|min:10|regex:/^[0-9]+$/"
    },
    changePassword: {
        OldPassword: "required|min:4",
        NewPassword:"required|min:4",
    },
    addpost:{
        user_id: "required",
        title: "required",
        description: "required",
        location: "required",
        latitude: "required",
        longitude: "required",
        website_url:"required",
        category_id: "required",
        
    },
}
module.exports = checkValidationRules