const User=require("../Controllers/User");
const customerRoute=(app)=>{
    app.post("/v1/user/signup",User.signup);
    app.post("/v1/user/login",User.login);

    app.post("/v1/user/verifyotp",User.verifyOTP);
    app.post("/v1/user/editprofile",User.editProfile);

    app.post("/v1/user/forgotpassword",User.forgotpassword);
    app.post("/v1/user/setpassword",User.setpassword);

    app.get("/v1/user/getcategory",User.getcategory);
    app.get("/v1/user/getpost",User.getpost);
    app.get("/v1/user/getonepost",User.getonepost);
    app.get("/v1/user/getcategorypost/:category_name",User.getcategorypost);
    app.get("/v1/user/getpostcomment",User.getpostcomment);
    app.get("/v1/user/getallcomment",User.getallcomment);
    app.get("/v1/user/userprofile",User.userprofile);
    app.get("/v1/user/filterpost/:category_name",User.filterpost);
    app.get("/v1/user/savepost",User.savepost);
    app.get("/v1/user/reportpost",User.reportpost);
    app.get("/v1/user/follower",User.follower);
    app.get("/v1/user/following",User.following);

    app.post("/v1/user/addpost",User.addpost);
    app.post("/v1/user/changepassword",User.changepassword);
    app.get("/v1/user/otherprofile",User.otherprofile);

}
module.exports=customerRoute;