const conn = require("../../../../config/database");
const responseCode = require("../../../../utillities/response-error-code");
const common = require("../../../../utillities/common");
const constant = require("../../../../config/constant");
const md5 = require("md5");
const { log, error } = require("console");
const { verify } = require("crypto");
const e = require("express");
class UserModel {
    constructor() { }
    // signup
    signup(requestData, callback) {
        console.log("Signup request for user:", requestData.user_name);

        const data = {
            user_name: requestData.user_name,
            country_code_id: requestData.country_code_id, // Fixed typo
            phone_no: requestData.phone_no,
            email: requestData.email,
            password: md5(requestData.password),
            referal_id: requestData.referal_id, // Fixed typo
        };

        const insert = "INSERT INTO tbl_user SET ?";
        conn.query(insert, data, (error, result) => {
            if (error) {
                console.error("Database insertion error:", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to insert user data."
                });
            }

            console.log("User inserted with ID:", result.insertId);
            const user_id = result.insertId;
            const devicedata = {
                user_id: user_id,
                device_type: requestData.device_type,
                device_token: "DEVICE" + common.generateToken(5),
                os_version: requestData.os_version,
                app_version: requestData.app_version
            };
            const device = "INSERT INTO tbl_device SET ?";
            conn.query(device, devicedata, (error, dresult) => {
                if (error) {
                    console.log("Device Insert Error : ", error);
                    return callback({
                        code: responseCode.OPERATION_FAILED,
                        message: "Failed to Insert Device Data..."
                    });
                }
                console.log("Device Id : ", dresult.insertId);
            });
            // Generate OTP AND SEND OPT 
            common.sendOTP(result.insertId, requestData, callback);
            // Get user Detail 
            common.getUserDetail(result.insertId, result.insertId, (err, userInfo) => {
                if (err) {
                    console.error("Error fetching user details:", err);
                    return callback({
                        code: responseCode.OPERATION_FAILED,
                        message: err
                    });
                }

                return callback({
                    code: responseCode.SUCCESS,
                    message: "OTP Sent Successfully. Please verify to complete signup.",
                });
            });
        });
    }
    addpost(requestData, callback) {
        const data = {
            user_id: requestData.user_id,
            title: requestData.title,
            post_img: requestData.post_img,
            description: requestData.description,
            location: requestData.location,
            latitude: requestData.latitude,
            longitude: requestData.longitude,
            website_url: requestData.website_url,
            category_id: requestData.category_id
        };
        console.log(data);

        const insert = "INSERT INTO tbl_post SET ?";
        conn.query(insert, data, (error, result) => {
            console.log(result);

            if (error) {
                console.error("Database insertion error:", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to insert user data."
                });
            }
            console.log("Post inserted with ID:", result.insertId);
            return callback({
                code: responseCode.SUCCESS,
                message: "Post Add Successfully",
            });
        });

    }
    //Verify OTP
    verifyOTP(requestData, callback) {
        console.log("Verify OTP for Contact : ", requestData.verify_with);
        console.log("Verify OTP for Contact : ", requestData.otp);
        const otpverifyquery = "SELECT * FROM tbl_otp WHERE verify_with=? AND otp=? and is_verify='0' ";
        conn.query(otpverifyquery, [requestData.verify_with, requestData.otp], (error, result) => {
            if (error) {
                console.log("OTP Verifiction Error", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Databse Error In OTP Verification..."
                });
            }
            // console.log(result);
            if (result.length === 0) {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    message: "Invalid OTP..."
                });
            }
            const user_id = result[0].user_id;

            const updateopt = "UPDATE tbl_otp SET is_verify='1' WHERE verify_with=? and otp=?";
            conn.query(updateopt, [requestData.verify_with, requestData.otp], error => {
                if (error) {
                    console.log("OTP Verifiction Staatus Update Error", error);
                    return callback({
                        code: responseCode.OPERATION_FAILED,
                        message: "Databse Error In OTP Verification Stattus Update..."
                    });
                }
                const updateuser = "UPDATE tbl_user SET is_step=2 WHERE user_id=?";
                //console.log(updateuser)
                conn.query(updateuser, [user_id], error => {
                    if (error) {
                        console.log("User Status Update Error", error);
                        return callback({
                            code: responseCode.OPERATION_FAILED,
                            message: "Databse Error In User Stattus Update..."
                        });
                    }
                    return callback({
                        code: responseCode.SUCESS,
                        message: "OTP Verified Successfully "
                    });
                });
            });
        });
    }
    //change password
    changepassword(requestData, callback) {
        const data = {
            user_name: requestData.user_name,
            OldPassword: md5(requestData.OldPassword),
            NewPassword: md5(requestData.NewPassword)
        }
        console.log(data);
        let checkpassword = "select * from tbl_user where user_name=? ";
        conn.query(checkpassword, [data.user_name, data.OldPassword], (error, result) => {
            //console.log(result);

            if (error) {
                console.log("internal error", error);
                return callback({
                    code: responseCode.CODE_NULL,
                    message: "can not fetch data"
                });
            }
            if (result >= 0 || result[0].type != "S") {
                console.log("you are login with facebook or google");
                return callback({
                    code: responseCode.NOT_APPROVE,
                    message: "login with social id"
                })
            }
            if (data.OldPassword != result[0].password) {
                return callback({
                    code: responseCode.NOT_APPROVE,
                    message: "old password is not corrct !"
                })
            }
            if (data.NewPassword == result[0].password) {
                return callback({
                    code: responseCode.NOT_APPROVE,
                    message: "old password and new password are same !"
                })
            }

            let updatpassword = "update tbl_user set password=? where user_name=?";

            conn.query(updatpassword, [data.NewPassword, data.user_name], (error, result_) => {
                if (error) {
                    console.log("internal database error");
                    return callback({
                        code: responseCode.NOT_APPROVE,
                        message: "internal database error"
                    });
                }
                if (result_ <= 0) {
                    console.log("password is not change");
                    return callback({
                        code: responseCode.NOT_APPROVE,
                        message: "Password in not change"
                    });
                }
                return callback({
                    code: responseCode.SUCESS,
                    message: "Password change Sucessfully"
                });

            });
        })
    }
    // Edit Progile
    editprofile(requestData, callback) {
        console.log("Edit Profile request for user:", requestData.user_name);
        const checkstatus = "SELECT user_id,is_step FROM tbl_user WHERE user_name=?";
        conn.query(checkstatus, [requestData.user_name], (error, result) => {
            if (error) {
                console.log("Error on Fetch Data : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to check user step."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    message: "User not found."
                });
            }
            if (result[0].is_step < '2') {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    message: "Please complete OTP verification before updating your profile."
                });
            }
            console.log(result);
            const user_id = result[0].user_id;
            const data = {
                user_name: requestData.user_name,
                first_name: requestData.first_name,
                last_name: requestData.last_name,
                profile_pic: requestData.profile_pic,
                description: requestData.description, // Fixed typo
                location: requestData.location,
                latitude: requestData.latitude,
                longitude: requestData.longitude,
                is_step: '3',
            };
            const update = "UPDATE tbl_user SET ? WHERE user_name=?";
            conn.query(update, [data, data.user_name], (error, result) => {
                if (error) {
                    console.error("Database insertion error:", error);
                    return callback({
                        code: responseCode.OPERATION_FAILED,
                        message: "Failed to Update user data."
                    });
                }


                console.log(user_id);
                console.log("User Update with User_name:", requestData.user_name);
                const token = "USER" + common.generateToken(4);
                if (data.is_step === '3') {
                    const updatetoken = "UPDATE tbl_device SET token=? where user_id=?";
                    conn.query(updatetoken, [token, user_id], (error, result) => {
                        if (error) {
                            console.error("Database insertion error:", error);
                            return callback({
                                code: responseCode.OPERATION_FAILED,
                                message: "Failed to Update user data."
                            });
                        }
                    });
                    console.log("Device token updated for user_id:", user_id);
                }
                return callback({
                    code: responseCode.SUCCESS,
                    message: "User Profile Complete Sucessfully.",
                });
            });
        });
    }
    // forgot password
    forgotpassword(requestData, callback) {
        console.log("Forgot Password request for user:", requestData.email || requestData.phone_no);
        const forgotpassword_query = "SELECT user_id,user_name From tbl_user where email=? OR phone_no=?";
        conn.query(forgotpassword_query, [requestData.email || null, requestData.phone_no || null], (error, result) => {
            console.log(result);
            if (error) {
                console.log("Database Error", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Database error occurred"
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    message: "Email not found."
                });
            }
            const user_id = result[0].user_id;
            console.log("User Id : ", result[0].user_id);
            common.sendOTP(user_id, requestData, callback);
        });
    }
    // Set Password
    setpassword(requestData, callback) {
        console.log("Set Password request for user:", requestData.email || requestData.phone_no);

        const checkOTPQuery = "SELECT user_id FROM tbl_otp WHERE verify_with=? AND otp=? AND is_verify='1'";

        const verifyWith = requestData.email || requestData.phone_no; // Choose the available field
        conn.query(checkOTPQuery, [verifyWith, requestData.otp], (error, result) => {
            if (error) {
                console.log("Database Error in Checking OTP Verification", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Database error occurred while checking OTP verification."
                });
            }

            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    message: "OTP not verified. Please verify OTP first."
                });
            }

            console.log("OTP Verified, proceeding to update password.");

            const user_id = result[0].user_id;
            const newpassword = md5(requestData.password); // Ensure you hash passwords

            const updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE user_id=?";

            conn.query(updatePasswordQuery, [newpassword, user_id], (error) => {
                if (error) {
                    console.log("Database Error in Updating Password", error);
                    return callback({
                        code: responseCode.OPERATION_FAILED,
                        message: "Database error occurred while updating password."
                    });
                }

                return callback({
                    code: responseCode.SUCCESS,
                    message: "Password updated successfully."
                });
            });
        });
    }

    // login
    login(requestData, callback) {
        console.log("Login request for user:", requestData.email);

        if (!requestData.email || !requestData.password) {
            return callback({
                code: responseCode.INVALID_REQUEST,
                message: "Email and password are required"
            });
        }

        const email = requestData.email;
        const password = md5(requestData.password);

        const loginQuery = "SELECT * FROM tbl_user WHERE email = ? AND password = ?";
        conn.query(loginQuery, [email, password], (error, result) => {
            console.log(result);

            if (error) {
                console.error("Database error:", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Database error occurred"
                });
            }

            else if (result.length <= 0) {
                return callback({
                    code: responseCode.NOT_REGISTERED,
                    message: "Invalid email or password"
                });
            }
            const user = result[0];
            if (user.is_step !== '3') {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    message: "Please complete OTP verification before logging in"
                });
            }
            const token = "USER" + common.generateToken(4); // Assuming it generates a secure token
            const device_token = "DEVICE" + common.generateToken(5)
            // Update device info in tbl_device
            const updateDeviceQuery = "UPDATE tbl_device SET token=?, device_token=? WHERE user_id=?";
            conn.query(updateDeviceQuery, [token, device_token, user.user_id], (deviceError, deviceResult) => {
                if (deviceError) {
                    console.error("Device update error:", deviceError);
                    return callback({
                        code: responseCode.OPERATION_FAILED,
                        message: "Failed to update device information"
                    });
                }

                console.log("Device token updated for user_id:", user.user_id);
                return callback({
                    code: responseCode.SUCCESS,
                    message: "Login Successfully"
                });
            });
        });
    }
    // get All Category
    getcategory(requestData, callback) {
        //console.log("Fetch Category : ");
        const query = "SELECT category_name,category_img from tbl_category order by category_name";
        conn.query(query, (error, result) => {
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve Data."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Post retrieved successfully.",
                data: result
            });
        });
    }
    // get post home screen
    getpost(requestData, callback) {
        //console.log("Fetch Category : ");
        const query = "SELECT u.profile_pic,u.user_name,p.post_img,p.title,p.location,DATE_FORMAT(p.creat_at, '%d %m %Y at %H : %i %p') as Date,p.total_comment,p.avg_rate FROM tbl_post as p INNER JOIN tbl_user as u on p.user_id=u.user_id ";
        conn.query(query, (error, result) => {
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve Data."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Post retrieved successfully.",
                data: result
            });
        });
    }
    // get one post detail
    getonepost(requestData, callback) {
        //console.log("Fetch Category : ");
        const query = "SELECT  p.post_img,c.category_name,p.title,p.description,p.website_url,GROUP_CONCAT(DISTINCT t.tag_name,',') as Tags ,p.total_comment,p.avg_rate,GROUP_CONCAT(DISTINCT u.user_name,' , ',DATE_FORMAT(p.creat_at, '%d %m %Y at %H : %i %p'),' , ') as Posted_by, GROUP_CONCAT( DISTINCT u.location,' , ',u.latitude,' , ',u.longitude,' , ') as Location FROM tbl_post as p INNER JOIN tbl_user as u on p.user_id=u.user_id INNER JOIN tbl_category as c on c.category_id=p.category_id INNER JOIN tbl_post_tag as pt on pt.post_id=p.post_id INNER JOIN tbl_tag AS t on pt.tag_id=t.tag_id WHERE p.post_id=?";
        conn.query(query, [requestData.post_id], (error, result) => {
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve post."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Post retrieved successfully.",
                data: result
            });
        });
    }
    getcategorypost(requestData, callback) {
        //console.log("Fetch Category : ");
        const query = "SELECT c.category_name, u.profile_pic,u.user_name,p.post_img,p.title,p.location,DATE_FORMAT(p.creat_at, '%d %m %Y at %H : %i %p') as Date,p.total_comment,p.avg_rate FROM tbl_post as p INNER JOIN tbl_user as u on p.user_id=u.user_id INNER JOIN tbl_category as c on c.category_id=p.category_id WHERE c.category_name=?"

        conn.query(query, [requestData], (error, result) => {
            //console.log(result[0])
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve post."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Post retrieved successfully.",
                data: result
            });
        });
    }
    // Post Comment
    getpostcomment(requestData, callback) {
        const query = "SELECT p.post_img,p.title,p.location,DATE_FORMAT(p.creat_at, '%d %m %Y at %H : %i %p') as Date FROM tbl_post as p WHERE p.post_id=?";
        conn.query(query, [requestData.post_id], (error, result) => {
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve post."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Post retrieved successfully.",
                data: result
            });
        });
    }
    // all comment
    getallcomment(requestData, callback) {
        const query = `SELECT u.profile_pic,u.user_name,DATE_FORMAT(pc.create_at, "%d %m %Y at %H : %i %p") as Date,pc.comment FROM tbl_post_comment as pc INNER JOIN tbl_user as u on u.user_id=pc.user_id WHERE pc.post_id=?`;
        conn.query(query, [requestData.post_id], (error, result) => {
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve post."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Post retrieved successfully.",
                data: result
            });
        });
    }
    // user profile
    userprofile(requestData, callback) {
        const query = `SELECT u.profile_pic,u.user_name,u.location ,b.name ,c.category_name,u.follower,u.following,u.description,(SELECT COUNT(*) FROM tbl_post  WHERE user_id=1 )as Post,GROUP_CONCAT(DISTINCT p.post_img,' , ')  as Post_imag FROM tbl_user as u INNER JOIN tbl_business as b on b.user_id=u.user_id INNER JOIN tbl_category as c on c.category_id=b.category_id INNER JOIN tbl_post as p on p.user_id=u.user_id WHERE u.user_id=?`;
        conn.query(query, [requestData.user_id], (error, result) => {
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve post."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Data retrieved successfully.",
                data: result
            });
        });
    }
    // filter
    filterpost(requestData, callback) {
        //console.log("Fetch Category : ");
        const query = `select c.category_id,
c.category_name,c.category_img,
p.post_img,
p.title,
date_format(p.creat_at, '%d %b, %Y at %h:%i %p') as Date,
p.description,
concat(ROUND(( 3959 * ACOS( COS( RADIANS(u.latitude) )  
		* COS( RADIANS( p.latitude ) ) 
		* COS( RADIANS( p.longitude ) - RADIANS(u.longitude) )  
		+ SIN( RADIANS(u.latitude) )  
		* SIN( RADIANS( p.latitude) ) ) ),0), " km") as Distance
from tbl_post p
inner join tbl_category c on c.category_id = p.category_id
INNER JOIN tbl_user as u on u.user_id=p.user_id
where c.category_name =?`;
        conn.query(query, [requestData], (error, result) => {
            //console.log(result[0])
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve post."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Post retrieved successfully.",
                data: result
            });
        });
    }
    savepost(requestData, callback) {
        const query = `SELECT u.profile_pic,u.user_name,p.post_img,p.title,p.location,DATE_FORMAT(p.creat_at, "%d %m %Y at %H : %i %p") as Date,p.total_comment,p.avg_rate 
FROM tbl_save as s INNER JOIN tbl_post as p on p.post_id=s.post_id INNER JOIN tbl_user as u on p.user_id=u.user_id WHERE s.user_id=?`;
        conn.query(query, [requestData.user_id], (error, result) => {
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve post."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Data retrieved successfully.",
                data: result
            });
        });
    }
    // report post
    reportpost(requestData, callback) {
        const query = `SELECT p.post_id ,u.profile_pic,u.user_name,p.post_img,p.title,p.location,DATE_FORMAT(p.creat_at, "%d %m %Y at %H : %i %p") as Date,p.total_comment,p.avg_rate 
FROM tbl_post as p INNER JOIN tbl_user as u on p.user_id=u.user_id WHERE  p.post_id not in (SELECT post_id from tbl_report WHERE user_id=?)`;
        conn.query(query, [requestData.user_id], (error, result) => {
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve post."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Data retrieved successfully.",
                data: result
            });
        });
    }
    //follower
    follower(requestData, callback) {
        const query = `SELECT u.profile_pic,u.user_name FROM tbl_follow as f INNER JOIN tbl_user as u on u.user_id=f.user_id WHERE f.user_id=?`;
        conn.query(query, [requestData.user_id], (error, result) => {
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve post."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Data retrieved successfully.",
                data: result
            });
        });
    }
    //following
    following(requestData, callback) {
        const query = `SELECT u.profile_pic,u.user_name FROM tbl_follow as f INNER JOIN tbl_user as u on u.user_id=f.follow_id WHERE f.user_id=?`;
        conn.query(query, [requestData.user_id], (error, result) => {
            if (error) {
                console.log("Database Error : ", error);
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Failed to retrieve post."
                });
            }
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    message: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCCESS,
                message: "Data retrieved successfully.",
                data: result
            });
        });
    }
    otherprofile(requestData, callback) {
        console.log(requestData.other_id, requestData.user_id);
        const other_id = requestData.other_id;
        const folowing = ("SELECT follow_id FROM tbl_follow  WHERE user_id=?");
        conn.query(folowing, requestData.user_id, (error, result) => {

            if (error) {
                console.log("Databse Error : ");
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Fail To Retrive Data"
                })

            }
            if (result <= 0) {
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    message: "Data Not Found"
                })
            }
            const followingIds = result.map(row => row.follow_id);
            if (followingIds.includes(other_id)) {
                const data =`SELECT u.profile_pic,u.user_name,u.follower,u.following,u.description,u.location, COUNT(p.post_id) as total_post,GROUP_CONCAT(p.post_img) as image FROM tbl_user as u left JOIN tbl_post as p on p.user_id=u.user_id WHERE u.user_id=?;`
                    conn.query(data, [requestData.other_id], (error, result) => {
                        console.log(result[0]);
                        if (error) {
                            console.log("operation fail", error);
                            return callback({
                                code: responseCode.OPERATION_FAILED,
                                message: "operation failed"
                            });
                        }
                        if (result <= 0) {
                            console.log("Data Not Found");
                            return callback({
                                code: responseCode.NO_DATA_FOUND,
                                message: "Data Not Found",
                                data: []
                            })
                        }
                        return callback({
                            code: responseCode.SUCESS,
                            message: "Data Retrive",
                            data: result
                        });
                    })
            } else {
                return callback({
                    code: responseCode.INACTIVE_ACCOUNT,
                    message: "you not follow this id"
                })
            }
        })

    }

}

module.exports = new UserModel();
