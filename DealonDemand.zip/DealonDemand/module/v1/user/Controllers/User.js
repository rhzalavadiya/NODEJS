const responseCode = require("../../../../utillities/response-error-code");
const constant = require("../../../../config/constant");
const common = require("../../../../utillities/common");
const userModel = require("../models/User-model");
const middleware = require("../../../../middleware/validators");
const validationRules = require("../../../../module/validation_rules");
const { request } = require("express");
const message = require("../../../../language/arbic");
const { t } = require('localizify');
class User {
    constructor() { }
    signup(req, res) {
        const request_data = req.body;
        /* if(paramValidator.signup(request_data).code==true){
             const message={
                 code:responseCode.OPERATION_FAILED,
                 message:paramValidator.signup(request_data).message
             }
             common.response(res,message);
         }*/

        // request_data.role="U";
        let message = {
            required: req.language.required,
            email: req.language.email
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.signUp
        console.log(rules)
        const valid = middleware.checkValidationRules(req,res,request_data,rules,message,keywords)
        if (valid) {
        userModel.signup(request_data, (_responseData) => {
            common.response(res,_responseData);
            //res.json(_responseData);
        });
    }
    }
    verifyOTP(req, res) {
        const request_data = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.verifyOtp
        console.log(rules)
        const valid = middleware.checkValidationRules(req,res,request_data,rules,message,keywords)
        if (valid) {
        userModel.verifyOTP(request_data, (_responseData) => {
            common.response(res,_responseData);
            //res.json(_responseData);
        });
    }
    }
    editProfile(req, res) {
        const request_data = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.editProfile
        console.log(rules)
        const valid = middleware.checkValidationRules(req,res,request_data,rules,message,keywords)
        if (valid) {
        userModel.editprofile(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    }
    forgotpassword(req, res) {
        const request_data = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.forgotPassword
        console.log(rules)
        const valid = middleware.checkValidationRules(req,res,request_data,rules,message,keywords)
        if (valid) {
        userModel.forgotpassword(request_data, (_responseData) => {
            common.response(res,_responseData);
            //res.json(_responseData);
        });
    }
    }
    setpassword(req, res) {
        const request_data = req.body;
        
        userModel.setpassword(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    login(req, res) {
        const request_data = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.login
        console.log(rules)
        const valid = middleware.checkValidationRules(req,res,request_data,rules,message,keywords)
        if (valid) {
            userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });
        }
    }
    getcategory(req, res) {
        const request_data = req.body;
        userModel.getcategory(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    getpost(req, res) {
        const request_data = req.body;
        userModel.getpost(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    getonepost(req, res) {
        const request_data = req.body;
        userModel.getonepost(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    getcategorypost(req, res) {
        const request_data = req.params.category_name;
        userModel.getcategorypost(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    getpostcomment(req, res) {
        const request_data = req.body;
        userModel.getpostcomment(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    getallcomment(req, res) {
        const request_data = req.body;
        userModel.getallcomment(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    userprofile(req, res) {
        const request_data = req.body;
        userModel.userprofile(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    filterpost(req, res) {
        const request_data = req.params.category_name;
        userModel.filterpost(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    savepost(req, res) {
        const request_data = req.body;
        userModel.savepost(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    reportpost(req, res) {
        const request_data = req.body;
        userModel.reportpost(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    follower(req, res) {
        const request_data = req.body;
        userModel.follower(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    following(req, res) {
        const request_data = req.body;
        userModel.following(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    addpost(req, res) {
        const request_data = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.addpost
        console.log(rules)
        const valid = middleware.checkValidationRules(req,res,request_data,rules,message,keywords)
        if (valid) {
        userModel.addpost(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    }
    changepassword(req, res) {
        const request_data = req.body;
        let message = {
            required: req.language.required
        }

        let keywords = {
            'passwords': t('rest_keywords_password')
        }

        const rules = validationRules.changePassword
        console.log(rules)
        const valid = middleware.checkValidationRules(req,res,request_data,rules,message,keywords)
        if (valid) {
        userModel.changepassword(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
    }
    otherprofile(req, res) {
        const request_data = req.body;
        userModel.otherprofile(request_data, (_responseData) => {
            //common.response(res,_responseData);
            res.json(_responseData);
        });
    }
}
module.exports = new User;
