const s3Baseurl="http://hlink-deep-bhaumik.s3.ap-south-1.amazonaws.com/DealsOnDemand/";
var constant={
    profile_pic:s3Baseurl+"profile_image/"
}
module.exports=constant;