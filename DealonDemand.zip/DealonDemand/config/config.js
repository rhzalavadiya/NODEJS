const env={
    server_listen:3000,
    version:"1.0.0",
    api_key:"DealonDemand",
};
module.exports=env;