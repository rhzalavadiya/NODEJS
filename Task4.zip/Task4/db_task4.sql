-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 08, 2025 at 05:53 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_task4`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_device`
--

CREATE TABLE `tbl_device` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `token` varchar(128) NOT NULL,
  `device_token` varchar(128) NOT NULL,
  `device_type` enum('Android','IOS') NOT NULL,
  `os_version` varchar(128) NOT NULL,
  `app_version` varchar(128) NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `is_delete` tinyint(4) NOT NULL DEFAULT 0,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_device`
--

INSERT INTO `tbl_device` (`id`, `user_id`, `token`, `device_token`, `device_type`, `os_version`, `app_version`, `is_active`, `is_delete`, `create_at`, `update_at`) VALUES
(1, 1, 'KdnAWowLxE6O8iRTCbZ0whMHOMNSY4zWeEEjrFGk', 'CSxRmmIMGEJ5aHy1aMFYOJppf6nT3UexcujmrqlJ', 'Android', 'Android 13', 'V1', 1, 0, '2025-04-04 12:28:17', '2025-04-04 12:28:17');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_task`
--

CREATE TABLE `tbl_task` (
  `task_id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `title` varchar(128) NOT NULL,
  `description` text NOT NULL,
  `deadline` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('Pending','In Progress','Complete') NOT NULL DEFAULT 'Pending',
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `is_delete` tinyint(4) NOT NULL DEFAULT 0,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_task`
--

INSERT INTO `tbl_task` (`task_id`, `user_id`, `title`, `description`, `deadline`, `status`, `is_active`, `is_delete`, `create_at`, `update_at`) VALUES
(1, 1, 'Create Login Page (HTML/CSS)', 'Build a responsive login page using HTML and style it with CSS. Include fields for email/username and password, and a login button.', '2025-04-07 16:27:59', 'Complete', 1, 0, '2025-04-05 09:11:18', '2025-04-05 09:11:18'),
(2, 1, 'Create Signup Page (HTML/CSS)', 'Build a signup form with fields like name, email, password, confirm password. Apply basic CSS styling.', '2025-04-07 16:14:25', 'Pending', 1, 0, '2025-04-05 09:37:34', '2025-04-05 09:37:34'),
(3, 1, 'Client-side Form Validation', 'Add JS validation to check for empty fields, valid email format, password match, etc.', '2025-04-08 23:59:59', 'Pending', 1, 0, '2025-04-05 09:39:44', '2025-04-05 09:39:44'),
(4, 1, 'Create Dashboard Page', 'Design a basic dashboard layout. Include a welcome message and navigation menu.', '2025-04-09 23:59:59', 'Pending', 1, 0, '2025-04-05 09:42:05', '2025-04-05 09:42:05'),
(5, 1, 'User Authentication Logic', 'Implement logic to simulate login/signup using local storage or simple session handling with JS', '2025-04-07 12:00:00', 'Pending', 1, 0, '2025-04-05 09:45:06', '2025-04-05 09:45:06'),
(6, 1, 'Learn React Basic', 'Learn On the w3Shcool', '2025-04-07 13:59:07', 'Pending', 1, 0, '2025-04-07 06:28:28', '2025-04-07 06:28:28'),
(7, 1, 'Create Api With Node js', 'Crete all Authentication API', '2025-04-09 11:59:59', 'Pending', 1, 0, '2025-04-07 08:12:59', '2025-04-07 08:12:59'),
(8, 1, 'Task Demo', 'This is Demo of  task', '2025-04-08 23:59:00', 'Pending', 1, 0, '2025-04-07 09:04:08', '2025-04-07 09:04:08');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_task_notes`
--

CREATE TABLE `tbl_task_notes` (
  `id` bigint(20) NOT NULL,
  `task_id` bigint(20) NOT NULL,
  `notes` text NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `is_delete` tinyint(4) NOT NULL DEFAULT 0,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_task_notes`
--

INSERT INTO `tbl_task_notes` (`id`, `task_id`, `notes`, `is_active`, `is_delete`, `create_at`, `update_at`) VALUES
(1, 1, 'done', 1, 0, '2025-04-07 10:57:59', '2025-04-07 10:57:59');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_timer`
--

CREATE TABLE `tbl_timer` (
  `id` bigint(20) NOT NULL,
  `user_id` bigint(20) NOT NULL,
  `task_id` bigint(20) NOT NULL,
  `start_time` datetime NOT NULL,
  `end_time` datetime NOT NULL,
  `total_time` time NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `is_delete` tinyint(4) NOT NULL DEFAULT 0,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_timer`
--

INSERT INTO `tbl_timer` (`id`, `user_id`, `task_id`, `start_time`, `end_time`, `total_time`, `is_active`, `is_delete`, `create_at`, `update_at`) VALUES
(1, 1, 1, '2025-04-07 16:13:14', '2025-04-07 16:13:25', '00:00:11', 1, 0, '2025-04-07 10:43:14', '2025-04-07 10:43:14'),
(2, 1, 2, '2025-04-07 16:13:40', '2025-04-07 16:14:11', '00:00:31', 1, 0, '2025-04-07 10:43:40', '2025-04-07 10:43:40'),
(3, 1, 2, '2025-04-07 16:14:18', '2025-04-07 16:14:25', '00:00:07', 1, 0, '2025-04-07 10:44:18', '2025-04-07 10:44:18'),
(4, 1, 1, '2025-04-07 16:22:41', '2025-04-07 16:23:20', '00:00:39', 1, 0, '2025-04-07 10:52:41', '2025-04-07 10:52:41'),
(5, 1, 1, '2025-04-07 16:25:05', '2025-04-07 16:26:43', '00:01:38', 1, 0, '2025-04-07 10:55:05', '2025-04-07 10:55:05'),
(6, 1, 1, '2025-04-07 16:26:51', '2025-04-07 16:27:11', '00:00:20', 1, 0, '2025-04-07 10:56:51', '2025-04-07 10:56:51'),
(7, 1, 1, '2025-04-07 16:27:17', '2025-04-07 16:27:23', '00:00:06', 1, 0, '2025-04-07 10:57:17', '2025-04-07 10:57:17'),
(8, 1, 1, '2025-04-07 16:27:47', '2025-04-07 16:27:53', '00:00:06', 1, 0, '2025-04-07 10:57:47', '2025-04-07 10:57:47');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `user_id` bigint(20) NOT NULL,
  `username` varchar(128) NOT NULL,
  `email` varchar(128) NOT NULL,
  `password` varchar(128) NOT NULL,
  `is_active` tinyint(4) NOT NULL DEFAULT 1,
  `is_delete` tinyint(4) NOT NULL DEFAULT 0,
  `create_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `update_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`user_id`, `username`, `email`, `password`, `is_active`, `is_delete`, `create_at`, `update_at`) VALUES
(1, 'rhzalavadiya', 'rupalizalavadiya22@gmail.com', 'Rupali@22', 1, 0, '2025-04-04 12:28:17', '2025-04-04 12:28:17');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_device`
--
ALTER TABLE `tbl_device`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_task`
--
ALTER TABLE `tbl_task`
  ADD PRIMARY KEY (`task_id`);

--
-- Indexes for table `tbl_task_notes`
--
ALTER TABLE `tbl_task_notes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_timer`
--
ALTER TABLE `tbl_timer`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_device`
--
ALTER TABLE `tbl_device`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_task`
--
ALTER TABLE `tbl_task`
  MODIFY `task_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_task_notes`
--
ALTER TABLE `tbl_task_notes`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tbl_timer`
--
ALTER TABLE `tbl_timer`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `user_id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
