const httpStatus = require("http-status-codes");
const con = require("../config/database");
const constant = require("../config/constant");
const responseCode = require("./responseErrorCode");
const { text } = require("express");
const cryptLib = require("cryptlib");
class Common {
    generateToken(length = 5) {
        const possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let token = "";
        for (let i = 0; i < length; i++) {
            token += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        return token;
    }
    encryptPlain(data) {
        console.log(data, 'encrption');

        return cryptLib.encrypt(JSON.stringify(data), constant.encryptionKey, constant.encryptionIV);
    }
    decryptPlain(data) {
        if (data) {
            return cryptLib.decrypt(data, constant.encryptionKey, constant.encryptionIV);
        }
        else {
            return;
        }
    }
    async SetToken(user_id) {
        try {
            const token = this.generateToken(40);
            const deviceToken = this.generateToken(40);
            const updateTokenQuery = "UPDATE tbl_device SET token=?,device_token=? WHERE user_id=? AND is_delete='0'";
            
            const result = await con.query(updateTokenQuery, [token, deviceToken,user_id]);
    
            if (result.affectedRows === 0) {
                console.log("Token not updated for user_id:", user_id);
                return null;
            }
    
            console.log("Token successfully updated:", token);
            return token;
    
        } catch (error) {
            console.error("Error in SetToken:", error);
            throw error;
        }
    }
    async checkStatus(task_id){
        const [result]=await con.query("select * from tbl_task where task_id=?",[task_id]);
        if(result[0].status==="Complete"){
            return 1;
        }
        return 0;
    }
    getDateTime() {
        const now = new Date();
    
        const options = {
            timeZone: 'Asia/Kolkata',
            year: 'numeric',
            month: '2-digit',
            day: '2-digit',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            hour12: false
        };
    
        const formatter = new Intl.DateTimeFormat('en-GB', options);
        const parts = formatter.formatToParts(now);
    
        const datePart = `${parts.find(p => p.type === 'year').value}-${parts.find(p => p.type === 'month').value}-${parts.find(p => p.type === 'day').value}`;
        const timePart = `${parts.find(p => p.type === 'hour').value}:${parts.find(p => p.type === 'minute').value}:${parts.find(p => p.type === 'second').value}`;
    
        return `${datePart} ${timePart}`;
    }
    
    getTimeDifference(startTimer, endTimer) {
        const startTime = new Date(startTimer);
        const endTime = new Date(endTimer);
        const diffMs = endTime.getTime() - startTime.getTime();
        const totalSeconds = Math.floor(diffMs / 1000);
        const hours = String(Math.floor(totalSeconds / 3600)).padStart(2, '0');
        const minutes = String(Math.floor((totalSeconds % 3600) / 60)).padStart(2, '0');
        const seconds = String(totalSeconds % 60).padStart(2, '0');
    
        return `${hours}:${minutes}:${seconds}`;
    }    
    
}
module.exports = new Common;