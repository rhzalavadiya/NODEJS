function signUp(event) {
    event.preventDefault();
    const username = document.getElementById("username");
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirm-password");

    if (username.value.trim() === "") {
        username.nextElementSibling.textContent = "Username is required.";
        return;
    }
    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email.value.trim())) {
        email.nextElementSibling.textContent = "Please enter a valid email.";
        return;
    }
    const passwordValue = password.value;
    const passwordPattern = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    if (!passwordPattern.test(passwordValue)) {
        password.nextElementSibling.textContent =
            "Password must be at least 8 characters and include an uppercase letter, a number, and a special character.";
        return;
    }
    if (password.value !== confirmPassword.value) {
        confirmPassword.nextElementSibling.textContent = "Passwords do not match.";
        return;
    }
    const myHeaders = new Headers();
    myHeaders.append("api-key", "Task4");
    myHeaders.append("Content-Type", "application/json");

    const raw = JSON.stringify({
        "username": username.value.trim(),
        "email": email.value.trim(),
        "password": password.value,
        "confirmPassword": confirmPassword.value,
        "device_type": "Android",
        "os_version": "Android 13",
        "app_version": "V1"
    });

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow"
    };
    fetch("http://localhost:3000/v1/user/signup", requestOptions)
        .then(response => {
            if (!response.ok) {
                throw new Error("Signup failed");
            }
            return response.json(); // assuming your server sends JSON
        })
        .then(result => {
            alert("Signup successful!");
            window.location.href = "login.html"; // redirect to login
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Signup failed. Please try again.");
        });
}
function login(event) {
    event.preventDefault();
    const email = document.getElementById("email");
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirm-password");

    const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailPattern.test(email.value.trim())) {
        email.nextElementSibling.textContent = "Please enter a valid email.";
        return;
    }
    const passwordValue = password.value;
    const passwordPattern = /^(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/;

    if (!passwordPattern.test(passwordValue)) {
        password.nextElementSibling.textContent =
            "Password must be at least 8 characters and include an uppercase letter, a number, and a special character.";
        return;
    }
    if (password.value !== confirmPassword.value) {
        alert("Password and Confirm Password Not Same..")
        return;
    }
    const myHeaders = new Headers();
    myHeaders.append("api-key", "Task4");
    myHeaders.append("Content-Type", "application/json");

    const raw = JSON.stringify({
        "email": email.value.trim(),
        "password": password.value,
        "confirmPassword": confirmPassword.value,
    });

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow"
    };

    fetch("http://localhost:3000/v1/user/login", requestOptions)
        .then(response => {
            if (!response.ok) {
                throw new Error("Login failed");
            }
            return response.json(); // assuming your server sends JSON
        })
        .then(result => {
            localStorage.setItem("email", email.value.trim());
            localStorage.setItem("isLoggedIn", true);
            console.log(result);
            if (result.data.token) {
                localStorage.setItem("token", result.data.token)
            }
            alert("Login successful!");
            window.location.href = "dashbord.html"; // redirect to login
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Login failed. Please try again.");
        });
}
function logout() {
    const token = localStorage.getItem("token");
    if (!token) {
        alert("You Are Not Login....");
        window.location.href = "index.html";
    }
    const myHeaders = new Headers();
    myHeaders.append("api-key", "Task4");
    myHeaders.append("token", token);

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        redirect: "follow"
    };

    fetch("http://localhost:3000/v1/user/logout", requestOptions)
        .then((response) => response.text())
        .then((result) => {
            alert("Logout successful!");

            // Clear session
            localStorage.removeItem("token");
            localStorage.removeItem("isLoggedIn");
            localStorage.removeItem("email");
            window.location.href = "index.html";
        })
        .catch((error) => {
            console.error("Logout error:", error);
            alert("Logout failed.");
        });
}
function datevalidation() {
    const input = document.getElementById('deadline');
    const now = new Date();
    const formatted = now.toISOString().slice(0, 16); // "YYYY-MM-DDTHH:MM"
    input.min = formatted
}
function addTask(event) {
    event.preventDefault();
    const title = document.getElementById("title").value.trim();
    const description = document.getElementById("description").value.trim();
    const deadline = document.getElementById("deadline").value;
    const token = localStorage.getItem("token");
    if (!title || !description || !deadline) {
        alert("All fields are required!");
        return;
    }
    const myHeaders = new Headers();
    myHeaders.append("api-key", "Task4");
    myHeaders.append("token", token);
    myHeaders.append("Content-Type", "application/json");

    const raw = JSON.stringify({
        "title": title,
        "description": description,
        "deadline": deadline,
    });

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow"
    };

    fetch("http://localhost:3000/v1/user/addtask", requestOptions)
        .then(response => {
            if (!response.ok) {
                throw new Error("Add Task failed");
            }
            return response.json(); // assuming your server sends JSON
        })
        .then(result => {
            alert("Task Added successful!");
            document.getElementById("title").value = "";
            document.getElementById("description").value = "";
            document.getElementById("deadline").value = "";
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Adding Task failed. Please try again.");
        });
}
function displayTask() {
    const token = localStorage.getItem("token");
    const myHeaders = new Headers();
    myHeaders.append("api-key", "Task4");
    myHeaders.append("token", token);

    const requestOptions = {
        method: "GET",
        headers: myHeaders,
        redirect: "follow"
    };

    fetch("http://localhost:3000/v1/user/displaytask", requestOptions)
        .then(response => {
            if (!response.ok) {
                throw new Error("Data Cannot Be Fetched");
            }
            return response.json();
        })
        .then(result => {
            const taskContainer = document.getElementById("taskContainer");
            taskContainer.innerHTML = "";

            result.data.forEach((task) => {
                const task_id = task.task_id;
                const isCompleted = task.status === "Complete";
                const alertHandler = `alert('This task is already completed.')`;

                const isProgress = task.status === "In Progress";
                const alerthandle = `alert('This task is not Started or completed.')`;

                const statusNote = isCompleted ?
                    `<span class="completed-note">${task.status}</span>` :
                    `<span class="incomplete-note">${task.status}</span>`;

                const timeSpent = task.total_time_spent || "00:00:00";

                taskContainer.innerHTML += `
                    <div class="task">
                        <div class="task-info">
                            <div class="task-title">${task.title}</div>
                            <div class="task-description">${task.description}</div>
                            <div class="task-deadline">Deadline: ${task.deadline}</div>
                            <div class="task-completion">Status : ${statusNote}</div>
                            <div class="task-time">Time Spent: <strong>${timeSpent}</strong></div>
                        </div>
                        <div class="task-timer">
                        <div class="timer" id="timer-${task_id}">00:00:00</div>
                        <div class="task-buttons">
                            <button class="start" onclick="${isCompleted ? alertHandler : `startTime(${task_id})`}">Start</button>
                            <button class="pause" onclick="${isProgress ? `pauseTime(${task_id})` : alerthandle}">Pause</button>
                            <button class="stop" onclick="${isProgress ? `stopTime(${task_id})` : alerthandle}">Stop</button>
                        </div>
                    </div>
                `;
            });
            let timerData=JSON.parse(localStorage.getItem("timer"));
            if(timerData){
                counter(timerData.task_id,timerData.start_time);
            }
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Data Get failed. Please try again.");
        });
}
function updateStatus(task_id, status) {
    const token = localStorage.getItem("token");
    const myHeaders = new Headers();
    myHeaders.append("api-key", "Task4");
    myHeaders.append("token", token);
    myHeaders.append("Content-Type", "application/json");

    const raw = JSON.stringify({
        "task_id": task_id,
        "status": status
    });

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow"
    };

    fetch("http://localhost:3000/v1/user/updatestatus", requestOptions)
        .then((response) => response.text())
        .then((result) => console.log(result))
        .catch((error) => console.error(error));
}
function counter(task_id,time) {
    let countDownDate = new Date(time).getTime();
    let x = setInterval(function () {
        let now = new Date().getTime();
        let distance = now - countDownDate;
        let hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
        let minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
        let seconds = Math.floor((distance % (1000 * 60)) / 1000);
        let timer = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')}`;
        document.getElementById(`timer-${task_id}`).innerHTML = timer;
        if (distance < 0) {
            clearInterval(x);
        }
    }, 1000);
}
function startTime(task_id) {
    updateStatus(task_id, "In Progress");
    let countDownDate = new Date().getTime();
    localStorage.setItem("timer", JSON.stringify({ task_id: task_id, start_time: countDownDate }));
    counter(task_id, countDownDate);
}
function pauseTime(task_id) {
    updateStatus(task_id, "Pending");
    let countDownDate = new Date().getTime();
    localStorage.removeItem("timer", JSON.stringify({ task_id: task_id, start_time: countDownDate }));
    counter(task_id, countDownDate);
    
}
function stopTime(task_id) {
    const confirmStop = confirm("Are you sure you want to stop this task?");
    if (!confirmStop) return;
    updateStatus(task_id, "Complete");
    const noteText = prompt("Add a note : ");
    if (noteText && noteText.trim() !== "") {
        submitNote(task_id, noteText.trim());
    }
    let countDownDate = new Date().getTime();
    localStorage.removeItem("timer", JSON.stringify({ task_id: task_id, start_time: countDownDate }));
    counter(task_id, countDownDate);
}
function submitNote(task_id, notes) {
    const token = localStorage.getItem("token");
    const myHeaders = new Headers();
    myHeaders.append("api-key", "Task4");
    myHeaders.append("token", token);
    myHeaders.append("Content-Type", "application/json");

    const raw = JSON.stringify({
        "task_id": task_id,
        "notes": notes
    });

    const requestOptions = {
        method: "POST",
        headers: myHeaders,
        body: raw,
        redirect: "follow"
    };

    fetch("http://localhost:3000/v1/user/addnotes", requestOptions)
        .then(response => {
            if (!response.ok) {
                throw new Error("Note submission failed");
            }
            return response.json();
        })
        .then(data => {
            alert("Note added successfully!");
            displayTask();
        })
        .catch(error => {
            console.error("Error:", error);
            alert("Failed to add note.");
        });
} 
