const responseCode = require("../../../../utillities/responseErrorCode");
const constant = require("../../../../config/constant");
const common = require("../../../../utillities/common");
const userModel = require("../Models/userModel");
const middleware = require("../../../../middeleware/validators");
const validationRules = require("../../../../middeleware/validation_rules");
const { request } = require("express");
const message = require("../../../../language/arbic");
const { t } = require('localizify');
const { required } = require("../../../../language/english");

class User {
    async signUp(req, res) {
        const requestData = req.body;
        let message = { required: req.language.required };
        let keyword = { 'passwords': t('rest_leywords_password') };
        const rules = validationRules.signUp;

        console.log("=== Validation Debug ===");
        console.log("requestData:", requestData);
        console.log("rules:", rules);
        console.log("message:", message);
        console.log("keyword:", keyword);
        console.log("=========================");

        if (!rules || typeof rules !== 'object') {
            return res.status(500).json({ message: "Validation rules not defined properly." });
        }
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.signUp(requestData);
        middleware.sendResponse(req, res, response);
    }
    async login(req, res) {
        const requestData = req.body;
        let message = { required: req.language.required };
        let keyword = {};
        const rules =validationRules.login;
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;

        const response = await userModel.login(requestData);
        middleware.sendResponse(req, res, response);
    }

    async Logout(req, res) {
        let requestData = req.body || {};
        if (Object.keys(requestData).length !== 0) {
            requestData = req.body;
        }
        requestData.user_id = req.user_id;
        let message = { required: req.language.required };
        let keyword = {};
        const rules ="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.Logout(requestData);
        middleware.sendResponse(req, res, response);
    }
    async addTask(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = { required: req.language.required };
        let keyword = {};
        const rules ="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;

        const response = await userModel.addTask(requestData);
        middleware.sendResponse(req, res, response);
    }
    async displayTask(req, res) {
        let requestData = req.body || {};
        if (Object.keys(requestData).length !== 0) {
            requestData = req.body;
        }
        requestData.user_id = req.user_id;
        let message = { required: req.language.required };
        let keyword = {};
        const rules ="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.displayTask(requestData);
        middleware.sendResponse(req, res, response);
    }
    async updateTaskStatus(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = { required: req.language.required };
        let keyword = {};
        const rules ="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;

        const response = await userModel.updateTaskStatus(requestData);
        middleware.sendResponse(req, res, response);
    }
    async completionNote(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = { required: req.language.required };
        let keyword = {};
        const rules ="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;

        const response = await userModel.completionNote(requestData);
        middleware.sendResponse(req, res, response);
    }
}
module.exports = new User;