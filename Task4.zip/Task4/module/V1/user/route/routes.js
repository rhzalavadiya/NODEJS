const User=require("../Controller/User");
const customeRoute=(app)=>{
     app.post("/v1/user/signup",User.signUp);
     app.post("/v1/user/login",User.login);
     app.post("/v1/user/logout",User.Logout);
     app.post("/v1/user/addtask",User.addTask);
     app.get("/v1/user/displaytask",User.displayTask);
     app.post("/v1/user/updatestatus",User.updateTaskStatus);
     app.post("/v1/user/addnotes",User.completionNote);
}
module.exports=customeRoute;