const con = require("../../../../config/database");
const responseCode = require("../../../../utillities/responseErrorCode");
const common = require("../../../../utillities/common");
const constant = require("../../../../config/constant");
const { log, error, Console } = require("console");
const { verify } = require("crypto");
const e = require("express");
const message = require("../../../../language/english");

class UserModel {
    async signUp(requestData) {
        try {
            const {
                username, email, password, confirmPassword,
                device_type, os_version, app_version
            } = requestData;
            let userData = {
                username, email, password
            };
            console.log("Signup Request For : - ", email);
            // **Check for missing required fields**
            if (!username || !email || !password) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing required fields"
                });
            }
            const emailQuery = "SELECT * FROM tbl_user WHERE email = ? and is_delete='0'";
            const [emailExists] = await con.query(emailQuery, [email]);

            if (emailExists.length > 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Email already exists. Please use a different one.",
                    data: emailExists
                });
            }
            if (password !== confirmPassword) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Password and Confirm Password are not same....",
                    data: userData
                })
            }
            // **Insert User Data**

            const insertQuery = "INSERT INTO tbl_user SET ?";
            const [userResult] = await con.query(insertQuery, userData);
            const user_id = userResult.insertId;
            if (!userResult.insertId) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Insert User Data"
                });
            }
            console.log("User Registered With ID:", userResult.insertId);
            const deviceData = {
                user_id,
                device_type,
                device_token: common.generateToken(40),
                os_version,
                app_version
            };
            const insertDeviceQuery = "INSERT INTO tbl_device SET ?";
            await con.query(insertDeviceQuery, deviceData);

            console.log("Device Data Inserted For User ID:", user_id);

            return ({
                code: responseCode.SUCCESS,
                keyword: "Signup Successfully......",
                data: { userData, deviceData }
            });
        } catch (error) {
            console.error("Signup Error:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Signup Process Failed..."
            });
        }
    }
    async login(requestData) {
        try {
            const { email, password, confirmPassword } = requestData;
            console.log("Login request for user:", email);
            let userData = { email, password };
            if (!email || !password) {
                return ({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Email and password are required",
                });
            }
            if (password !== confirmPassword) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Password and Confirm Password are not same....",
                    data: userData
                })
            }
            const userQuery = "SELECT * FROM tbl_user WHERE email = ? AND password = ? AND is_active='1' AND  is_delete='0'";
            const [userResult] = await con.query(userQuery, [userData.email, userData.password]);

            if (!userResult || userResult.length === 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "Invalid credentials or user not registered",
                    data: userResult
                });
            }
            const { user_id } = userResult[0];
            const updateToken = await common.SetToken(user_id);
            console.log(userResult[0])
            console.log("Device token updated for user_id:", user_id);
            return ({
                code: responseCode.SUCCESS,
                keyword: "Login Successful...",
                data: {
                    user: userResult[0],
                    token: updateToken
                }
            });

        } catch (error) {
            console.error("Error during login:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred",
            });
        }
    }
    async Logout(requestData) {
        try {
            const { user_id } = requestData;
            console.log("Logout Request for : ", user_id);
            const query = "SELECT u.user_id,u.email,d.token,d.device_token FROM tbl_user as u INNER JOIN tbl_device as d on u.user_id=d.user_id WHERE u.user_id=? AND u.is_delete='0'";
            const [result] = await con.query(query, [user_id]);
            if (!result || result.length === 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            console.log("User Logout With ID:", user_id);
            const updatetoken = "UPDATE tbl_device SET token=NULL, device_token=NULL WHERE user_id=?";
            const [status] = await con.query(updatetoken, [requestData.user_id]);

            if (status.affectedRows === 0) {
                console.log("Token update failed");
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Token update failed"
                });
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "Logout Successfully",
                data: result[0]
            });
        } catch (error) {
            console.error("Database Error", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async addTask(requestData) {
        try {
            const { user_id, title, description, deadline } = requestData;
            let taskData = { user_id, title, description, deadline };

            const insertQuery = "INSERT INTO tbl_task SET ?";
            const [taskResult] = await con.query(insertQuery, taskData);
            if (!taskResult.insertId) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Insert Task Data"
                });
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "Task Added Successfully......",
                data: taskData
            });
        } catch (error) {
            console.error("Signup Error:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Signup Process Failed..."
            });
        }
    }
    async displayTask(requestData) {
        try {
            const { user_id } = requestData;
            const [result] = await con.query(`SELECT t.user_id,t.task_id,t.title,t.description,t.status,t.deadline,SEC_TO_TIME(SUM(TIME_TO_SEC(tm.total_time))) AS total_time_spent FROM tbl_task t
                LEFT JOIN  tbl_timer tm ON t.task_id = tm.task_id WHERE  t.user_id = ? GROUP BY  t.task_id`, user_id);
            if (!result || result.length === 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data Found",
                    data: userResult
                });
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "Data Get Successful...",
                data: result
            });

        } catch (error) {
            console.error("Error :", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred",
            });
        }
    }
    async updateTaskStatus(requestData) {
        try {
            const formattedDateTime = common.getDateTime();
            const { user_id, status, task_id } = requestData;
            const taskStatus = common.checkStatus(task_id);
            if (taskStatus == 1) {
                return {
                    code: responseCode.SUCCESS,
                    keyword: "Task Completed",
                    data: insertResult
                };
            }
            await con.query(
                "UPDATE tbl_task SET status='Pending' WHERE user_id=? AND status='In Progress'",
                [user_id]
            );
            if (status === "In Progress") {
                await con.query(
                    "UPDATE tbl_task SET status='In Progress' WHERE user_id=? AND task_id=? AND status='Pending'",
                    [user_id, task_id]
                );
                const [timerRows] = await con.query(
                    "SELECT * FROM tbl_timer WHERE user_id=? AND end_time IS NULL",
                    [user_id, task_id]
                );
                if (timerRows.length > 0) {

                    const timer = timerRows[0];
                    const totalTime = common.getTimeDifference(timer.start_time, formattedDateTime);
                    await con.query(
                        "UPDATE tbl_timer SET end_time=?, total_time=? WHERE id=?",
                        [formattedDateTime, totalTime, timer.id]
                    );
                }
                const timerData = {
                    user_id,
                    task_id,
                    start_time: formattedDateTime
                };

                const [insertResult] = await con.query(
                    "INSERT INTO tbl_timer SET ?",
                    [timerData]
                );

                if (insertResult.insertId) {
                    return {
                        code: responseCode.SUCCESS,
                        keyword: "Task Started",
                        data: insertResult
                    };
                }

            } else if (status === "Pending" || status === "Complete") {

                const [timerRows] = await con.query(
                    "SELECT * FROM tbl_timer WHERE user_id=? AND task_id=? AND end_time IS NULL",
                    [user_id, task_id]
                );
                if (timerRows.length > 0) {
                    const timer = timerRows[0];
                    const totalTime = common.getTimeDifference(timer.start_time, formattedDateTime);
                    await con.query(
                        "UPDATE tbl_timer SET end_time=?, total_time=? WHERE id=?",
                        [formattedDateTime, totalTime, timer.id]
                    );
                }

                const [updateResult] = await con.query(
                    "UPDATE tbl_task SET status=? WHERE user_id=? AND task_id=? AND status='In Progress'",
                    [status, user_id, task_id]
                );

                return {
                    code: responseCode.SUCCESS,
                    keyword: "Task status updated",
                    data: updateResult
                };
            }
            return {
                code: responseCode.NO_DATA_FOUND,
                keyword: "No task was updated",
                data: []
            };

        } catch (error) {
            console.error("Error:", error);
            return {
                code: responseCode.OPERATION_FAILED,
                keyword: "Task update failed",
                data: []
            };
        }
    }
    async completionNote(requestData) {
        try {
            const { user_id,task_id, notes } = requestData;
            const noteData = { task_id, notes };
            const [result] = await con.query("insert into tbl_task_notes set ?", [noteData]);
            if (!result.insertId) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Insert Note Data"
                });
            }
            await con.query(
                "UPDATE tbl_task SET status='Complete' WHERE user_id=? AND task_id=?",
                [user_id, task_id]
            );
            return ({
                code: responseCode.SUCCESS,
                keyword: "Notes Added Successfully......",
                data: { noteData }
            });
        } catch (error) {
            console.error("Error:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Failed..."
            });
        }
    }
}
module.exports = new UserModel();