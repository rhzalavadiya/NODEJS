const Validator = require('Validator');
const { default: localizify } = require('localizify');
const en = require('../language/english');
const ar = require('../language/arbic');
const hn = require('../language/hindi');
const { t } = require('localizify');
const con = require('../config/database');
const process = require('../config/config');
const message = require('../language/english');
const cryptoLib = require('cryptlib');
const { response } = require('../utillities/common');
const common = require('../utillities/common');
const bypassMethods = new Array('signup', 'login', 'verifyotp', 'forgotpassword', 'setpassword');
const middleware = {
    checkValidationRules: function (req, res, request, rules, message, keywords) {
        const v = Validator.make(request, rules, message, keywords);
        if (v.fails()) {
            const errors = v.getErrors();
            console.log(errors);

            let error = "";
            for (let key in errors) {
                error = errors[key][0];
                break;
            }
            responseData = {
                code: "0",
                message: error
            }
            res.status(200);
            res.send(responseData);
            return false;
        } else {
            return true;
        }
    },
    sendResponse: function (req, res, message) {
        this.getMessage(req.language, message, function (translateMessage) {
           
            const responseData = {
                code: message.code,
                message: translateMessage,
                data: message.data
            };
            const encryptedResponse = responseData;
            res.status(200).send(encryptedResponse);
        });
    },
    getMessage: function (language, message, callback) {
        localizify.add('en', en)
            .add('ar', ar)
            .add('hn', hn)
            .setLocale(language);
        let translateMessage = t(message.keyword);
        if (message.content) {
            Object.keys(message.content).forEach(key => {
                translateMessage = translateMessage.replace(`{${key}}`, message.content[key]);
            });
        }
        callback(translateMessage);
    },
    extractHeaderLanguage: function (req, res, callback) {
        let headerlang = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "")
            ? req.headers['accept-language'] : 'en';
        req.lang = headerlang;

        if (headerlang === 'en') {
            req.language = en;
          } else if (headerlang === 'hn') {
            req.language = hn;
          } else {
            req.language = ar;
          }

        localizify
            .add('en', en)
            .add('ar', ar)
            .add('hn', hn)
            .setLocale(req.language);

        callback();
    },

    validateApikey: function (req, res, callback) {
        try {
            const api_Key = req.headers['api-key'];
            if (api_Key != "") {

                try {
                    if (api_Key == process.apiKey) {
                        callback();
                    }
                    else {
                        res.status(401);
                        res.send("Invalid api key");
                    }
                } catch (error) {
                    console.log("error in apikey", error);

                    res.status(400);
                    res.send( "Invalid api key");
                }
            } else {
                res.status(401);
                res.send( "invalid api key");
            }
        } catch (error) {
            console.log(Error);
            res.status(401);
            res.send( "invalid api key");
        }
    },
    validateHeaderToken: async function (req, res, callback) {
        try {
            let path_data = req.path.split("/");
            if (bypassMethods.indexOf(path_data[3]) === -1) {
                const headerToken = req.headers['token'];
                if (headerToken != "") {
                    try {
                        
                        const [result] = await con.query("SELECT * FROM tbl_device as d INNER JOIN tbl_user as u ON u.user_id=d.user_id  WHERE token=? AND u.is_delete='0'", [headerToken]);
                        
                        if (result.length < 0) {
                            res.status(401);
                            res.send( responseData);

                        }
                        const userId = result[0].user_id;
                        req.user_id = userId;

                        callback();

                    } catch (error) {
                        responseData = {
                            code: '0',
                            message: 'Invalid Token Provided...'
                        }
                        res.status(401);
                        res.send( responseData);
                    }
                }
                else {
                    responseData = {
                        code: '0',
                        message: 'Invalid Token Provided...'
                    }
                    res.status(401);
                    res.send( responseData);
                }
            }
            else {
                callback();
            }
        } catch (error) {
            res.status(401);
            res.send( "Invalid Token");
        }

    },
}
module.exports = middleware;