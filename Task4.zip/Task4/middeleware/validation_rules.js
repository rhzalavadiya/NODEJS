const { signUp, login } = require("../module/V1/user/Models/userModel")

const checkValidationRules = {
    signUp:{
            username: "required",
            email: "required|email",
            password: "required|min:8",
    },
    login:{
        email: "required|email",
        password: "required|min:8",
    },
}
module.exports = checkValidationRules
