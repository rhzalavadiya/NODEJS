const express =require('express');
const cors = require("cors");
const config=require("./config/config");
const appRouting=require("./module/app_routing");
const bodyParser=require("body-parser");
let app=express();
const urlencoderParser=bodyParser.urlencoded({
    extended:true
});
app.use(express.json());
app.use(cors({ origin: 'http://127.0.0.1:5502' })); 

app.use('/',require('./middeleware/validators').extractHeaderLanguage);
app.use('/',require('./middeleware/validators').validateApikey);
app.use('/',require('./middeleware/validators').validateHeaderToken);
appRouting.v1(app);
try {
    app.listen(config.serverListen,()=>{
        console.log("Server State: Running Port : "+config.serverListen);
        
    });
} catch (error) {
    console.log("Connection Failed....");
    
}