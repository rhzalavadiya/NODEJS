var express = require('express');
const app = express();
app.use(express.json());
//Login API
app.post('/login', function (req, res) {
    var data = req.body;
    if (data.email=="jenil@gmail.com") {
        var response = {
            "code": "1",
            "message": "Sucess",
            "Data": data.email
        };
        res.send(response);
    } else {
        var response = {
            "code": "0",
            "message": "Error",
            "Data": null
        };
        res.send(response);
    }
});
//Signup API
app.post('/register', function (req, res) {
    var { name, email, password, confirmPassword, image, gender, mobile } = req.body;
    // Validate password and confirmPassword match
    if (password !== confirmPassword) {
        var response = {
            "code": "0",
            "message": "Passwords do not match",
        };
        res.send(response);
    }
    if({ name, email, password, confirmPassword, image, gender, mobile })
    {
        var response = {
            "code": "1",
            "message": "Registration successful",
            "data": {
                name: name,
                email: email,
                gender: gender,
                mobile: mobile,
                image: image,
            },
        };
        res.send(response);
    }
    else{
        var resp = {
            "code": "0",
            "message": "Error",
            "data": "Some error occured"
}
res.send(response);
}
  
});
// Find APi
app.get("/find/:placeid",(req,res)=>{
    var placeid=req.params;
    if(placeid)
    {
        var response={
            "code": "1",
            "message": "Success",
            "data": "Requested Location having Place id"
        }
        res.send(response);
    }
        else{
            var resp = {
                "code": "0",
                "message": "Error",
                "data": "Some error occured"
    }
    res.send(response);
}
});
//Place Detail Api
app.get('/getdetails',function(req,res){
    var data=req.body;
    if(data){
    var response={
        "code":"1",
        "message":"data found",
    };
        res.send(response);
    }else{
    var response={
        "code":"0",
        "message":"Data not Found"
    };
    req.send(response);
    }
    
});
// Feedback aPi
app.get('/Feedback',function(req,res){
    var data=req.body;
    if(data){
    var response={
        "code":"1",
        "message":"Data Stored",
        "Data":data.review
    };
        res.send(response);
    }else{
    var response={
        "code":"0",
        "message":"Data Failed To Stored"
    };
    req.send(response);
    }
    
});

//Add Place
app.post('/addplace', function (req, res) {
    var { placeid,placename } = req.body;
    if({ placeid,placename })
    {
        var response = {
            "code": "1",
            "message": "Add Place successful",
            "data": {
                "placeid":placeid,
                "placename":placename
            },
        };
        res.send(response);
    }
    else{
        var response = {
            "code": "0",
            "message": "Place Not Added",
        };
        res.send(response);
    }  
});
//Profile
app.get('/profile',function(req,res){
    var data=req.body;
    if(data){
    var response={
        "code":"1",
        "message":"data found",
    };
        res.send(response);
    }else{
    var response={
        "code":"0",
        "message":"Data not Found"
    };
    req.send(response);
    }
    
});
try {
    app.listen(3033);
    console.log("Connected");
} catch (error) {
    console.log("Error:", error);
}
