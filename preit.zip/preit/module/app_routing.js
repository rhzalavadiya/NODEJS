class routing{
    v1(app){
        const user=require("./V1/user/route/routes");
        const admin=require("./V1/Admin/route/route");
        user(app);
        admin(app);
    }
}
module.exports=new routing();