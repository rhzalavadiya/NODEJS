const md5 = require("md5");
const common = require("../../../../utillities/common");
const con = require("../../../../config/database");
const responseCode = require("../../../../utillities/responseErrorCode");
const { data_found } = require("../../../../language/english");
const constant = require("../../../../config/constant");
class adminModule {
    constructor() { }
    async adminLogin(requestData) {
        try {
            const { email, password, token, device_token, device_type, os_version, app_version } = requestData;
            if (!email || !password) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing required fields"
                });
            }
            const adminCheck = "SELECT id From tbl_admin WHERE email=? AND password=? AND is_delete='0' AND is_active='1'";
            const [result] = await con.query(adminCheck, [email, md5(password)])
            if (result.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Admin Data Found"
                })
            }
            const adminDevice = {
                admin_id: result[0].id,
                token: common.generateToken(20),
                device_token: common.generateToken(20),
                device_type, os_version, app_version
            }
            const [checkAdmin] = await con.query("SELECT * FROM tbl_admin_device WHERE admin_id=?", [result[0].id]);
            if (checkAdmin.length > 0) {
                await con.query("UPDATE tbl_admin_device SET ? WHERE admin_id=?", [adminDevice, result[0].id]);
            }
            else {
                await con.query("INSERT INTO tbl_admin_device SET ? ", [adminDevice]);
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Login SucessFully",
                data: result
            })
        } catch (error) {
            return ({
                code: responseCode.NOT_REGISTER,
                keyword: "Invalid Detail..."
            })
        }
    }
    async changePassword(requestData) {
        try {
            const { OldPassword, NewPassword } = requestData;
            const data = {
                OldPassword: md5(OldPassword),
                NewPassword: md5(NewPassword)
            };
            if (!requestData) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing Value....."
                });
            }
            console.log("Change Password Request:", requestData.admin_id);
            const checkPasswordQuery = "SELECT * FROM tbl_admin WHERE id=? AND is_delete='0'";
            const [result] = await con.query(checkPasswordQuery, [requestData.admin_id]);
            console.log(result[0])
            if (!result || result.length === 0) {
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "User not found."
                });
            }
            const user = result[0];
            if (data.OldPassword !== user.password) {
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Old password is incorrect!"
                });
            }

            if (data.NewPassword === user.password) {
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Old password and new password cannot be the same!"
                });
            }

            const updatePasswordQuery = "UPDATE tbl_admin SET password=? WHERE id=?";
            const [updateResult] = await con.query(updatePasswordQuery, [data.NewPassword, requestData.admin_id]);
            console.log(updateResult[0]);
            if (updateResult.affectedRows === 0) {
                console.log("Password update failed");
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Password update failed"
                });
            }
            console.log("Password changed successfully for user:", requestData.user_id);
            return ({
                code: responseCode.SUCESS,
                keyword: "Password changed successfully",
                data: updateResult
            });
        } catch (error) {
            console.error("con Error", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "con error occurred."
            });
        }
    }
    async addMeal(requestData) {
        try {
            const { name, image, kcal, carbs, protein, fat, price, description, ingredients, category_id, day } = requestData;
            const mealData = {
                name, image: `${constant.imgUrl}${image}`,
                kcal, carbs, protein, fat, price, description, category_id, day
            };
            const insertMeal = "INSERT INTO tbl_meal SET ?";
            const [result] = await con.query(insertMeal, [mealData]);
            console.log("Meal Register With ID : ", result.insertId);
            let data = { ingredients }
            let ingredientsArray = data.ingredients.split(',');
            for (let i = 0; i < ingredientsArray.length; i++) {
                //console.log(ingredientsArray[i]);
                let interstdata = {
                    meal_id: result.insertId,
                    ingredient_id: ingredientsArray[i]
                };
                const [ingredientResult] = await con.query("INSERT INTO tbl_meal_ingredient SET ?", [interstdata]);
            }
            if (result.length <= 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "Meal No Register...",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Meal Register......",
                data: result
            })
        } catch (error) {
            console.log("ERROR : ", error);
            return ({
                code: responseCode.NOT_REGISTER,
                keyword: "Meal No Register...",
                data: []
            })
        }
    }
    async addSubscription(requestData) {
        try {
            const { name, duration, description } = requestData;
            if (!requestData) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing required fields",
                    data: requestData
                });
            }
            const insertQuery = "INSERT INTO tbl_subscription SET ?";
            const [result] = await con.query(insertQuery, [requestData]);
            console.log("Data Register With ID : ", result.insertId);
            if (result.length <= 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "Data No Register...",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Data Register......",
                data: result
            })
        } catch (error) {
            console.log("ERROR : ", error);
            return ({
                code: responseCode.NOT_REGISTER,
                keyword: "Data No Register...",
                data: []
            })
        }
    }
    async changeStatus(requestData) {
        try {
            const  { order_id,status }=requestData;
            //update order status
            let [result] = await con.query("update tbl_order set status=? where id=?", [status,order_id]);
            if (result.length <= 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "status is not change",
                    data: []
                })
            }
            // set notification
            let setnotifiaction = "insert into tbl_notification set ?";
            let notificationdata = {};
            let [reciver_id] = await con.query("select u.id  as id from tbl_user as u inner join tbl_order as o on o.user_id=u.id where o.id=?", [order_id]);
            notificationdata.receiver_id = reciver_id[0].id;
            
            //check status
            if (status == "InPreperation") {
                notificationdata.type = "Order Inprocess",
                    notificationdata.notification = "your order in process"
            }
            else if (status == "Out For Delivery") {
                notificationdata.type = "Order Delivery",
                    notificationdata.notification = "your order Out For Delivery"
            }
            else if (status == "Completed") {
                notificationdata.type = "Order is complete",
                    notificationdata.notification = "your order is complete"
            }
            //console.log(notificationdata);
            let [notifiaction] = await con.query(setnotifiaction, [notificationdata]);
            if (notifiaction.length <= 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Notifiaction is not sent",
                    data: []
                })
            }

            return ({
                code: responseCode.SUCESS,
                keyword: "Notifiaction is sent",
                data: notifiaction
            })

        } catch (Error) {
            console.log(Error);

            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Status is not change",
                data: []
            })
        }

    }
    async desboard(requestData){
        try{
        let data={
            total_user:await common.gettotalUser(),
            total_order: await common.gettotalorder(),
            total_pending_Order:await common.gettotalPendingOrder(),
            total_completed_orders:await common.gettotalCompletedOrder(),
            toal_subscription_plan:await common.gettotalplan()
        }
        console.log(data);
        
        if(data.length<=0){
            return ({
                code:responseCode.NO_DATA_FOUND,
                keyword:"no data found",
                data:[]
            })
        }
        else{
            return ({
                code:responseCode.SUCESS,
                keyword:"Success",
                data:data
            })
        }
    }catch(Error){
        console.log(Error);
        return ({
            code:responseCode.NO_DATA_FOUND,
            keyword:"no data found",
            data:[]
        })
        
    }
    }
}
module.exports = new adminModule();