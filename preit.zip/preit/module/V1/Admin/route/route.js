const admin=require("../Controller/Admin");
let customeRoute=(app)=>{
    app.post("/v1/admin/adminlogin",admin.adminLogin);
    app.post("/v1/admin/changepassword",admin.changePassword);
    app.post("/v1/admin/addmeal",admin.addMeal);
    app.post("/v1/admin/addsubscription",admin.addSubscription);
    app.post("/v1/admin/changestatus",admin.changeStatus);
    app.get("/v1/admin/deshboard",admin.desboard);

}
module.exports=customeRoute;