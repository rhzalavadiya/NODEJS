const adminModule = require("../Models/adminModel");
const middleware = require("../../../../middeleware/validators")
const validationRules = require("../../../../middeleware/validation_rules");
const common = require("../../../../utillities/common");
const { t } = require('localizify');
class admin {
    async adminLogin(req, res) {
        try {
            const requestData = JSON.parse(common.decryptPlain(req.body));
            let message = { required: req.language.required };
            let keyword = { 'passwords': t('rest_leywords_password') };
            const rules = validationRules.adminLogin;

            const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
            if (!valid) return;

            const response = await adminModule.adminLogin(requestData);
            middleware.sendResponse(req, res, response);
        } catch (error) {
            console.log(error);
            res.status(401);
            res.send(common.encryptPlain("Data Required.."));
        }
    }
    async changePassword(req, res) {
        const requestData = JSON.parse(common.decryptPlain(req.body));
        requestData.admin_id = req.admin_id;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = validationRules.changePassword
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await adminModule.changePassword(requestData);
        middleware.sendResponse(req, res, response);
    }
    async addMeal(req, res) {
        const requestData = JSON.parse(common.decryptPlain(req.body));
        requestData.admin_id = req.admin_id;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = validationRules.addMeal
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await adminModule.addMeal(requestData);
        middleware.sendResponse(req, res, response);
    }
    async addSubscription(req, res) {
        const requestData = JSON.parse(common.decryptPlain(req.body));
        let message = {
            required: req.language.required
        }
        let keyword = { }
        const rules = ""
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await adminModule.addSubscription(requestData);
        middleware.sendResponse(req, res, response);
    }
    async changeStatus(req, res) {
        const requestData = JSON.parse(common.decryptPlain(req.body));
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = ""
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await adminModule.changeStatus(requestData);
        middleware.sendResponse(req, res, response);
    }
    async desboard(req, res) {
        const requestData = req.body;
        if (Object.keys(requestData).length != 0) {
            requestData = JSON.parse(common.decryptPlain(req.body));
        }
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = ""
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await adminModule.desboard(requestData);
        middleware.sendResponse(req, res, response);
    }
}
module.exports = new admin();