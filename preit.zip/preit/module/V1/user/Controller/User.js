const responseCode = require("../../../../utillities/responseErrorCode");
const constant = require("../../../../config/constant");
const common = require("../../../../utillities/common");
const userModel = require("../Models/userModel");
const middleware = require("../../../../middeleware/validators");
const validationRules = require("../../../../middeleware/validation_rules");
const { request } = require("express");
const message = require("../../../../language/arbic");
const { t } = require('localizify');
const { required } = require("../../../../language/english");

class User {
    constructor() { }
    async signUp(req, res) {
        const requestData = JSON.parse(common.decryptPlain(req.body));
        let message = { required: req.language.required };
        let keyword = { 'passwords': t('rest_leywords_password') };
        const rules = validationRules.signup;

        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;

        const response = await userModel.signUp(requestData);
        middleware.sendResponse(req, res, response);
    }

    async verifyOtp(req, res) {
        const requestData = JSON.parse(common.decryptPlain(req.body));
        let message = { required: req.language.required };
        let keyword = { };
        const rules = validationRules.verifyOtp;

        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;

        const response = await userModel.verifyOtp(requestData);
        middleware.sendResponse(req, res, response);
    }

    async login(req, res) {
        try {
            const requestData = JSON.parse(common.decryptPlain(req.body));
            console.log(requestData);
            let message = { required: req.language.required };
            let keyword = { 'passwords': t('rest_leywords_password') };
            const rules = validationRules.login;
            
            const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
            if (!valid) return;

            const response = await userModel.login(requestData);
            middleware.sendResponse(req, res, response);
        } catch (error) {
            console.log(error);
            res.status(400).json(error);
        }
    }
    async completeProfile(req, res) {
         const requestData = JSON.parse(common.decryptPlain(req.body));
        requestData.id = req.user_id;
        let message = { required: req.language.required };
        let keyword = {};
        const rules = "";

        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;

        const response = await userModel.completeProfile(requestData);
        middleware.sendResponse(req, res, response);
    }
    async forgotPassword(req, res) {
         const requestData = JSON.parse(common.decryptPlain(req.body));
         console.log(requestData);
        let message = {
            required: req.language.required
        }
        let keyword = { 'passwords': t('rest_leywords_password') }
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;

        const response = await userModel.forgotPassword(requestData);
        middleware.sendResponse(req, res, response);
    }
    async setPassword(req, res) {
         const requestData = JSON.parse(common.decryptPlain(req.body));
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = ""
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;

        const response = await userModel.setPassword(requestData);
        middleware.sendResponse(req, res, response);
    }
    async changePassword(req, res) {
         const requestData = JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = validationRules.changePassword
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.changePassword(requestData);
        middleware.sendResponse(req, res, response);
    }
    async mealDetails(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules=validationRules.mealDeatails;
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.mealDeatails(requestData);
        middleware.sendResponse(req, res, response);
    }
    async allMeal(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.allMeal(requestData);
        middleware.sendResponse(req, res, response);
    }
    async addCart(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.addCart(requestData);
        middleware.sendResponse(req, res, response);
    }
    async getSubscription(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.getSubscription(requestData);
        middleware.sendResponse(req, res, response);
    }
    async placeOrder(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.placeOrder(requestData);
        middleware.sendResponse(req, res, response);
    }
    async displayKcalry(req,res){
        const requestData=req.body;
        if (Object.keys(requestData).length != 0) {
            requestData = JSON.parse(common.decryptPlain(req.body));
        }
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.displayKcalry(requestData);
        middleware.sendResponse(req, res, response);
    }
    async displayOrderDetail(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.displayOrderDetail(requestData);
        middleware.sendResponse(req, res, response);
    }
    async displayOrder(req,res){
        const requestData=req.body;
        if (Object.keys(requestData).length != 0) {
            requestData = JSON.parse(common.decryptPlain(req.body));
        }
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.displayOrder(requestData);
        middleware.sendResponse(req, res, response);
    }
    async displayAddress(req,res){
        const requestData=req.body;
        if (Object.keys(requestData).length != 0) {
            requestData = JSON.parse(common.decryptPlain(req.body));
        }
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.displayAddress(requestData);
        middleware.sendResponse(req, res, response);
    }
    async addAddress(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.addAddress(requestData);
        middleware.sendResponse(req, res, response);
    }
    async displayNotification(req,res){
        const requestData=req.body;
        if (Object.keys(requestData).length != 0) {
            requestData = JSON.parse(common.decryptPlain(req.body));
        }
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.displayNotification(requestData);
        middleware.sendResponse(req, res, response);
    }
    async displaySubscription(req,res){
        const requestData=req.body;
        if (Object.keys(requestData).length != 0) {
            requestData = JSON.parse(common.decryptPlain(req.body));
        }
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.displaySubscription(requestData);
        middleware.sendResponse(req, res, response);
    }
    async helpAndSupport(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body))
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules=validationRules.helpAndSupport;
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.helpAndSupport(requestData);
        middleware.sendResponse(req, res, response);
    }
    async contctUs(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body))
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules=validationRules.contctUs;
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.contctUs(requestData);
        middleware.sendResponse(req, res, response);
    }
    async aboutUs(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.aboutUs(requestData);
        middleware.sendResponse(req, res, response);
    }
    async tremsAndConditions(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.tremsAndConditions(requestData);
        middleware.sendResponse(req, res, response);
    }
    async privacyAndPolicy(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.privacyAndPolicy(requestData);
        middleware.sendResponse(req, res, response);
    }
    async report(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.report(requestData);
        middleware.sendResponse(req, res, response);
    }
    async Logout(req,res){
        const requestData=req.body;
        if (Object.keys(requestData).length != 0) {
            requestData = JSON.parse(common.decryptPlain(req.body));
        }
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.Logout(requestData);
        middleware.sendResponse(req, res, response);
    }
}
module.exports = new User;