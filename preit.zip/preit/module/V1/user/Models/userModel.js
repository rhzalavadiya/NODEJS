const con = require("../../../../config/database");
const responseCode = require("../../../../utillities/responseErrorCode");
const common = require("../../../../utillities/common");
const constant = require("../../../../config/constant");
const md5 = require("md5");
const { log, error, Console } = require("console");
const { verify } = require("crypto");
const e = require("express");
const { createGzip } = require("zlib");
const message = require("../../../../language/english");
const { read } = require("fs");
const { type } = require("os");
const { callbackify } = require("util");
class UserModel {
    async signUp(requestData) {
        try {
            const {
                name, email, phone_no, password, country_id,
                device_type, os_version, app_version
            } = requestData;

            console.log("Signup Request For : - ", requestData.email);

            // **Check for missing required fields**
            if (!email || !password || !phone_no || !country_id) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing required fields"
                });
            }

            // **Check if the email or phone number already exists separately**
            const emailQuery = "SELECT id FROM tbl_user WHERE email = ?";
            const [emailExists] = await con.query(emailQuery, [email]);

            if (emailExists.length > 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Email already exists. Please use a different one."
                });
            }

            const phoneQuery = "SELECT id FROM tbl_user WHERE phone_no = ?";
            const [phoneExists] = await con.query(phoneQuery, [phone_no]);

            if (phoneExists.length > 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Phone Number already exists. Please use a different one."
                });
            }

            // **Insert User Data**
            const userData = { email, phone_no, password: md5(password), country_id };
            const insertQuery = "INSERT INTO tbl_user SET ?";
            const [userResult] = await con.query(insertQuery, userData);

            if (!userResult.insertId) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Insert User Data"
                });
            }

            console.log("User Registered With ID:", userResult.insertId);
            const user_id = userResult.insertId;

            // **Insert Device Data**
            const deviceData = {
                user_id,
                device_type,
                device_token: common.generateToken(10),
                os_version,
                app_version
            };
            const insertDeviceQuery = "INSERT INTO tbl_device SET ?";
            await con.query(insertDeviceQuery, deviceData);

            console.log("Device Data Inserted For User ID:", user_id);

            // **Send OTP only for traditional signup**
            await this.sendOtp(user_id, requestData);

            return ({
                code: responseCode.SUCESS,
                keyword: "OTP Sent Successfully. Please verify to complete signup.",
                data: { user_id }
            });

        } catch (error) {
            console.error("Signup Error:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Signup Process Failed..."
            });
        }
    }

    async sendOtp(user_id, requestData) {
        try {
            const otp = common.generateOtp();
            const phone_no = requestData.phone_no;
            const country_id = requestData.country_id
            if (!phone_no) {
                throw new Error("No valid contact value provided.");
            }
            const otpData = { user_id, otp, phone_no, country_id };
            const insertOtp = "INSERT INTO tbl_otp SET ?";
            await con.query(insertOtp, otpData);
            console.log("OTP Inserted With User_id:", user_id);
            return {
                code: responseCode.SUCESS,
                keyword: "OTP sent successfully",
                data: []
            };
        } catch (error) {
            console.error("OTP Sending Error:", error);
            return {
                code: responseCode.OPERATION_FAILED,
                keyword: "Failed to send OTP"
            };
        }
    }
    async verifyOtp(requestData) {
        try {
            const { phone_no, otp } = requestData;
            if (!otp) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing Value..."
                });
            }
            console.log("Verify OTP With : ", phone_no);
            const otpQuery = "SELECT * FROM tbl_otp WHERE phone_no=? AND otp=? AND is_verify='0' AND is_delete='0'";
            const [result] = await con.query(otpQuery, [phone_no, otp]);
            if (!result || result.length === 0) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Invalid OTP...."
                });
            }
            const user_id = result[0].id;
            const updateOtpQuery = "UPDATE tbl_otp SET is_verify='1' WHERE phone_no=? AND otp=? AND is_delete='0'";
            await con.query(updateOtpQuery, [phone_no, otp]);

            const stepQuery = "SELECT is_step FROM tbl_user WHERE id=? AND is_delete='0'";
            const [stepcnt] = await con.query(stepQuery, [user_id]);

            const { is_step } = stepcnt[0];
            if (is_step < '2') {
                const updateQuery = "UPDATE tbl_user SET is_step='2' WHERE id=? AND is_delete='0'";
                await con.query(updateQuery, [user_id]);
            }
            common.SetToken(user_id);
            // const token = common.generateToken(10);
            // const updateDeviceQuery = "UPDATE tbl_device SET token = ? WHERE user_id = ? AND is_delete='0'";
            // await con.query(updateDeviceQuery, [token, user_id]);

            // console.log("Device token updated for user_id:", user_id);

            return ({
                code: responseCode.SUCESS,
                keyword: "OTP Verified Successfully",
                data: result
            });

        } catch (error) {
            console.error("OTP Verification Error:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Failed to verify OTP"
            });
        }
    }
    async completeProfile(requestData) {
        try {
            const {
                address, latitude, longitude, fitness_goal_id, gender, dob, weight, target_weight, height, activity_level
            } = requestData;
            const user_id = requestData.id;
            const stepQuery = "SELECT is_step FROM tbl_user WHERE id=? AND is_delete='0'";
            const [stepcnt] = await con.query(stepQuery, [user_id]);
            const is_step = stepcnt[0].is_step;
            if (is_step < '3') {
                const locationData = {
                    address, latitude, longitude, is_step: "3"
                }
                if (!address || !latitude || !longitude) {
                    return ({
                        code: responseCode.REQUEST_ERROR,
                        keyword: "Missing Location Value..."
                    });
                }
                const locationQuery = "UPDATE tbl_user SET ? WHERE id=? AND is_delete='0'";
                const [locationResult] = await con.query(locationQuery, [locationData, user_id]);
                const addressData = { address, latitude, longitude, user_id };
                const addressQuery = "INSERT INTO tbl_address SET ?";
                await con.query(addressQuery, [addressData]);
                return ({
                    code: responseCode.SUCESS,
                    keyword: "Location Detail Updated....",
                    data: locationResult
                })
            }
            if (is_step < '4') {
                const fitnessData = {
                    fitness_goal_id, is_step: "4"
                }
                if (!fitness_goal_id) {
                    return ({
                        code: responseCode.REQUEST_ERROR,
                        keyword: "Missing Goal Value..."
                    });
                }
                const fitnessQuery = "UPDATE tbl_user SET ? WHERE id=? AND is_delete='0'";
                const [fitnessResult] = await con.query(fitnessQuery, [fitnessData, user_id]);
                return ({
                    code: responseCode.SUCESS,
                    keyword: "Fitness Goal Detail Updated....",
                    data: fitnessResult
                })
            }
            if (is_step < '5') {
                console.log("Call other");
                const otherData = {
                    gender, dob, weight, target_weight, height, activity_level, is_step: "5"
                }
                if (!gender || !dob || !weight || !target_weight || !activity_level || !height) {
                    return ({
                        code: responseCode.REQUEST_ERROR,
                        keyword: "Missing Value..."
                    });
                }

                const otherQuery = "UPDATE tbl_user SET ? WHERE id=? AND is_delete='0'";
                const [otherResult] = await con.query(otherQuery, [otherData, user_id]);
                return ({
                    code: responseCode.SUCESS,
                    keyword: "User Deatil Update....",
                    data: otherResult
                });
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Profile Compeleted....",
            })
        } catch (error) {
            console.error("Failed To Update User Profile:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Failed To Update User Profile"
            });
        }
    }
    async login(requestData) {
        try {

            // Destructure fields from requestData
            const { email, password } = requestData;
            console.log("Login request for user:", email);

            let userQuery, userParams;
            if (!email || !password) {
                return ({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Email and password are required",
                });
            }
            const hashedPassword = md5(password);
            userQuery = "SELECT * FROM tbl_user WHERE email = ? AND password = ? AND is_delete='0'";
            userParams = [email, hashedPassword];
            const [userResult] = await con.query(userQuery, userParams);

            if (!userResult || userResult.length === 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "Invalid credentials or user not registered",
                });
            }

            const { id, is_step } = userResult[0];
            if (is_step < '2') {
                return ({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Please complete OTP verification before logging in",
                });
            }
            if (is_step < '3') {
                return ({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Please complete the Location Detail",
                });
            }
            if (is_step < '4') {
                return ({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Please complete To Set Your Goal",
                });
            }
            if (is_step < '5') {
                return ({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Please complete Your Profile First",
                });
            }

            // Generate tokens
            const token = common.generateToken(10);
            const device_token = common.generateToken(10);

            // Update device information in tbl_device
            const updateDeviceQuery = "UPDATE tbl_device SET token = ?, device_token = ? WHERE user_id = ?";
            await con.query(updateDeviceQuery, [token, device_token, id]);

            console.log("Device token updated for user_id:", id);
            return ({
                code: responseCode.SUCESS,
                keyword: "Login Successful",
                data: { id, token, device_token },
            });

        } catch (error) {
            console.error("Error during login:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred",
            });
        }
    }
    async forgotPassword(requestData) {
        try {
            const frogotPwd = "SELECT id FROM tbl_user where (email='" + requestData.emailOrPhone + "' OR phone_no='" + requestData.emailOrPhone + "') AND is_delete='0'";
            const [result] = await con.query(frogotPwd);
            console.log(result[0]);
            if (!result || result.length === 0) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Data Not Found..."
                });
            }
            const otpData = {
                otp: common.generateOtp(),
                is_verify: 0,
            }
            const updateOtp = "UPDATE tbl_otp SET ? WHERE user_id=?";
            const [otpResult] = await con.query(updateOtp, [otpData, result[0].id]);
            console.log(otpResult)
            if (otpResult.affectedRows <= 0) {
                return {
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Data Not Updated"
                };
            }

            return ({
                code: responseCode.SUCESS,
                keyword: "OTP Sent Successfully. Please verify to complete Process",
            });
        } catch (error) {
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred"
            });
        }
    }
    async setPassword(requestData,) {
        const { otp, emailOrPhone, password, confirmPassword } = requestData;
        try {
            // **Check for missing required fields**
            if (!otp || !emailOrPhone || !password || !confirmPassword) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing required fields."
                });
            }

            // **Check if password and confirm password match**
            if (password !== confirmPassword) {
                return ({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Password and Confirm Password do not match."
                });
            }
            const checkOTPQuery = "SELECT user_id FROM tbl_otp WHERE phone_no=? AND otp=? AND is_verify=1 AND is_delete='0'";
            console.log("Executing OTP verification query:", checkOTPQuery);
            const [otpResult] = await con.query(checkOTPQuery, [requestData.emailOrPhone, requestData.otp]);
            console.log("OTP Query Result:", otpResult);
            if (!otpResult || otpResult.length === 0) {
                return ({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Database Error"
                });
            }
            const user_id = otpResult[0].user_id;
            const newpassword = md5(requestData.password); // Ensure you hash passwords
            const updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE id=?";
            await con.query(updatePasswordQuery, [newpassword, user_id]);

            return ({
                code: responseCode.SUCESS,
                keyword: "Password updated successfully."
            });
        } catch (error) {
            console.error("Database Error", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async changePassword(requestData) {
        try {
            const { OldPassword, NewPassword, ConfirmPassword, user_id } = requestData;
            const data = {
                OldPassword: md5(OldPassword),
                NewPassword: md5(NewPassword),
                ConfirmPassword: md5(ConfirmPassword)
            };

            // **Check for missing fields**
            if (!OldPassword || !NewPassword || !ConfirmPassword || !user_id) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing required fields."
                });
            }

            // **Check if New Password matches Confirm Password**
            if (NewPassword !== ConfirmPassword) {
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "New password and Confirm password do not match!"
                });
            }
            console.log("Change Password Request:", requestData.user_id);
            const checkPasswordQuery = "SELECT * FROM tbl_user WHERE id=? AND is_delete='0'";
            const [result] = await con.query(checkPasswordQuery, [requestData.user_id]);

            if (!result || result.length === 0) {
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "User not found."
                });
            }
            const user = result[0];
            if (data.OldPassword !== user.password) {
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Old password is incorrect!"
                });
            }

            if (data.NewPassword === user.password) {
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Old password and new password cannot be the same!"
                });
            }

            const updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE id=?";
            const [updateResult] = await con.query(updatePasswordQuery, [data.NewPassword, requestData.user_id]);

            if (updateResult.affectedRows === 0) {
                console.log("Password update failed");
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Password update failed"
                });
            }

            console.log("Password changed successfully for user:", requestData.user_id);
            return ({
                code: responseCode.SUCESS,
                keyword: "Password changed successfully"
            });
        } catch (error) {
            console.error("Database Error", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async mealDeatails(requestData) {
        try {
            const { meal_id } = requestData;
            console.log(meal_id);
            const [result] = await con.query("SELECT m.id,m.name,m.image,m.kcal,m.carbs,m.protein,m.fat,m.price,m.description,GROUP_CONCAT( DISTINCT i.name) as Ingredients  FROM tbl_meal AS m JOIN tbl_meal_ingredient AS mi ON mi.meal_id=m.id JOIN tbl_ingredient AS i ON i.id=mi.ingredient_id WHERE m.id=?", [requestData.meal_id]);
            if (result.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data Found...",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Data Get Successfully...",
                data: result
            })
        } catch (error) {
            console.log(error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database Error",
            })
        }
    }
    async allMeal(requestData) {
        try {
            const { type, day } = requestData;
            let minResult = {};
            if (!requestData) {
                day = new Intl.DateTimeFormat('en-US', { weekday: 'long' }).format(new Date());
            }
            let id = 0;
            if (type == "Lunch") {
                id = 2;
            } else if (type == "Breakfast") {
                id = 1;
            } else if (type == "Dinner") {
                id = 3;
            }
            minResult.userDetail = await common.getUserDetails(requestData.user_id);
            const [allMeal] = await con.query("select * from tbl_meal where category_id=? and day=?", [id, requestData.day]);
            //console.log(allMeal[0]);
            minResult.allMeal = allMeal;
            console.log(minResult);
            if (allMeal.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data Found..",
                    data: allMeal
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Data Found..",
                data: minResult
            })
        } catch (error) {
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database Error",
                data: []
            })
        }
    }
    async addCart(requestData) {
        try {
            const { user_id, meal_id, qty, date } = requestData;

            // **Check if meal already exists in the cart**
            const checkCartQuery = "SELECT id, qty FROM tbl_add_cart WHERE user_id = ? AND meal_id = ? AND date=?";
            const [existingCart] = await con.query(checkCartQuery, [user_id, meal_id, date]);

            if (existingCart.length > 0) {
                // **Meal already in cart, update quantity**
                const cart_id = existingCart[0].id;
                const newQty = existingCart[0].qty + qty;

                const updateCartQuery = "UPDATE tbl_add_cart SET qty = ? WHERE id = ?";
                await con.query(updateCartQuery, [newQty, cart_id]);

                return ({
                    code: responseCode.SUCESS,
                    keyword: "Item quantity updated in cart.",
                    data: { cart_id, qty: newQty }
                });
            } else {
                // **Meal not in cart, insert new row**
                const insertCartQuery = "INSERT INTO tbl_add_cart SET ?";
                const [result] = await con.query(insertCartQuery, requestData);

                if (!result.insertId) {
                    return ({
                        code: responseCode.OPERATION_FAILED,
                        keyword: "Item not added to cart.",
                        data: []
                    });
                }

                return ({
                    code: responseCode.SUCESS,
                    keyword: "Item added to cart successfully.",
                    data: { cart_id: result.insertId, qty }
                });
            }

        } catch (error) {
            console.error("Database Error:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred.",
                data: []
            });
        }
    }
    async getSubscription(requestData) {
        try {
            const { subscription_id, user_id, expire_date } = requestData;
            const [result] = await con.query("SELECT * FROM tbl_subscription WHERE id=?", [subscription_id]);
            if (result.length > 0) {
                const month = result[0].duration; // Get duration in months
                const currentDate = new Date(); // Current date
                currentDate.setMonth(currentDate.getMonth() + month); // Add months to current date
                const subscribeData = {
                    subscription_id,
                    user_id,
                    expire_date: currentDate.toISOString().split("T")[0] // Format YYYY-MM-DD
                }
                const [subscribe] = await con.query("insert into tbl_user_subscription set ?", [subscribeData]);
                if (subscribe.length <= 0) {
                    return ({
                        code: responseCode.OPERATION_FAILED,
                        keyword: "Subscription not successfully",
                        data: subscribe
                    })
                }
                await con.query("update tbl_user set is_subscribe='1' where id=?", [requestData.user_id]);
                return ({
                    code: responseCode.SUCESS,
                    keyword: "Subscribtion comple...",
                    data: subscribe
                })
            } else {
                console.log("Subscription not found.");
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "No Data Found...",
                    data: []
                })
            }
        } catch (error) {
            console.log(error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database Error",
                data: []
            })
        }

    }
    async placeOrder(requestData) {
        try {
            const { user_id, address_id, note } = requestData
            const [subscribstatus] = await con.query("select u.is_subscribe from tbl_user as u INNER JOIN tbl_user_subscription as us WHERE us.expire_date>=CURRENT_DATE and u.id=?", [user_id]);
            if (subscribstatus[0].is_subscribe !== 1) {
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "First buy a subscription plane to place order",
                    data: []
                });
            }
            let data = {
                user_id, address_id, note
            }
            let finalResult = {};
            // order 
            const [order] = await con.query(`select DISTINCT(m.category_id),a.date from tbl_add_cart as a 
                INNER JOIN tbl_meal as m on m.id=a.meal_id where a.user_id=?` , [user_id]);
            if (order.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "Cart Is Empty...",
                    data: []
                });
            }
            console.log("Order : ", order);
            for (let i = 0; i < order.length; i++) {
                const [cart] = await con.query(
                    `SELECT user_id, meal_id, qty, date 
                     FROM tbl_add_cart as a INNER JOIN tbl_meal as m on m.id=a.meal_id
                     WHERE a.user_id = ? AND a.date = ? and m.category_id=?`, [user_id, order[i].date,order[i].category_id]);
                if (cart.length <= 0) {
                    return ({
                        code: responseCode.NO_DATA_FOUND,
                        keyword: "Cart Is Empty...",
                        data: []
                    });
                }
                let [time]=await con.query("select * from tbl_category where id=?",[order[i].category_id])
                data.time=time[0].time
                data.order_date = cart[0].date
                if (!(await common.checkitemtime(cart[0].meal_id, order[i].date))) {
                    return ({
                        code: responseCode.NOT_REGISTER,
                        keyword: "Order must be placed at least 6 hours in advance",
                        data: finalResult
                    });
                }

                const [price] = await con.query(
                    `SELECT SUM(m.price * a.qty) AS total 
                    FROM tbl_meal AS m  
                    INNER JOIN tbl_add_cart AS a ON a.meal_id = m.id 
                    WHERE a.user_id = ? AND a.date = ?`, [user_id, order[i].date]);
                
                console.log("Price : ",price);

                const distance = await common.getDistance(address_id);
                console.log("Distance : ", distance);

                data.delivery_charge = distance[0].Distance * 20;
                const grand_total = parseInt(price[0].total) + (distance[0].Distance * 20);
                data.grand_total=grand_total
                console.log("Grand Total : ",grand_total);

                const [result] = await con.query("INSERT INTO tbl_order SET ?", [data]);
                finalResult.order = result;
                if (result.length <= 0) {
                    return ({
                        code: responseCode.NOT_APPROVE,
                        keyword: "Order is not placed",
                        data: []
                    });
                }
                let sub_total = 0;
                let total_qty = 0;
                for (let item of cart) {
                    let [mealData] = await con.query("select * from tbl_meal where id=?", [item.meal_id]);
                    let price = mealData[0].price * item.qty;
                    sub_total += price;
                    total_qty += item.qty;

                    let orderDetailData = {
                        order_id: result.insertId,
                        meal_id: item.meal_id,
                        qty: item.qty,
                        price: price,
                        user_id
                    };
                    await con.query("insert into tbl_order_detail set ?", [orderDetailData]);
                }
                console.log("Sub Total : ",sub_total);
                let updateOrder = {
                    sub_total: sub_total,
                    total_qty: total_qty,
                    status: "Confirm"
                };
                await con.query("UPDATE tbl_order SET ? WHERE id = ?", [updateOrder, result.insertId]);

                await con.query(`DELETE a FROM tbl_add_cart AS a 
                    INNER JOIN tbl_meal AS m ON m.id = a.meal_id 
                    WHERE a.user_id = ? AND a.date = ?`, [user_id, order[i].date]);
            }
            const notification = {
                sender_id: 1,
                receiver_id: user_id,
                type: "Place Order",
                notification: "Your order has been placed successfully.."
            };
            await con.query("INSERT INTO tbl_notification SET ?", [notification]);

            return ({
                code: responseCode.SUCESS,
                keyword: "Order placed successfully",
                data: finalResult
            });
        } catch (error) {
            console.log(error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database Error",
                data: []
            })
        }
    }
    async displayKcalry(requestData) {
        try {
            const { user_id } = requestData;
            const [calary] = await con.query("select sum(m.kcal*o.qty) as calary from tbl_order_detail as o INNER JOIN tbl_meal as m on m.id=o.meal_id where o.user_id=? and m.day = DAYNAME(CURDATE()) GROUP BY o.user_id", [user_id]);
            if (calary.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "data is not found",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Success",
                data: calary
            })
        } catch (Error) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "data not found",
                data: []
            })
        }
    }
    async displayOrderDetail(requestData) {
        try {
            const { order_id } = requestData

            const [order] = await con.query("SELECT a.address,o.delivery_time,m.name,od.qty,o.note,o.status FROM tbl_order as o JOIN tbl_address as a on a.id=o.address_id JOIN tbl_order_detail as od on od.order_id=o.id JOIN tbl_meal as m on m.id=od.meal_id where o.id=?", [order_id]);
            //mainResult.order = order;
            if (order.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data Found",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: " Data Get ",
                data: order
            })

        } catch (Error) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "No Data Found",
                data: []
            })
        }
    }
    async displayOrder(requestData) {
        try {
            const {user_id}=requestData;
            console.log(user_id);
            let [order] = await con.query("SELECT * FROM tbl_order WHERE  user_id=?", [user_id]);
            if (order.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "not data found",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: " Data found",
                data: order
            })

        } catch (Error) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "No Data Found",
                data: []
            })
        }
    }
    async displayAddress(requestData) {
        try {
            const {user_id}=requestData;
            console.log(user_id);
            let [order] = await con.query("SELECT * FROM tbl_address WHERE  user_id=?", [user_id]);
            if (order.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "not data found",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: " Data found",
                data: order
            })

        } catch (Error) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "No Data Found",
                data: []
            })
        }
    }
    async addAddress(requestData) {
        try {
            const {user_id,address,latitude,longitude,type}=requestData
            const [result] = await con.query("insert into tbl_address set ?", [requestData]);
            if (result.length <= 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "Address Not Register...",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Address Registered....",
                data: result
            })

        } catch (Error) {
            console.log(error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Data base Error",
                data: []
            })
        }
    }
    async displayNotification(requestData) {
        try {
            const {user_id}=requestData;
            console.log(user_id);
            let [order] = await con.query("select * from tbl_notification where receiver_id=1=?", [user_id]);
            if (order.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "not data found",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: " Data found",
                data: order
            })

        } catch (Error) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "No Data Found",
                data: []
            })
        }
    }
    async displaySubscription(requestData) {
        try {
            let [order] = await con.query("SELECT * FROM tbl_subscription");
            if (order.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "not data found",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: " Data found",
                data: order
            })

        } catch (Error) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "No Data Found",
                data: []
            })
        }
    }
    async helpAndSupport(requestData) {
        try {
            const {full_name,email,phone_no,description}=requestData
            const [result] = await con.query("insert into tbl_help set ?", [requestData]);
            if (result.length <= 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "Help Not Register...",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Help Registered....",
                data: result
            })

        } catch (Error) {
            console.log(error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Data base Error",
                data: []
            })
        }
    }
    async contctUs(requestData) {
        try {
            const {first_name,last_name,email,subject,description}=requestData
            const [result] = await con.query("insert into tbl_contactus set ?", [requestData]);
            if (result.length <= 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "Not Register...",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Registered....",
                data: result
            })

        } catch (Error) {
            console.log(error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Data base Error",
                data: []
            })
        }
    }
    async aboutUs(requestData) {
        try {
            const {tag}=requestData;
            let [order] = await con.query("SELECT * FROM tbl_page_context WHERE tag=?", [tag]);
            if (order.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "not data found",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: " Data found",
                data: order
            })

        } catch (Error) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "No Data Found",
                data: []
            })
        }
    }
    async tremsAndConditions(requestData) {
        try {
            const {tag}=requestData;
            let [order] = await con.query("SELECT * FROM tbl_page_context WHERE tag=?", [tag]);
            if (order.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "not data found",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: " Data found",
                data: order
            })

        } catch (Error) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "No Data Found",
                data: []
            })
        }
    }
    async privacyAndPolicy(requestData) {
        try {
            const {tag}=requestData;
            let [order] = await con.query("SELECT * FROM tbl_page_context WHERE tag=?", [tag]);
            if (order.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "not data found",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: " Data found",
                data: order
            })

        } catch (Error) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "No Data Found",
                data: []
            })
        }
    }
    async report(requestData) {
        try {
            const {user_id,report}=requestData
            const [result] = await con.query("insert into tbl_report set ?", [requestData]);
            if (result.length <= 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: " Not Register...",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Registered....",
                data: result
            })

        } catch (Error) {
            console.log(error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Data base Error",
                data: []
            })
        }
    }
    async Logout(requestData) {
        try {
            console.log("Logout Request for : ", requestData.user_id);
            const query = "SELECT u.id,u.email,d.token,d.device_token FROM tbl_user as u INNER JOIN tbl_device as d on u.id=d.user_id WHERE u.id=? AND u.is_delete='0'";
            const [result] = await con.query(query, [requestData.user_id]);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            console.log("User Logout With ID:", result[0].user_id);
            //const user_id = result[0].user_id;
            const updatetoken = "UPDATE tbl_device SET token=NULL, device_token=NULL WHERE user_id=?";
            const [status] = await con.query(updatetoken, [requestData.user_id]);
            //console.log(status);

            if (status.affectedRows === 0) {
                console.log("Token update failed");
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Token update failed"
                });
            }
            return ({
                code: responseCode.SUCESS,
                keyword: "Logout Successfully",
                //data: result
            });
        } catch (error) {
            console.error("Database Error", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
}
module.exports = new UserModel();