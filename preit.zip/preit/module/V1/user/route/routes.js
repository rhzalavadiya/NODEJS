const User=require("../Controller/User");
const customeRoute=(app)=>{

     app.post("/v1/user/signup",User.signUp);
     app.post("/v1/user/verifyotp",User.verifyOtp);
     app.post("/v1/user/completeprofile",User.completeProfile);
     app.post("/v1/user/login",User.login);
     app.post("/v1/user/forgotpassword",User.forgotPassword);
     app.post("/v1/user/setpassword",User.setPassword);
     app.post("/v1/user/changepassword",User.changePassword);
     app.post("/v1/user/addcart",User.addCart);
     app.post("/v1/user/getsubscription",User.getSubscription);
     app.post("/v1/user/placeorder",User.placeOrder);
     app.post("/v1/user/addaddress",User.addAddress);
     app.post("/v1/user/help",User.helpAndSupport);
     app.post("/v1/user/contctus",User.contctUs);
     app.post("/v1/user/report",User.report);
     app.post("/v1/user/logout",User.Logout);

     app.get("/v1/user/mealdetail",User.mealDetails);
     app.get("/v1/user/allmeal",User.allMeal);
     app.get("/v1/user/displaykcalry",User.displayKcalry);
     app.get("/v1/user/orderdetail",User.displayOrderDetail);
     app.get("/v1/user/order",User.displayOrder);
     app.get("/v1/user/dispalyaddress",User.displayAddress);
     app.get("/v1/user/dispalynotification",User.displayNotification);
     app.get("/v1/user/dispalysubscription",User.displaySubscription);
     app.get("/v1/user/aboutus",User.aboutUs);
     app.get("/v1/user/termsandconditions",User.tremsAndConditions);
     app.get("/v1/user/privacyandpolicy",User.privacyAndPolicy);
}
module.exports=customeRoute;