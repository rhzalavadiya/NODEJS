const { adminLogin, addMeal } = require("../module/V1/Admin/Models/adminModel")
const { signup, verifyOtp, login, changePassword, mealDeatails, helpAndSupport, contctUs } = require("../module/V1/user/Models/userModel")

const checkValidationRules={
    signup:{
        name:"required",
        email:"required|email",
        phone_no:"required|min:10|regex:/^[0-9]+$/",
        password:"required|min:8|",

    },
    verifyOtp:{
        phone_no:"required|min:10|regex:/^[0-9]+$/",
        otp:"required",
    },
    login:{
        email:"required|email",
        password:"required|min:8|",
    },
    adminLogin:{
        email:"required|email",
        password:"required|min:8|",
    },
    changePassword:{
        OldPassword:"required",
        NewPassword:"required",
    },
    addMeal:{
        name: "required",
        image: "required",
        kcal: "required",
        carbs: "required",
        protein:"required",
        fat: "required",
        price:"required",
        description: "required",
        ingredients: "required",
        category_id: "required",
        day: "required",
    },
    mealDeatails:{
        meal_id:"required"
    },
    helpAndSupport:{
        full_name:"required",
        email:"required|email",
        phone_no:"required|min:10|regex:/^[0-9]+$/",
    },
    contctUs:{
        email:"required|email",
    }
}
module.exports=checkValidationRules