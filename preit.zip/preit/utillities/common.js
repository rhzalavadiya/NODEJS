const httpStatus=require("http-status-codes");
const con=require("../config/database");
const constant=require("../config/constant");
const responseCode=require("./responseErrorCode");
const { text }=require("express");

const cryptLib=require("cryptlib");
class common{
    response(res,message){
        //res.status(statusCode); statusCode=httpStatus.OK0
        res.json(this.encryptPlain(message));
        //res.json(message);
    }
    generateOtp(){
        return Math.floor(1000+ + Math.random()* 9000).toString();
    }
    generateToken(length=5){
        const possible="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let token="";
        for(let i=0;i<length;i++){
            token+=possible.charAt(Math.floor(Math.random()*possible.length));
        }
        return token;
    }
    getPaginationData(requestData) {
        let page = requestData<= 0 ? 1 : requestData;
        const limit = constant.itemPerPage;
        const start = (page - 1) * constant.itemPerPage;
        return [start,limit] ;
    }
    encryptPlain(data){
        console.log(data,'encrption');
        
        return cryptLib.encrypt(JSON.stringify(data),constant.encryptionKey,constant.encryptionIV);
    }
    decryptPlain(data){        
        if(data){
            return cryptLib.decrypt(data,constant.encryptionKey,constant.encryptionIV);
        }
        else{
            return ;
        }
    }
    SetToken(user_id) {
        let tokan = this.generateToken(10);
        let updatetokan = "update tbl_device set token=? where user_id=?";

        con.query(updatetokan, [tokan, user_id], (error, result) => {
            if (error) {
                console.log("operation faild", error);
            }
            if (result <= 0) {
                console.log("token in not generated");
            }
            console.log("token generated");

        })
    }
    async getStepCount(user_id) {
        let [result] = await con.query("select * from tbl_user where id=?", [user_id]);
        if (result.length <= 0) {
            return 0;
        }
        return result[0].is_step;
    }
    async mealDetails(meal_id) {
        let [result] = await con.query("select * from tbl_meal where id=? and is_delete='0'", [meal_id]);
        //console.log(result);
        let [time] = await con.query("select * from tbl_category where id=? and is_delete='0'", [result[0].category_id]);
        //console.log(time);
        //console.log(time[0].time);

        let hours = await this.timeDiffrence(time[0].time);
        //console.log(hours);

        if (hours > 6) {
            return true;
        }
        else {
            return false;
        }
    }
    async timeDifference(time, day) {
        const now = new Date();
        const [hours, minutes, seconds] = time.split(':').map(Number);

        const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];

        const currentDayIndex = now.getDay(); // 0-6 (Sunday-Saturday)
        const targetDayIndex = daysOfWeek.indexOf(day);

        if (targetDayIndex === -1) {
            throw new Error("Invalid day name. Use full day names, e.g., 'Monday'.");
        }

        // Calculate days to add to reach the next target weekday
        let daysToAdd = targetDayIndex - currentDayIndex;
        if (daysToAdd <= 0) {
            daysToAdd += 7; // Move to the next week's target day
        }

        // Set the future date to the next "targetDayName"
        const givenDate = new Date(now);
        givenDate.setDate(now.getDate() + daysToAdd);

        givenDate.setHours(hours, minutes, seconds, 0);

        const diffMilliseconds = givenDate - now;

        const diffHours = Math.floor(diffMilliseconds / (1000 * 60 * 60));
        const diffDays = Math.floor(diffMilliseconds / (1000 * 60 * 60 * 24));
        console.log(diffDays);

        return {
            days: diffDays,
            hours: diffHours % 24,

        };
    }
    async checkitemtime(meal_id,date){
        console.log(meal_id);
        
        let[result]=await con.query("select * from tbl_meal as m inner join tbl_category as c on c.id=m.category_id where m.id=?",[meal_id]);
        let difference= await this.getTimeDifferenc(date,result[0].time);
        console.log(difference);
        if(difference.hours>6|| difference.day>1){
            return true
        }
        return false
        
    }
    async getTimeDifferenc(date,time) {
        const targetDate = new Date(date); // Your specific date
        const currentTime = new Date(); // Current date and time
        const [hours, minutes, seconds] = time.split(':').map(Number); // Extract time parts

        targetDate.setHours(hours, minutes, seconds || 0, 0); 
        
        console.log(`Merged DateTime: ${targetDate}`);
        const diffMs =  targetDate.getTime()-currentTime.getTime(); // Difference in milliseconds
        const diffSeconds = Math.floor(diffMs / 1000);
        const diffMinutes = Math.floor(diffSeconds / 60);
        const diffHours = Math.floor(diffMinutes / 60);
        const diffDays = Math.floor(diffHours / 24);

        return {
            day: diffDays,
            hours: diffHours
        }

    }
    async getUserDetails(user_id){
        let [result]=await con.query("select * from tbl_user where id=?",[user_id]);
        if(result.length<=0){
            return [];
        }
        return result;
    }
    async getDistance(address_id){
        const [result]=await con .query("SELECT ROUND((6371 * ACOS(COS(RADIANS(latitude)) * COS(RADIANS(23.010864058150997)) * COS(RADIANS(72.5134746920629) - RADIANS(longitude)) + SIN(RADIANS(latitude)) * SIN(RADIANS(23.010864058150997)))), 1) AS Distance FROM tbl_address WHERE id=?",[address_id]);
        if(result.length<=0){
            return [];
        }
        return result;
    }
    async gettotalUser() {
        let [result] = await con.query("select count(*) as total_users from tbl_user");
        if (result <= 0) {
            return 0;
        }
        return result;
    }
    async gettotalorder() {
        let [result] = await con.query("select count(*) as total_orders from tbl_order");
        if (result <= 0) {
            return 0;
        }
        return result;
    }
    async gettotalplan() {
        let [result] = await con.query("select count(*)as total_plan from tbl_subscription");
        if (result <= 0) {
            return 0;
        }
        return result;
    }
    async gettotalPendingOrder() {
        let [result] = await con.query("select count(*) as pendingOrders from tbl_order where status not like'Completed'");
        if (result <= 0) {
            return 0;
        }
        return result;
    }
    async gettotalCompletedOrder() {
        let [result] = await con.query("select count(*)as completedOrders from tbl_order where status  like'Completed'");
        if (result <= 0) {
            return 0;
        }
        return result;
    }
    async autoPlaceOrder() {
        const CurrentTime = new Date();
        const currentDate = new Date().toISOString().split('T')[0];
        console.log("Current Date:", currentDate);
        let [time] = await con.query("select DISTINCT(time),id from tbl_order where order_date=?", [currentDate]);
        for(let i=0;i<time.length;i++){
        const [targetHours, targetMinutes, targetSeconds] = time[i].time.split(':').map(Number);
        const targetDate = new Date();
        targetDate.setHours(targetHours, targetMinutes, targetSeconds, 0);
            
        // Get time difference in milliseconds
        const diffMs = targetDate - CurrentTime;
        const diffMinutes = Math.floor(diffMs / (1000 * 60)) % 60;

        if(diffMinutes<=30 && diffMinutes>0){
            
            await con.query("update tbl_order set status='Out For Delivery' where time=? and order_date=?",[time[i].time,currentDate]);
        }
        if(CurrentTime==targetDate ||diffMinutes<=0){
           let[update] =await database.query("update tbl_order set status='Completed' where time=? and order_date=?",[time[i].time,currentDate]);
            console.log(update);
        }
        //console.log(diffMinutes);
        }
    }
   /* async ExpiredSubscriptions() {
        try {
            const[user_id]=await con.query("SELECT user_id FROM tbl_user_subscription WHERE expire_date=CURRENT_DATE");
            const query = `UPDATE tbl_user SET is_subscribe = 0 WHERE id=?`;
            const [result] = await connection.execute(query,[user_id]);
            console.log(`Updated ${result.affectedRows} rows.`);
        } catch (error) {
            console.error('Error updating expired subscriptions:', error);
        }
    }*/
} 
module.exports= new common;