const encryptLib=require("cryptlib");
const constant={
    itemPerPage:3,
    imgUrl:"https://www.image.com/meal/",
    encryptionKey:encryptLib.getHashSha256("xza548sa3vcr641b5ng5nhy9mlo64r6k",32),
    encryptionIV:"5ng5nhy9mlo64r6k",
    apiKey:"Preit",
}
module.exports = constant;