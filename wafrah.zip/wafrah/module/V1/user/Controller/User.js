const responseCode = require("../../../../utillities/responseErrorCode");
const constant = require("../../../../config/constant");
const common = require("../../../../utillities/common");
const userModel = require("../Models/userModel");
const middleware = require("../../../../middeleware/validators");
const validationRules = require("../../../../middeleware/validation_rules");
const { request } = require("express");
const message = require("../../../../language/arbic");
const { t } = require('localizify');
const { required } = require("../../../../language/english");

class User {
    async signUp(req, res) {
        const requestData = JSON.parse(common.decryptPlain(req.body));
        let message = { required: req.language.required };
        let keyword = { 'passwords': t('rest_leywords_password') };
        const rules = validationRules.signup;
        //const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.signUp(requestData);
        middleware.sendResponse(req, res, response);
    }

    async login(req, res) {
        const requestData = JSON.parse(common.decryptPlain(req.body));
        let message = { required: req.language.required };
        let keyword = {};
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;

        const response = await userModel.login(requestData);
        middleware.sendResponse(req, res, response);
    }
    async addCart(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.addCart(requestData);
        middleware.sendResponse(req, res, response);
    }
    async placeOrder(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.placeOrder(requestData);
        middleware.sendResponse(req, res, response);
    }
    async productDetail(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.productDetail(requestData);
        middleware.sendResponse(req, res, response);
    }
    async displayProduct(req,res){
        const requestData=req.body;
        if (Object.keys(requestData).length != 0) {
            requestData = JSON.parse(common.decryptPlain(req.body));
        }
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.displayProduct(requestData);
        middleware.sendResponse(req, res, response);
    }
    async displayOrder(req,res){
        const requestData=req.body;
        if (Object.keys(requestData).length != 0) {
            requestData = JSON.parse(common.decryptPlain(req.body));
        }
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.displayOrder(requestData);
        middleware.sendResponse(req, res, response);
    }
    async filterProduct(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.filterProduct(requestData);
        middleware.sendResponse(req, res, response);
    }
    async searchProduct(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.searchProduct(requestData);
        middleware.sendResponse(req, res, response);
    }
    async displayOrdersDetail(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.displayOrdersDetail(requestData);
        middleware.sendResponse(req, res, response);
    }
    async displayStoreDetail(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.displayStoreDetail(requestData);
        middleware.sendResponse(req, res, response);
    }
    async addRate(req,res){
        const requestData=JSON.parse(common.decryptPlain(req.body));
        requestData.user_id = req.user_id;
        let message={
            required:req.language.required
        }
        let keyword={}
        const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword);
        if (!valid) return;
        const response = await userModel.addRate(requestData);
        middleware.sendResponse(req, res, response);
    }
}
module.exports = new User;