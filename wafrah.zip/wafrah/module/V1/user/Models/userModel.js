const con = require("../../../../config/database");
const responseCode = require("../../../../utillities/responseErrorCode");
const common = require("../../../../utillities/common");
const constant = require("../../../../config/constant");
const md5 = require("md5");
const { log, error, Console } = require("console");
const { verify } = require("crypto");
const e = require("express");
const { createGzip } = require("zlib");
const message = require("../../../../language/english");
const { read } = require("fs");
const { type } = require("os");
//const { callbackify } = require("util");
class UserModel {
    async signUp(requestData) {
        try {
            const {
                name, email, phone_no, password, confirmPassword, country_id, profile_picture,
                address, latitude, longitude, company, country, state, city, postal_code,
                login_type, social_id,
                device_type, os_version, app_version
            } = requestData;
            let insertQuery = "";
            let userData = {};
            if (login_type === 'G' || login_type === 'F') {
                console.log("Signup Request For : - ", social_id);
                userData = {
                    name, email, phone_no, password: null, country_id,
                    profile_picture: `${constant.imgUrl}${profile_picture}`, login_type, social_id
                };
                insertQuery = "INSERT INTO tbl_user SET ?";
            }
            else {
                userData = {
                    name, email, phone_no, password: md5(password), country_id,
                    profile_picture: `${constant.imgUrl}${profile_picture}`, social_id: null
                };
                console.log("Signup Request For : - ", email);
                // **Check for missing required fields**
                if (!name || !email || !password || !phone_no || !country_id) {
                    return ({
                        code: responseCode.REQUEST_ERROR,
                        keyword: "Missing required fields"
                    });
                }
                const emailQuery = "SELECT * FROM tbl_user WHERE email = ? and is_delete='0'";
                const [emailExists] = await con.query(emailQuery, [email]);

                if (emailExists.length > 0) {
                    return ({
                        code: responseCode.OPERATION_FAILED,
                        keyword: "Email already exists. Please use a different one.",
                        data: emailExists
                    });
                }

                const phoneQuery = "SELECT * FROM tbl_user WHERE phone_no = ? and is_delete='0'";
                const [phoneExists] = await con.query(phoneQuery, [phone_no]);

                if (phoneExists.length > 0) {
                    return ({
                        code: responseCode.OPERATION_FAILED,
                        keyword: "Phone Number already exists. Please use a different one.",
                        data: phoneExists
                    });
                }
                if (md5(password) !== md5(confirmPassword)) {
                    return ({
                        code: responseCode.OPERATION_FAILED,
                        keyword: "Password and Confirm Password are not same....",
                        data: userData
                    })
                }
                // **Insert User Data**

                insertQuery = "INSERT INTO tbl_user SET ?";
            }
            const [userResult] = await con.query(insertQuery, userData);
            const user_id = userResult.insertId;
            const addressData = { user_id, address, latitude, longitude, company, postal_code, country, state, city };
            const [insertAddress] = await con.query("INSERT INTO tbl_address SET ?", addressData)
            if (!userResult.insertId || !insertAddress.insertId) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Insert User Data"
                });
            }

            console.log("User Registered With ID:", userResult.insertId);


            // **Insert Device Data**
            const deviceData = {
                user_id,
                device_type,
                device_token: common.generateToken(40),
                os_version,
                app_version
            };
            const insertDeviceQuery = "INSERT INTO tbl_device SET ?";
            await con.query(insertDeviceQuery, deviceData);

            console.log("Device Data Inserted For User ID:", user_id);

            return ({
                code: responseCode.SUCCESS,
                keyword: "Signup Successfully......",
                data: userData
            });
        } catch (error) {
            console.error("Signup Error:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Signup Process Failed..."
            });
        }
    }
    async login(requestData) {
        try {
            const { email, password, login_type, social_id } = requestData;
            console.log("Login request for user:", email || social_id);
            let userQuery, userResult;
            let userData = {};
            if (login_type === "G" || login_type === "F") {
                userData = { social_id, login_type };
                console.log(userData);
                if (!social_id) {
                    return ({
                        code: responseCode.INVALID_REQUEST,
                        keyword: "Social ID is required for social login",
                    });
                }
                userQuery = "SELECT * FROM tbl_user WHERE social_id = ? AND login_type = ? AND is_delete='0'";
                [userResult] = await con.query(userQuery, [userData.social_id, userData.login_type]);
            } else {
                userData = { email, password: md5(password) };
                if (!email || !password) {
                    return ({
                        code: responseCode.INVALID_REQUEST,
                        keyword: "Email and password are required",
                    });
                }
                userQuery = "SELECT * FROM tbl_user WHERE email = ? AND password = ? AND is_delete='0'";
                [userResult] = await con.query(userQuery, [userData.email, userData.password]);
            }
            if (!userResult || userResult.length === 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "Invalid credentials or user not registered",
                    data: userResult
                });
            }
            const { user_id } = userResult[0];
            common.SetToken(user_id);
            console.log("Device token updated for user_id:", user_id);
            return ({
                code: responseCode.SUCCESS,
                keyword: "Login Successful...",
                data: userResult,
            });

        } catch (error) {
            console.error("Error during login:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred",
            });
        }
    }
    async displayProduct(requestData) {
        try {
            const { user_id } = requestData;
            let finalResult = {};
            let [storeDetail] = await con.query("SELECT store_id,store_img,name,avg_rate FROM tbl_store")
            finalResult.StoreDetail = storeDetail;
            let [topDeals] = await con.query("SELECT ( SELECT GROUP_CONCAT( pi.image) FROM tbl_product_image as pi where pi.product_id=p.id ) AS Image,p.name,p.price,CASE WHEN EXISTS (select 1 FROM tbl_like where both_id=p.id and user_id=? AND role='Product')THEN 'Liked' ELSE 'Not Liked' end as LikeStatus FROM tbl_product AS p  ORDER BY p.avg_rate DESC", [user_id]);
            finalResult.TopDeals = topDeals;
            let [trending] = await con.query("SELECT ( SELECT GROUP_CONCAT( pi.image) FROM tbl_product_image as pi where pi.product_id=p.id ) AS Image,p.name,p.price,CASE WHEN EXISTS (select 1 FROM tbl_like where both_id=p.id and user_id=? AND role='Product')THEN 'Liked' ELSE 'Not Liked' end as LikeStatus FROM tbl_product AS p  ORDER BY p.avg_rate DESC", [user_id]);
            finalResult.Trending = trending;
            let [newArival] = await con.query("SELECT ( SELECT GROUP_CONCAT( pi.image) FROM tbl_product_image as pi where pi.product_id=p.id ) AS Image,p.name,p.price,CASE WHEN EXISTS (select 1 FROM tbl_like where both_id=p.id and user_id=? AND role='Product')THEN 'Liked' ELSE 'Not Liked' end as LikeStatus FROM tbl_product AS p  ORDER BY p.create_at DESC", [user_id]);
            finalResult.NewArival = newArival;
            let [bestSell] = await con.query("SELECT ( SELECT GROUP_CONCAT( pi.image) FROM tbl_product_image as pi where pi.product_id=p.id ) AS Image,p.name,p.price,CASE WHEN EXISTS (select 1 FROM tbl_like where both_id=p.id and user_id=? AND role='Product')THEN 'Liked' ELSE 'Not Liked' end as LikeStatus FROM tbl_product AS p ORDER BY (SELECT COUNT(*) FROM tbl_oder_item as oi WHERE oi.product_id=p.id) DESC", [user_id]);
            finalResult.BestSell = bestSell;
            return ({
                code: responseCode.SUCCESS,
                keyword: "Data Get Successful...",
                data: finalResult,
            });
        } catch (error) {
            console.error("Error during login:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred",
            });
        }
    }
    async addCart(requestData) {
        try {
            const { user_id, product_id, qty, size, type, comment } = requestData;
            const checkCartQuery = "SELECT id, qty FROM tbl_add_to_cart WHERE user_id = ? AND product_id = ?";
            const [existingCart] = await con.query(checkCartQuery, [user_id, product_id]);

            if (existingCart.length > 0) {
                // **Meal already in cart, update quantity**
                const cart_id = existingCart[0].id;
                const newQty = existingCart[0].qty + qty;

                const updateCartQuery = "UPDATE tbl_add_to_cart SET qty = ? WHERE id = ?";
                await con.query(updateCartQuery, [newQty, cart_id]);

                return ({
                    code: responseCode.SUCCESS,
                    keyword: "Item quantity updated in cart.",
                    data: { cart_id, qty: newQty }
                });
            }
            else {
                const insertCartQuery = "INSERT INTO tbl_add_to_cart SET ?";
                const [result] = await con.query(insertCartQuery, requestData);

                if (!result.insertId) {
                    return ({
                        code: responseCode.OPERATION_FAILED,
                        keyword: "Item not added to cart.",
                        data: []
                    });
                }

                return ({
                    code: responseCode.SUCCESS,
                    keyword: "Item added to cart successfully.",
                    data: result
                });
            }

        } catch (error) {
            console.error("Database Error:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred.",
                data: []
            });
        }
    }
    async placeOrder(requestData) {
        try {
            let finalResult = {};
            const { user_id, card_id, payment_type, payment_status, address_id, tax, coupon_id, delivery_charge } = requestData;
            let couponPrice;

            let orderData = {
                user_id, order_no: common.generateOrderNo(),
                card_id, payment_type, payment_status,
                address_id, tax, coupon_id, delivery_charge
            }

            let [cart] = await con.query("SELECT * FROM tbl_add_to_cart WHERE user_id=? AND is_delete='0'", [user_id]);
            if (cart.length === 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "Cart is empty, order not placed",
                    data: cart
                });
            }
            let [couponDetail] = await con.query("SELECT * FROM tbl_cupon WHERE expire_date>=CURRENT_DATE AND id=?", [coupon_id]);
            if (couponDetail.length !== 0) {
                couponPrice = couponDetail[0].price;
                orderData.coupon_id = couponDetail[0].id;
            }
            else {
                couponPrice = 0;
                orderData.coupon_id = 0;
            }
            let [subtotal] = await con.query("SELECT SUM(p.price * a.qty) AS total,SUM(a.qty) AS totalQty  FROM tbl_product AS p  INNER JOIN tbl_add_to_cart AS a ON a.product_id = p.id WHERE a.user_id = ? AND a.is_delete='0'", [user_id]);
            let subTotal = subtotal[0].total;
            orderData.sub_total = subTotal;

            let Qty = subtotal[0].totalQty;
            orderData.total_qty = Qty;

            orderData.total_price = subTotal + tax + delivery_charge - couponPrice;

            const [result] = await con.query("INSERT INTO tbl_order SET ?", [orderData]);
            finalResult.Order = result;
            if (result.length <= 0) {
                return ({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Order is not placed",
                    data: []
                });
            }
            console.log(result.insertId);
            let orderId = result.insertId;
            for (let item of cart) {
                let [productData] = await con.query("select * from tbl_product where id=?", [item.product_id]);
                let price = productData[0].price * item.qty;
                let orderDetailData = {
                    order_id: result.insertId,
                    product_id: item.product_id,
                    qty: item.qty,
                    price: price,
                    size: item.size,
                    type: item.type,
                    comment: item.comment,
                    user_id
                };
                await con.query("insert into tbl_oder_item set ?", [orderDetailData]);
            }
            await con.query(`DELETE FROM tbl_add_to_cart WHERE user_id = ? `, [user_id]);
            await con.query("UPDATE tbl_order SET status='Order Placed' WHERE id=?", [orderId]);
            const notification = {
                sender_id: 1,
                receiver_id: user_id,
                type: "Place Order",
                meassge: "Your order has been placed successfully.."
            };
            await con.query("INSERT INTO tbl_notification SET ?", [notification]);

            return ({
                code: responseCode.SUCCESS,
                keyword: "Order placed successfully",
                data: finalResult
            });
        } catch (error) {
            console.error("Database Error:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred.",
                data: []
            });
        }
    }
    async productDetail(requestData) {
        try {
            const { product_id } = requestData;
            let ProductDetail = {};
            let [result] = await con.query(`SELECT ( SELECT GROUP_CONCAT( pi.image) FROM tbl_product_image as pi where pi.product_id=p.id ) AS Image,p.name,p.price,
                CASE WHEN EXISTS (select 1 FROM tbl_like where both_id=p.id and user_id=1 AND role='Product')THEN 'Liked' ELSE 'Not Liked' end as LikeStatus,description 
                FROM tbl_product AS p  WHERE p.id=?`, [product_id])
            ProductDetail.productData = {
                ProductImage: result[0].Image,
                ProductName: result[0].name,
                ProductPrice: result[0].price,
                ProductLike: result[0].LikeStatus
            };

            let [sizeResult] = await con.query("SELECT size FROM tbl_size WHERE sub_cat_id IN(SELECT 1 FROM tbl_product as p WHERE p.id=?)", [product_id]);
            ProductDetail.sizeDetail = {
                Size: sizeResult
            };
            ProductDetail.Description = {
                ProductDescription: result[0].description
            };
            let [additional] = await con.query("SELECT feature,designer,style,climate,material FROM tbl_additional_info WHERE product_id=?", [product_id]);
            ProductDetail.AdditionalInfo = {
                Feature: additional[0].feature,
                Designer: additional[0].designer,
                Style: additional[0].style,
                Climate: additional[0].climate,
                Material: additional[0].material
            }
            let [storeResult] = await con.query("SELECT name,store_img,description FROM tbl_store WHERE store_id =(SELECT store_id FROM tbl_product WHERE id=?)", [product_id]);
            ProductDetail.StoreDetail = storeResult;

            let [suggest] = await con.query(`SELECT ( SELECT GROUP_CONCAT( pi.image) FROM tbl_product_image as pi where pi.product_id=p.id ) AS Image,p.name,p.price,
                CASE WHEN EXISTS (select 1 FROM tbl_like where both_id=p.id and user_id=1 AND role='Product')THEN 'Liked' ELSE 'Not Liked' end as LikeStatus 
                FROM tbl_product AS p  WHERE p.sub_category_id IN (SELECT sub_category_id FROM tbl_product WHERE id=1)`, [product_id]);
            ProductDetail.Suggested = suggest;
            return ({
                code: responseCode.SUCCESS,
                keyword: "Data Get Successful...",
                data: ProductDetail,
            });
        } catch (error) {
            console.error("Error during login:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred",
            });
        }
    }
    async filterProduct(requestData) {
        const { user_id, price, category_id, sub_category_id, avg_rate } = requestData;
        let data = {};
        let filterQuery = `SELECT ( SELECT GROUP_CONCAT( pi.image) FROM tbl_product_image as pi where pi.product_id=p.id ) AS Image,p.name,p.price,
        CASE WHEN EXISTS (select 1 FROM tbl_like where both_id=p.id and user_id=? AND role='Product')THEN 'Liked' ELSE 'Not Liked' end as LikeStatus FROM 
        tbl_product AS p WHERE p.price BETWEEN 0 AND ? AND p.category_id IN (?) AND p.sub_category_id IN (?) AND p.avg_rate>=?`;

        data.price = (price === 0) ? 1000 : price
        data.category_id = (category_id === 0) ? [1, 2, 3] : category_id;
        data.sub_category_id = (sub_category_id === 0) ? [1, 2, 3, 4, 5, 6, 7] : sub_category_id
        data.avg_rate = (avg_rate === 0.0) ? 0 : avg_rate

        const [result] = await con.query(filterQuery, [user_id, data.price, data.category_id, data.sub_category_id, data.avg_rate]);
        if (result.length == 0) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "Data Not Found...",
                data: result
            });
        }
        return ({
            code: responseCode.SUCCESS,
            keyword: "Data Get Successful...",
            data: result,
        });
    }
    async searchProduct(requestData) {
        try {
            const { user_id, type, search } = requestData;
            let serchquery = '';
            let [serchResult] = '';
            const [result] = await con.query("SELECT search FROM tbl_search where user_id=? AND type=?", [user_id, type]);
            if (result.length === 0) {
                await con.query("INSERT INTO tbl_search SET ?", [requestData]);
                if (type === 'Product') {
                    serchquery = `SELECT ( SELECT GROUP_CONCAT( pi.image) FROM tbl_product_image as pi where pi.product_id=p.id ) AS Image,p.name,p.price,
                    CASE WHEN EXISTS (select 1 FROM tbl_like where both_id=p.id and user_id=? AND role='Product')THEN 'Liked' ELSE 'Not Liked' end as LikeStatus FROM 
                    tbl_product AS p WHERE p.name LIKE '%?%'`;
                }
                else {
                    serchquery = `SELECT ( SELECT GROUP_CONCAT( pi.image) FROM tbl_product_image as pi where pi.product_id=p.id ) AS Image,p.name,p.price,
                    CASE WHEN EXISTS (select 1 FROM tbl_like where both_id=p.id and user_id=? AND role='Product')THEN 'Liked' ELSE 'Not Liked' end as LikeStatus FROM 
                    tbl_product AS p WHERE p.store_id IN(SELECT store_id FROM tbl_store WHERE name LIKE '%?%');`
                }
                [serchResult] = await con.query(serchResult, [user_id, search]);
                if (serchResult.length === 0) {
                    return ({
                        code: responseCode.NO_DATA_FOUND,
                        keyword: "Data Not Found...",
                        data: serchResult
                    });
                }
                return ({
                    code: responseCode.SUCCESS,
                    keyword: "Data Get Successful...",
                    data: serchResult,
                });
            }
            else {
                return ({
                    code: responseCode.SUCCESS,
                    keyword: "Serch History is",
                    data: result,
                });
            }
        } catch (error) {
            console.error("Error :", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred",
            });
        }
    }
    async displayOrder(requestData) {
        try {
            const { user_id } = requestData;
            let [order] = await con.query("SELECT * FROM tbl_order WHERE  user_id=?", [user_id]);
            if (order.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data Found",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: " Data Get Sucessfully",
                data: order
            })

        } catch (Error) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "No Data Found",
                data: []
            })
        }
    }
    async displayOrdersDetail(requestData) {
        const { user_id, order_id, prroduct_id } = requestData
        let mainresult = {};
        let [result] = await con.query("SELECT a.address ,o.sub_total,o.tax,o.total_price,o.delivery_charge,o.total_qty FROM tbl_order as o INNER JOIN tbl_address as a on a.id=o.address_id INNER JOIN tbl_oder_item as oi on oi.order_id=o.id where o.id=? ", [order_id]);
        mainresult.orderDetails = result;
        let [result1] = await con.query("SELECT o.* ,(SELECT GROUP_CONCAT(p.image) FROM tbl_product_image as p WHERE p.product_id=o.product_id) as product_image FROM tbl_oder_item as o WHERE o.order_id=?;", [order_id]);
        mainresult.productInfo = result1;
        if (mainresult.length <= 0) {
            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "No Data Found",
                data: []
            })
        }
        return ({
            code: responseCode.SUCCESS,
            keyword: " Data Found",
            data: mainresult
        })
    }
    async displayStoreDetail(requestData) {
        try {
            const { store_id } = requestData
            let [result] = await con.query("select * from tbl_store WHERE store_id=?", store_id);
            if (result.length <= 0) {
                return ({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "Data Not Found",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "Success",
                data: result
            })
        } catch (Error) {
            console.log(Error);

            return ({
                code: responseCode.NO_DATA_FOUND,
                keyword: "Data Not Found ",
                data: []
            })
        }
    }
    async addRate(requestData) {
            try {
                const { user_id,product_id,rate,review } =requestData
                let [result] = await con.query("insert into tbl_rate set ?", [requestData]);
                if (result.length <= 0) {
                    return ({
                        code: responseCode.NOT_REGISTER,
                        keyword: "rating is not register",
                        data: []
                    })
                }
                let [count] = await con.query("select avg(rate) as rate,count(user_id) AS review from tbl_rate where product_id=?", [product_id]);
                await con.query("update tbl_product set avg_rate=? ,total_review=? where id=?", [count[0].rate,count[0].review,product_id]);
                return ({
                    code: responseCode.SUCCESS,
                    keyword: "Success",
                    data: result
                })
            } catch (Error) {
                console.log(Error);
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "rating  and review is not register",
                    data: []
                })
            }
    
        }
}
module.exports = new UserModel();