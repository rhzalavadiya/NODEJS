const User=require("../Controller/User");
const customeRoute=(app)=>{
     app.post("/v1/user/signup",User.signUp);
     app.post("/v1/user/login",User.login);
     app.post("/v1/user/addcart",User.addCart);
     app.post("/v1/user/placeorder",User.placeOrder);
     app.post("/v1/user/addRate",User.addRate);
     app.get("/v1/user/displayproduct",User.displayProduct);
     app.get("/v1/user/productdetail",User.productDetail);
     app.get("/v1/user/filterproduct",User.filterProduct);
     app.get("/v1/user/searchproduct",User.searchProduct);
     app.get("/v1/user/displayorder",User.displayOrder);
     app.get("/v1/user/displayorderdetail",User.displayOrdersDetail);
     app.get("/v1/user/displaystoredetail",User.displayStoreDetail);
}
module.exports=customeRoute;