const httpStatus = require("http-status-codes");
const con = require("../config/database");
const constant = require("../config/constant");
const responseCode = require("./responseErrorCode");
const { text } = require("express");
const nodemailer = require('nodemailer');

const cryptLib = require("cryptlib");
class common {
    response(res, message) {
        //res.status(statusCode); statusCode=httpStatus.OK0
        res.json(this.encryptPlain(message));
        //res.json(message);
    }
    generateOtp() {
        return Math.floor(1000 + + Math.random() * 9000).toString();
    }
    generateToken(length = 5) {
        const possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let token = "";
        for (let i = 0; i < length; i++) {
            token += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        return token;
    }
    generateOrderNo() {
        const possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let orderNo = "";
        for (let i = 0; i < 8; i++) {
            orderNo += possible.charAt(Math.floor(Math.random() * possible.length));
        }
        return orderNo;
    }
    getPaginationData(requestData) {
        let page = requestData <= 0 ? 1 : requestData;
        const limit = constant.itemPerPage;
        const start = (page - 1) * constant.itemPerPage;
        return [start, limit];
    }
    encryptPlain(data) {
        console.log(data, 'encrption');

        return cryptLib.encrypt(JSON.stringify(data), constant.encryptionKey, constant.encryptionIV);
    }
    decryptPlain(data) {
        if (data) {
            return cryptLib.decrypt(data, constant.encryptionKey, constant.encryptionIV);
        }
        else {
            return;
        }
    }
    sendMail(subject, to_email, message) {
        let transporter = nodemailer.createTransport({
            service: 'gmail',
            host: 'smtp.gmail.com',
            port: 587,
            secure: false,
            auth: {
                user: constant.mailer_email,
                pass: constant.mailer_password
            }
        });
        let mailOptions = {
            from: constant.from_email,
            to: to_email,
            subject: subject,
            html: message
        };
        let info = transporter.sendMail(mailOptions);
        console.log("Email Sent  : ",info.message);
        return info;
    }
    SetToken(user_id) {
        let tokan = this.generateToken(40);
        let updatetokan = "update tbl_device set token=? where user_id=? AND is_delete='0'";

        con.query(updatetokan, [tokan, user_id], (error, result) => {
            if (error) {
                console.log("operation faild", error);
            }
            if (result <= 0) {
                console.log("token in not generated");
            }
            console.log("token generated");

        })
    }
    async getStepCount(user_id) {
        let [result] = await con.query("select * from tbl_user where user_id=? AND is_delete='0'", [user_id]);
        if (result.length <= 0) {
            return 0;
        }
        return result[0].is_step;
    }
    async displayOrdersDetails(order_id) {
        try {
            let mainresult = {};
           
            let [pod]=await database.query("select case when(o.address_id=0) then 'true' ELSE 'false' end as status from tbl_order as o where o.order_id=?",[order_id])
            let time_per_km = 4;
            let details = "";
            if (pod.status == 'true') {
                details = `select ROUND(( 6371 * ACOS( COS( RADIANS(a.latitude) ) 
                * COS( RADIANS( r.latitude ) ) * COS( RADIANS(r.longitude) 
                - RADIANS(a.longitude) ) + SIN( RADIANS(a.latitude) ) 
                * SIN( RADIANS( r.latitude ) ) ) ),1) as distance ,r.,o.,d.driver_image,o.status,d.full_name as driver_name,d.phone as driver_phone,d.avg_rate,a.address as sender_address,a.latitude as sender_latitude,a.longitude as sender_longitude from tbl_order as o  left join tbl_driver as d on o.driver_id=d.id inner join tbl_order_reciver_address as r on r.id=o.receiver_address_id INNER JOIN tbl_second_address as a on a.user_id=o.user_id WHERE o.id=?`
            } else {
                details = `select ROUND(( 6371 * ACOS( COS( RADIANS(a.latitude) ) 
                * COS( RADIANS( r.latitude ) ) * COS( RADIANS(r.longitude) 
                - RADIANS(a.longitude) ) + SIN( RADIANS(a.latitude) ) 
                * SIN( RADIANS( r.latitude ) ) ) ),1) as distance ,r.,o.,d.driver_image,o.status,d.full_name as driver_name,d.phone as driver_phone,d.avg_rate,a.address as sender_address,a.latitude as sender_latitude,a.longitude as sender_longitude from tbl_order as o  left join tbl_driver as d on o.driver_id=d.id inner join tbl_order_reciver_address as r on r.id=o.receiver_address_id INNER JOIN tbl_address as a on a.user_id=o.user_id WHERE o.id=?`
            }
            let [result] = await database.query(details,[order_id]);
            console.log(result[0]);

            let [item_details] = await database.query("select sum(oi.qty),oi.notes,oi.type from tbl_order as o inner join tbl_order_items as oi on oi.order_id=o.id where o.id=?  GROUP BY type ", [order_id]);
            let location = {
                sender_Address: result[0].sender_address,
                receiverAddress: result[0].address
            }
            let receiver_details = {
                reciver_name: result[0].full_name,
                receiver_email: result[0].email,
                reciver_phone: result[0].phone
            }
            let distanceandtime = {
                distance: result[0].distance + "km",
                time: (result[0].distance * time_per_km) + "min"
            }
            let driver_details = {
                driver_name: result[0].driver_name,
                driver_image: result[0].driver_image,
                driver_phone: result[0].driver_phone,
                driver_rating: result[0].avg_rate,
             
            }
            let order_Summary={
                date:result[0].order_date,
                sub_total:result[0].sub_total,
                pod_charge:result[0].pod,
                total:result[0].total_price
            }
            mainresult.location_Details = location;
            mainresult.reciver_Details = receiver_details;
            mainresult.item_details = item_details;
            mainresult.distance_time = distanceandtime;
            mainresult.driver_details = driver_details;
            mainresult.status=result[0].status;
            if(result[0].status=='complete'){
                mainresult.order_Summary=order_Summary;
            }
            if (mainresult.length <= 0) {
                return 0
              
            }
            return mainresult
            
        } catch (Error) {
            console.log(Error);
            return 0
                
           
        }
    }
}
module.exports = new common;