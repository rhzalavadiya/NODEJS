const Validator = require('Validator');
const { default: localizify } = require('localizify');
const en = require('../language/english');
const ar = require('../language/arbic');
const hn = require('../language/hindi');
const { t } = require('localizify');
const con = require('../config/database');
const process = require('../config/config');
const message = require('../language/english');
const cryptoLib = require('cryptlib');
const { response } = require('../utillities/common');
const common = require('../utillities/common');
const bypassMethods = new Array('signup', 'login', 'verifyotp', 'forgotpassword', 'setpassword');
const middleware = {
    checkValidationRules: function (req, res, request, rules, message, keywords) {
        const v = Validator.make(request, rules, message, keywords);
        if (v.fails()) {
            const errors = v.getErrors();
            console.log(errors);

            var error = "";
            for (var key in errors) {
                error = errors[key][0];
                break;
            }
            responseData = {
                code: "0",
                message: error
            }
            res.status(200);
            res.send(common.encryptPlain(responseData));
            return false;
        } else {
            return true;
        }
    },
    sendResponse: function (req, res, message) {
        this.getMessage(req.language, message, function (translateMessage) {
            //console.log("Data :- ", JSON.stringify(message.data, null, 2));

            const responseData = {
                code: message.code,
                message: translateMessage,
                data: message.data
            };

            const encryptedResponse = common.encryptPlain(responseData);
            res.status(200).send(encryptedResponse);
        });
    },
    getMessage: function (language, message, callback) {
        localizify.add('en', en)
            .add('ar', ar)
            .add('hn', hn)
            .setLocale(language);
        let translateMessage = t(message.keyword);
        if (message.content) {
            Object.keys(message.content).forEach(key => {
                translateMessage = translateMessage.replace(`{${key}}`, message.content[key]);
            });
        }
        callback(translateMessage);
    },
    extractHeaderLanguage: function (req, res, callback) {
        var headerlang = (req.headers['accept-language'] != undefined && req.headers['accept-language'] != "")
            ? req.headers['accept-language'] : 'en';
        req.lang = headerlang;

        req.language = (headerlang == 'en') ? en : (headerlang == 'hn') ? hn : ar;

        localizify
            .add('en', en)
            .add('ar', ar)
            .add('hn', hn)
            .setLocale(req.language);

        callback();
    },

    validateApikey: function (req, res, callback) {
        try {
            const api_Key = common.decryptPlain(req.headers['api-key']);
            // const api_Key = (req.headers['api-key'] != undefined && req.headers['api-key'] != "") ? req.headers['api-key'] : '';
            if (api_Key != "") {

                try {
                    if (api_Key == process.apiKey) {
                        callback();
                    }
                    else {
                        res.status(401);
                        res.send(common.encryptPlain("Invalid api key"));
                    }
                } catch (error) {
                    console.log("error in apikey", error);

                    res.status(400);
                    res.send(common.encryptPlain("Invalid api key"));
                }
            } else {
                res.status(401);
                res.send(common.encryptPlain("invalid api key"));
            }
        } catch (error) {
            console.log(Error);
            res.status(401);
            res.send(common.encryptPlain("invalid api key"));
        }
    },
    validateHeaderToken: async function (req, res, callback) {
        try {
            var path_data = req.path.split("/");
            if (bypassMethods.indexOf(path_data[3]) === -1) {
                const headerToken = common.decryptPlain(req.headers['token']);
                if (headerToken != "") {
                    try {
                        //console.log(headerToken);
                        const [result] = await con.query("SELECT * FROM tbl_device as d INNER JOIN tbl_user as u ON u.user_id=d.user_id  WHERE token=? AND u.is_delete='0'", [headerToken]);
                        //console.log(result[0])
                        if (result.length < 0) {
                            res.status(401);
                            res.send(common.encryptPlain(responseData));

                        }
                        const userId = result[0].user_id;
                        req.user_id = userId;
                        //console.log(req.user_id);
                        callback();

                    } catch (error) {
                        responseData = {
                            code: '0',
                            message: 'Invalid Token Provided...'
                        }
                        res.status(401);
                        res.send(common.encryptPlain(responseData));
                    }
                }
                else {
                    responseData = {
                        code: '0',
                        message: 'Invalid Token Provided...'
                    }
                    res.status(401);
                    res.send(common.encryptPlain(responseData));
                }
            }
            else {
                callback();
            }
        } catch (error) {
            res.status(401);
            res.send(common.encryptPlain("Invalid Token"));
        }

    },
}
module.exports = middleware;