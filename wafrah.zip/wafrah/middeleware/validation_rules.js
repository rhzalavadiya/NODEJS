const { signUp, verifyOtp, editProfile, forgotPassword } = require("../module/V1/user/Models/userModel")

const checkValidationRules={
    signup:{
        name:"required",
        email:"required|email",
        phone_no:"required|min:10|regex:/^[0-9]+$/",
        //password:"required|min:8|",
        address:"required",
        latitude:"required",
        longitude:"required",
        profile_picture:"required",
    },
    verifyOtp:{
        otp:"required",
    },
    forgotPassword:{
        emailorphone:"required"
    },
}
module.exports=checkValidationRules
