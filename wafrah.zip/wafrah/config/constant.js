const encryptLib=require("cryptlib");
const constant={
    itemPerPage:3,
    imgUrl:"https://www.image.com/wafrah/",
    encryptionKey:encryptLib.getHashSha256("xza548sa3vcr641b5ng5nhy9mlo64r6k",32),
    encryptionIV:"5ng5nhy9mlo64r6k",
    mailer_email:"zalavadiyarupali2202@gmail.com",
    mailer_password:"rsly fjaz orue rnsz",
    from_email: "zalavadiyarupali2202@gmail.com",
    language: "",
    host_mail: "",
}
module.exports = constant;
