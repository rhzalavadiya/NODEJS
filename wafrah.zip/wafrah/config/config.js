const env={
    serverListen:3000,
    version:"1.0.0",
    apiKey:"Wafrah",
};
module.exports=env;