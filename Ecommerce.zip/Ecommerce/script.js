function fetchProduct() {
    Promise.all([
        fetch("https://fakestoreapi.com/products").then(res => res.json())
    ]).then(([data]) => {
        const product = data.slice(0, 20); // Take first 5 products
        displayProduct(product);
    }).catch(error => {
        console.error("Error fetching products:", error);
    });
}
function displayProduct(products) {
    let productList = document.getElementById("product-list");
    productList.innerHTML = "";
    products.forEach(product => {
        productList.innerHTML += `  
        <div class="product-card">
            <img src="${product.image}" alt="${product.title}" class="product-img">
            <h3 class="product-title">${product.title}</h3>
            <p class="product-price">$${product.price}</p>
            <button class="add-to-cart" onclick="addToCart(${product.id}, '${product.title}', ${product.price})">
                Add to Cart
            </button>
        </div>`;
    });
}

function setCookie(name, value, days) {
    let expires = "";
    if (days) {
        let date = new Date();
        date.setTime(date.getTime() + (days * 24 * 60 * 60 * 1000));
        expires = "; expires=" + date.toUTCString();
    }
    document.cookie = name + "=" + encodeURIComponent(value) + expires + "; path=/";
}

function getCookie(name) {
    let cookies = document.cookie.split('; ');
    for (let cookie of cookies) {
        let [key, value] = cookie.split('=');
        if (key === name) return decodeURIComponent(value);
    }
    return "";
}

function signUp() {
    let userName = document.getElementById('username').value;
    let email = document.getElementById('email').value;
    let password = document.getElementById('password').value;
    console.log(userName, " + ", email, " + ", password);
    
    setCookie("username", userName, 7);
    setCookie("email", email, 7);
    setCookie("password", password, 7);
    
    alert("SignUp Successfully....");
    window.location.href = "login.html";
}

function login() {
    console.log("login Call");
    
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;
    console.log(email,"  + ",password);
    
    
    let storedEmail = getCookie("email");
    let storedPassword = getCookie("password");
    
    if (email === storedEmail && password === storedPassword) {
        alert("Login Successful! Welcome, " + getCookie("username"));
        window.location.href = "login.html";
    } else {
        alert("Invalid email or password. Please try again.");
        window.location.href = "index.html";

    }
}