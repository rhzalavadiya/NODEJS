const User=require("../Controller/User");
const customeRoute=(app)=>{
     app.post("/v1/user/signup",User.signUp);
     app.post("/v1/user/verifyotp",User.verifyOtp);
     app.post("/v1/user/editprofile",User.editProfile);
     app.post("/v1/user/login",User.login);
     app.post("/v1/user/forgotpassword",User.forgotPassword);
     app.post("/v1/user/setpassword",User.setPassword);
     app.post("/v1/user/createpost",User.createPost);
     app.post("/v1/user/followfollowing",User.followFollowing);
     app.get("/v1/user/allpost",User.allPost);
     app.post("/v1/user/postlike",User.postLike);
     app.post("/v1/user/postdislike",User.postDisLike);
     app.post("/v1/user/cmtdislike",User.commentDisLike);
     app.post("/v1/user/postdeletecmt",User.postDeleteComment);
     app.post("/v1/user/commentlike",User.commentLike);
     app.post("/v1/user/addcomment",User.addComment);
     app.post("/v1/user/postrepost",User.postRepost);
     app.post("/v1/user/reportpost",User.reportPost);
     app.get("/v1/user/postlikelist",User.postLikeListing);
     app.get("/v1/user/postcmtlist",User.postCommentListing);
}
module.exports=customeRoute;