const con = require("../../../../config/database");
const responseCode = require("../../../../utillities/responseErrorCode");
const common = require("../../../../utillities/common");
const constant = require("../../../../config/constant");
const md5 = require("md5");
const { log, error, Console } = require("console");
const { verify } = require("crypto");
const e = require("express");
const { createGzip } = require("zlib");
const message = require("../../../../language/english");
const { read } = require("fs");
const { type } = require("os");
//const { callbackify } = require("util");
class UserModel {
    async signUp(requestData) {
        try {
            const {
                name, username, email, phone_no, password, confirmPassword, country_code_id, terms,
                login_type, social_id, is_step,
                device_type, os_version, app_version
            } = requestData;
            let insertQuery = "";
            let userData = {};
            let sendOtpFlag = true;
            if (login_type === 'G' || login_type === 'F' || login_type === 'A') {
                console.log("Signup Request For : - ", social_id);
                userData = { login_type, social_id, is_step, terms };
                insertQuery = "INSERT INTO tbl_user SET ?";
                sendOtpFlag = false; // Do not send OTP for social login
            }
            else {
                userData = { name, username, email, phone_no, password: md5(password), country_code_id, terms };
                console.log("Signup Request For : - ", username);
                // **Check for missing required fields**
                if (!name || !username || !email || !password || !phone_no || !country_code_id || !terms) {
                    return ({
                        code: responseCode.REQUEST_ERROR,
                        keyword: "Missing required fields"
                    });
                }

                const usernameQuery = "SELECT * FROM tbl_user WHERE username = ?";
                const [usernameExists] = await con.query(usernameQuery, [username]);

                if (usernameExists.length > 0) {
                    return ({
                        code: responseCode.OPERATION_FAILED,
                        keyword: "UserName already exists. Please use a different one.",
                        data: usernameExists

                    });
                }
                const emailQuery = "SELECT * FROM tbl_user WHERE email = ?";
                const [emailExists] = await con.query(emailQuery, [email]);

                if (emailExists.length > 0) {
                    return ({
                        code: responseCode.OPERATION_FAILED,
                        keyword: "Email already exists. Please use a different one.",
                        data: emailExists
                    });
                }

                const phoneQuery = "SELECT * FROM tbl_user WHERE phone_no = ?";
                const [phoneExists] = await con.query(phoneQuery, [phone_no]);

                if (phoneExists.length > 0) {
                    return ({
                        code: responseCode.OPERATION_FAILED,
                        keyword: "Phone Number already exists. Please use a different one.",
                        data: phoneExists
                    });
                }
                if (md5(password) !== md5(confirmPassword)) {
                    return ({
                        code: responseCode.OPERATION_FAILED,
                        keyword: "Password and Confirm Password are not same....",
                        data: userData
                    })
                }
                // **Insert User Data**

                insertQuery = "INSERT INTO tbl_user SET ?";
            }
            const [userResult] = await con.query(insertQuery, userData);

            if (!userResult.insertId) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Insert User Data"
                });
            }

            console.log("User Registered With ID:", userResult.insertId);
            const user_id = userResult.insertId;

            // **Insert Device Data**
            const deviceData = {
                user_id,
                device_type,
                device_token: common.generateToken(40),
                os_version,
                app_version
            };
            const insertDeviceQuery = "INSERT INTO tbl_device SET ?";
            await con.query(insertDeviceQuery, deviceData);

            console.log("Device Data Inserted For User ID:", user_id);

            // **Send OTP only for traditional signup**
            if (sendOtpFlag) {
                await this.sendOtp(user_id, requestData);
                return ({
                    code: responseCode.SUCCESS,
                    keyword: "OTP Sent Successfully. Please verify to complete signup.",
                    data: { user_id }
                });
            } else {
                return ({
                    code: responseCode.SUCCESS,
                    keyword: "Signup successful via Social login.",
                    data: { user_id }
                });
            }
        } catch (error) {
            console.error("Signup Error:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Signup Process Failed..."
            });
        }
    }
    async sendOtp(user_id, requestData) {
        try {
            const otp = common.generateOtp();
            const emailorphone = requestData.phone_no || requestData.email || requestData.emailorphone;
            if (!emailorphone) {
                throw new Error("No valid contact value provided.");
            }
            const otpData = { user_id, otp, emailorphone };
            const insertOtp = "INSERT INTO tbl_otp SET ?";
            await con.query(insertOtp, otpData);
            console.log("OTP Inserted With User_id:", user_id);
            return {
                code: responseCode.SUcCESS,
                keyword: "OTP sent successfully"
            };
        } catch (error) {
            console.error("OTP Sending Error:", error);
            return {
                code: responseCode.OPERATION_FAILED,
                keyword: "Failed to send OTP"
            };
        }
    }
    async verifyOtp(requestData) {
        try {
            const { emailorphone, otp } = requestData;
            //console.log(requestData);
            if (!emailorphone || !otp) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing Value...",
                    data: requestData
                });
            }
            console.log("Verify OTP With : ", emailorphone);
            const otpQuery = "SELECT * FROM tbl_otp WHERE emailorphone=? AND otp=? AND is_verify='0' AND is_delete='0'";
            const [result] = await con.query(otpQuery, [requestData.emailorphone, requestData.otp]);
            //console.log(result[0]);
            const user_id = result[0].user_id;
            if (!result || result.length === 0) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Invalid OTP....",
                    data: result
                });
            }
            const updateOtpQuery = "UPDATE tbl_otp SET is_verify='1' WHERE emailorphone=? AND otp=? AND is_delete='0'";
            await con.query(updateOtpQuery, [emailorphone, otp]);
            const is_step = common.getStepCount(user_id);
            if (is_step !== '3') {
                const updateQuery = "UPDATE tbl_user SET is_step='2' WHERE user_id=? AND is_delete='0'";
                await con.query(updateQuery, [user_id]);
            }
            common.SetToken(user_id)
            console.log("Device token updated for user_id:", user_id);
            return ({
                code: responseCode.SUCCESS,
                keyword: "OTP Verified Successfully",
                data: []
            });
        } catch (error) {
            console.error("OTP Sending Error:", error);
            return {
                code: responseCode.OPERATION_FAILED,
                keyword: "Failed to verify OTP"
            };
        }
    }
    async editProfile(requestData) {
        try {
            const {
                name, is_step, profile_image, description
            } = requestData;
            const userId = requestData.user_id;
            console.log("Edit Profile For Request : ", userId);
            const status = common.getStepCount(userId);
            if (status < '2') {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Please Complete OTP Verification..."
                });
            }
            const updateData = {
                profile_image: `${constant.imgUrl}${profile_image}`,
                description, is_step: '3'
            };
            if (name !== undefined) {
                updateData.name = name;
            }

            const updateQuery = "UPDATE tbl_user SET ? WHERE user_id=? AND is_delete='0'";
            const [result] = await con.query(updateQuery, [updateData, userId]);
            if (result.affectedRows <= 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "User Profile Not Updated",
                    data: result
                });
            }
            console.log("User updated with user_id:", userId);

            return ({
                code: responseCode.SUCCESS,
                keyword: "User Profile Updated Successfully.",
                data: result
            });

        } catch (error) {
            console.error("Update Profile Error", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Failed To Update Profile..."
            });
        }
    }
    async login(requestData) {
        try {
            const { username, password, login_type, social_id } = requestData;
            console.log("Login request for user:", username || social_id);
            let userQuery, userResult;
            let userData = {};
            if (login_type === "G" || login_type === "F" || login_type === "A") {
                userData = { social_id, login_type };
                console.log(userData);
                if (!social_id) {
                    return ({
                        code: responseCode.INVALID_REQUEST,
                        keyword: "Social ID is required for social login",
                    });
                }
                userQuery = "SELECT * FROM tbl_user WHERE social_id = ? AND login_type = ? AND is_delete='0'";
                [userResult] = await con.query(userQuery, [userData.social_id, userData.login_type]);
            } else {
                userData = { username, password: md5(password) };
                if (!username || !password) {
                    return ({
                        code: responseCode.INVALID_REQUEST,
                        keyword: "username and password are required",
                    });
                }
                userQuery = "SELECT * FROM tbl_user WHERE username = ? AND password = ? AND is_delete='0'";
                [userResult] = await con.query(userQuery, [userData.username, userData.password]);
            }
            if (!userResult || userResult.length === 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "Invalid credentials or user not registered",
                });
            }
            const { user_id, is_step } = userResult[0];
            if (is_step !== '3') {
                return ({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Please complete OTP verification before logging in",
                });
            }
            common.SetToken(user_id);
            console.log("Device token updated for user_id:", user_id);
            return ({
                code: responseCode.SUCCESS,
                keyword: "Login Successful...",
                data: userResult,
            });

        } catch (error) {
            console.error("Error during login:", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred",
            });
        }
    }
    async forgotPassword(requestData) {
        try {
            if (!requestData.emailorphone) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing Value...."
                });
            }
            console.log("Forgot Password Request user  : ", requestData.emailorphone);
            const frogotPwd = "SELECT * FROM tbl_user where (email='" + requestData.emailorphone + "' OR phone_no='" + requestData.emailorphone + "') AND is_delete='0'";
            const [result] = await con.query(frogotPwd);
            //console.log(result[0].user_id);
            if (!result || result.length === 0) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Email Not Found..."
                });
            }
            // const { user_id } = result[0].user_id;
            //console.log(user_id);
            await this.sendOtp(result[0].user_id, requestData);
            return ({
                code: responseCode.SUCCESS,
                keyword: "OTP Sent Successfully. Please verify to complete Process",
            });

        } catch (error) {
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred"
            });
        }
    }
    async setPassword(requestData,) {
        const { otp, emailorphone, password } = requestData;
        try {
            // **Check for missing required fields**
            if (!otp || !emailorphone || !password) {
                return ({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing required fields."
                });
            }
            const checkOTPQuery = "SELECT * FROM tbl_otp WHERE emailorphone=? AND otp=? AND is_verify=1 AND is_delete='0'";
            const [otpResult] = await con.query(checkOTPQuery, [requestData.emailorphone, requestData.otp]);
            console.log("OTP Query Result:", otpResult);
            if (!otpResult || otpResult.length === 0) {
                return ({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Database Error"
                });
            }
            const user_id = otpResult[0].user_id;
            const newpassword = md5(requestData.password); // Ensure you hash passwords
            const updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE user_id=?";
            await con.query(updatePasswordQuery, [newpassword, user_id]);

            return ({
                code: responseCode.SUCCESS,
                keyword: "Password updated successfully."
            });
        } catch (error) {
            console.error("Database Error", error);
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async createPost(requestData) {
        try {
            const { user_id, headline, description, post_link, image } = requestData;
            const mealData = {
                user_id, headline, description, post_link
            };
            const insertMeal = "INSERT INTO tbl_post SET ?";
            const [result] = await con.query(insertMeal, [mealData]);
            console.log("Post Register With ID : ", result.insertId);
            let data = { image }
            let imageArray = data.image.split(',');
            for (let i = 0; i < imageArray.length; i++) {
                const image_name = imageArray[i];
                let imageData = {
                    post_id: result.insertId,
                    image: `${constant.imgUrl}${image_name}`
                };
                //console.log(imageData);
                const [imageResult] = await con.query("INSERT INTO tbl_post_image SET ?", [imageData]);
            }
            if (result.length <= 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "Post No Register...",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "Post Register......",
                data: result
            })
        } catch (error) {
            console.log("ERROR : ", error);
            return ({
                code: responseCode.NOT_REGISTER,
                keyword: "Post No Register...",
                data: []
            })
        }
    }
    async followFollowing(requestData) {
        try {
            const { user_id, following_id } = requestData;
            console.log("Following Request For : - ", following_id);
            const followQuery = "INSERT INTO tbl_follow SET ?";
            const [result] = await con.query(followQuery, [requestData]);
            if (!result.insertId) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Folllow"
                });
            }
            //following
            const [followingData] = await con.query("SELECT * FROM tbl_user WHERE user_id='" + requestData.user_id + "'")
            let following = followingData[0].following + 1;
            const [followingResult] = await con.query("update tbl_user set following='" + following + "' where user_id='" + requestData.user_id + "'");
            if (followingResult.affectedRows <= 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Folllow"
                });
            }
            //follower
            const [followerData] = await con.query("SELECT * FROM tbl_user WHERE user_id='" + requestData.following_id + "'")
            let follower = followerData[0].follower + 1;
            const [data] = await con.query("update tbl_user set follower='" + follower + "' where user_id='" + requestData.following_id + "'")
            if (data.affectedRows <= 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Folllow"
                });
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "You Are Followed this Profile",
                data: result
            })

        } catch (error) {
            console.log("ERROR : ", error);
            return ({
                code: responseCode.NOT_REGISTER,
                keyword: "Following Failed",
                data: []
            })
        }
    }
    async allPost(requestData) {
        try {
            const { user_id } = requestData;
            const [result] = await con.query(`SELECT GROUP_CONCAT(DISTINCT pi.image) as PostImage,
                p.headline,u.username,u.profile_image, 
                CONCAT(TIMESTAMPDIFF(MINUTE,p.create_at,CURRENT_TIMESTAMP),' min ago') AS TimeDiffence, 
                p.description,p.total_like,p.total_comment,p.total_repost,
                CASE WHEN EXISTS (select 1 FROM tbl_post_like where post_id=p.post_id and user_id=?)THEN 'Liked' ELSE 'Not Liked' end as LikeStatus 
                FROM tbl_post AS p JOIN tbl_post_image AS pi ON p.post_id=pi.post_id 
                JOIN tbl_user AS u ON u.user_id=p.user_id 
                WHERE p.user_id in (SELECT following_id FROM tbl_follow where user_id=?) GROUP BY pi.post_id`, [user_id, user_id]);
            if (!result || result.length === 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "No Data Found",
                    data: result
                });
            }
            const processedData = result.map(row => {
                const postImages = row.PostImage ? row.PostImage.split(',') : [];
                return {
                    postData: {
                        headline: row.headline,
                        username: row.username,
                        profile_image: row.profile_image,
                        TimeDiffence: row.TimeDiffence,
                        description: row.description,
                        total_like: row.total_like,
                        total_comment: row.total_comment,
                        total_repost: row.total_repost,
                        LikeStatus: row.LikeStatus
                    },
                    postImages: postImages
                };
            });
            return ({
                code: responseCode.SUCCESS,
                keyword: "Data Get Successfully",
                data: processedData
            })
        } catch (error) {
            console.log(error)
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Error Accour",
                data: processedData
            });
        }
    }
    async postLike(requestData) {
        try {
            const { post_id, user_id } = requestData;
            const [result] = await con.query("insert into tbl_post_like set ?", [requestData]);;
            if (!result.insertId) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Post Like"
                });
            }
            const [postData] = await con.query("SELECT * FROM tbl_post WHERE post_id='" + requestData.post_id + "'")
            let total_like = postData[0].total_like + 1;
            const [postResult] = await con.query("update tbl_post set total_like='" + total_like + "' where post_id='" + requestData.post_id + "'");
            if (postResult.affectedRows <= 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To post like"
                });
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "You Are liked post",
                data: result
            })

        } catch (error) {
            console.log("ERROR : ", error);
            return ({
                code: responseCode.NOT_REGISTER,
                keyword: "post like Failed",
                data: []
            })
        }
    }
    async postLikeListing(requestData) {
        try {
            const { post_id } = requestData;
            const [result] = await con.query(`SELECT u.name,u.username,u.profile_image FROM tbl_post_like AS p JOIN tbl_user AS u ON u.user_id=p.user_id WHERE p.post_id=?`, [requestData.post_id]);
            if (!result || result.length === 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "No Data Found",
                    data: result
                });
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "Data Get Successfully",
                data: result
            })
        } catch (error) {
            console.log(error)
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Error Accour",
                data: result
            });
        }
    }
    async addComment(requestData) {
        try {
            const { user_id, post_id, comment, parent_comment_id } = requestData;
            const [addCmt] = await con.query("INSERT INTO tbl_post_comment set ?",[requestData]);
            if (!addCmt.insertId) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Comment On Post"
                });
            }
            const [postData] = await con.query("SELECT * FROM tbl_post WHERE post_id='" + requestData.post_id + "'")
            let total_comment = postData[0].total_comment + 1;
            const [postResult] = await con.query("update tbl_post set total_comment='" + total_comment + "' where post_id='" + requestData.post_id + "'");
            if (postResult.affectedRows <= 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To comment"
                });
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "Commented On Post",
                data:addCmt
            })

        } catch (error) {
            console.log(error)
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Error Accour",
                data: []
            });
        }
    }
    async postCommentListing(requestData) {
        try {
            const { post_id } = requestData;
            const [result] = await con.query(`SELECT u.name,u.username,u.profile_image FROM tbl_post_comment AS p JOIN tbl_user AS u ON u.user_id=p.user_id WHERE p.post_id=?`, [requestData.post_id]);
            if (!result || result.length === 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "No Data Found",
                    data: result
                });
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "Data Get Successfully",
                data: result
            })
        } catch (error) {
            console.log(error)
            return ({
                code: responseCode.OPERATION_FAILED,
                keyword: "Error Accour",
                data: result
            });
        }
    }
    async postRepost(requestData) {
        try {
            const { post_id, user_id } = requestData;
            const [result] = await con.query("insert into tbl_repost set ?", [requestData]);;
            if (!result.insertId) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Post Like"
                });
            }
            const [postData] = await con.query("SELECT * FROM tbl_post WHERE post_id='" + requestData.post_id + "'")
            let total_repost = postData[0].total_repost + 1;
            const [postResult] = await con.query("update tbl_post set total_repost='" + total_repost + "' where post_id='" + requestData.post_id + "'");
            if (postResult.affectedRows <= 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To post like"
                });
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "You Are liked post",
                data: result
            })

        } catch (error) {
            console.log("ERROR : ", error);
            return ({
                code: responseCode.NOT_REGISTER,
                keyword: "post like Failed",
                data: []
            })
        }
    }
    async reportPost(requestData) {
        try {
            const { user_id,post_id,reason } = requestData;
            const insertMeal = "INSERT INTO tbl_report SET ?";
            const [result] = await con.query(insertMeal, [requestData]);
            console.log("Report on Post  Register With ID : ", result.insertId);
            if (result.length <= 0) {
                return ({
                    code: responseCode.NOT_REGISTER,
                    keyword: "can not report on post...",
                    data: []
                })
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "report on post......",
                data: result
            })
        } catch (error) {
            console.log("ERROR : ", error);
            return ({
                code: responseCode.NOT_REGISTER,
                keyword: "Databse Error...",
                data: []
            })
        }
    }
    async commentLike(requestData) {
        try {
            const { comment_id, user_id } = requestData;
            const [result] = await con.query("insert into tbl_comment_like set ?", [requestData]);;
            if (!result.insertId) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To comment Like"
                });
            }
            const [postData] = await con.query("SELECT * FROM tbl_post_comment WHERE id='" + requestData.comment_id + "'")
            let total_like = postData[0].total_like + 1;
            const [postResult] = await con.query("update tbl_post_comment set total_like='" + total_like + "' where id='" + requestData.comment_id + "'");
            if (postResult.affectedRows <= 0) {
                return ({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To comment like"
                });
            }
            return ({
                code: responseCode.SUCCESS,
                keyword: "You Are liked comment",
                data: result
            })

        } catch (error) {
            console.log("ERROR : ", error);
            return ({
                code: responseCode.NOT_REGISTER,
                keyword: "comment like Failed",
                data: []
            })
        }
    }
    async postDisLike(requestData) {
        try {
            const { post_id, user_id } = requestData;
            const [existingLike] = await con.query("SELECT * FROM tbl_post_like WHERE post_id = ? AND user_id = ?",[post_id, user_id]);
    
            if (existingLike.length > 0 && existingLike[0].is_delete === 0) {
                await con.query("UPDATE tbl_post_like SET is_delete = 1 WHERE post_id = ? AND user_id = ?",[post_id, user_id]);
                const [postData] = await con.query("SELECT * FROM tbl_post WHERE post_id='" + requestData.post_id + "'")
                let total_like = postData[0].total_like - 1;
                await con.query("UPDATE tbl_post SET total_like = ? WHERE post_id = ?",[total_like,post_id]);
                return {
                    code: responseCode.SUCCESS,
                    keyword: "You disliked the post",
                    total_like
                };
            } else {
                return {
                    code: responseCode.OPERATION_FAILED,
                    keyword: "You have not liked this post yet"
                };
            }
        } catch (error) {
            console.error("ERROR: ", error);
            return {
                code: responseCode.OPERATION_FAILED,
                keyword: "Post dislike failed",
                data: []
            };
        }
    }
    async postDeleteComment(requestData) {
        try {
            const { id,post_id, user_id } = requestData;
            const [existingLike] = await con.query("SELECT * FROM tbl_post_comment WHERE id=? and  post_id = ? AND user_id = ?",[id,post_id, user_id]);
    
            if (existingLike.length > 0 && existingLike[0].is_delete === 0) {
                await con.query("UPDATE tbl_post_comment SET is_delete = 1 WHERE id=? and  post_id = ? AND user_id = ?",[id,post_id, user_id]);
                const [postData] = await con.query("SELECT * FROM tbl_post WHERE post_id='" + requestData.post_id + "'")
                let total_comment = postData[0].total_comment - 1;
                await con.query("UPDATE tbl_post SET total_comment = ? WHERE post_id = ?",[total_comment,post_id]);
                return {
                    code: responseCode.SUCCESS,
                    keyword: "You delete commnet the post"
                };
            } else {
                return {
                    code: responseCode.OPERATION_FAILED,
                    keyword: "You have not delet comment this post yet"
                };
            }
        } catch (error) {
            console.error("ERROR: ", error);
            return {
                code: responseCode.OPERATION_FAILED,
                keyword: "Post comment delete failed",
                data: []
            };
        }
    }
    async commentDisLike(requestData) {
        try {
            const { comment_id, user_id } = requestData;
            const [existingLike] = await con.query("SELECT * FROM tbl_comment_like WHERE comment_id = ? AND user_id = ?",[comment_id, user_id]);
    
            if (existingLike.length > 0 && existingLike[0].is_delete === 0) {
                await con.query("UPDATE tbl_comment_like SET is_delete = 1 WHERE comment_id = ? AND user_id = ?",[comment_id, user_id]);
                const [postData] = await con.query("SELECT * FROM tbl_post_comment WHERE id='" + requestData.comment_id + "'")
                let total_like = postData[0].total_like - 1;
                await con.query("UPDATE tbl_post_comment SET total_like = ? WHERE id = ?",[total_like,comment_id]);
                return {
                    code: responseCode.SUCCESS,
                    keyword: "You disliked the comment",
                    total_like
                };
            } else {
                return {
                    code: responseCode.OPERATION_FAILED,
                    keyword: "You have not liked this commnet yet"
                };
            }
        } catch (error) {
            console.error("ERROR: ", error);
            return {
                code: responseCode.OPERATION_FAILED,
                keyword: "comment dislike failed",
                data: []
            };
        }
    }
    
}
module.exports = new UserModel();