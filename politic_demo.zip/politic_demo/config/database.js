const mysql = require("mysql2");
const credential = {
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'db_politic',
    dateStrings: true, // use dateStrings instead of dateString
    port: 3306
};

const database = mysql.createPool(credential).promise();
module.exports = database;
