const { profile } = require("console")
const { signUp, verifyOtp, editProfile, forgotPassword } = require("../module/V1/user/Models/userModel")

const checkValidationRules={
   /* signup:{
        name:"required",
        username:"required",
        email:"required|email",
        phone_no:"required|min:10|regex:/^[0-9]+$/",
        password:"required|min:8|",
        terms:"required",
    },*/
    verifyOtp:{
        otp:"required",
    },
    editProfile:{
        profile_image:"required",
        description:"required",
    },
    forgotPassword:{
        emailorphone:"required"
    },
}
module.exports=checkValidationRules
