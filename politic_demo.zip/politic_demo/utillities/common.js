const httpStatus=require("http-status-codes");
const con=require("../config/database");
const constant=require("../config/constant");
const responseCode=require("./responseErrorCode");
const { text }=require("express");

const cryptLib=require("cryptlib");
class common{
    response(res,message){
        //res.status(statusCode); statusCode=httpStatus.OK0
        res.json(this.encryptPlain(message));
        //res.json(message);
    }
    generateOtp(){
        return Math.floor(1000+ + Math.random()* 9000).toString();
    }
    generateToken(length=5){
        const possible="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let token="";
        for(let i=0;i<length;i++){
            token+=possible.charAt(Math.floor(Math.random()*possible.length));
        }
        return token;
    }
    getPaginationData(requestData) {
        let page = requestData<= 0 ? 1 : requestData;
        const limit = constant.itemPerPage;
        const start = (page - 1) * constant.itemPerPage;
        return [start,limit] ;
    }
    encryptPlain(data){
        console.log(data,'encrption');
        
        return cryptLib.encrypt(JSON.stringify(data),constant.encryptionKey,constant.encryptionIV);
    }
    decryptPlain(data){        
        if(data){
            return cryptLib.decrypt(data,constant.encryptionKey,constant.encryptionIV);
        }
        else{
            return ;
        }
    }
    SetToken(user_id) {
        let tokan = this.generateToken(40);
        let updatetokan = "update tbl_device set token=? where user_id=? AND is_delete='0'";

        con.query(updatetokan, [tokan, user_id], (error, result) => {
            if (error) {
                console.log("operation faild", error);
            }
            if (result <= 0) {
                console.log("token in not generated");
            }
            console.log("token generated");

        })
    }
    async getStepCount(user_id) {
        let [result] = await con.query("select * from tbl_user where user_id=? AND is_delete='0'", [user_id]);
        if (result.length <= 0) {
            return 0;
        }
        return result[0].is_step;
    }
} 
module.exports= new common;