const express =require('express');
const config=require("./config/config");
const appRouting=require("./module/app_routing");
const bodyParser=require("body-parser");
const appDoc=require("./module/V1/ApiDocument/route");
let app=express();

app.use("/api-doc",appDoc);
const urlencoderParser=bodyParser.urlencoded({
    extended:true
});
app.use(express.text());

app.use('/',require('./middeleware/validators').extractHeaderLanguage);
app.use('/',require('./middeleware/validators').validateApikey);
app.use('/',require('./middeleware/validators').validateHeaderToken);
appRouting.v1(app);
try {
    app.listen(config.serverListen,()=>{
        console.log("Server State: Running Port : "+config.serverListen);
        
    });
} catch (error) {
    console.log("Connection Failed....");
    
}