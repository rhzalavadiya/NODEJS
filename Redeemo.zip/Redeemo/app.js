const express=require("express");
const config=require("./config/config");
const appRouting=require("./modules/appRouting");
const bodyParser=require("body-parser");
let app=express();
const urlencoderParser=bodyParser.urlencoded({
    extended:true
});
app.use(bodyParser.json());

app.use('/',require('./middeleware/validators').extractHeaderLanguage);
app.use('/',require('./middeleware/validators').validateApikey);
app.use('/',require('./middeleware/validators').validateHeaderToken);
appRouting.v1(app);
try {
    app.listen(config.serverListen,()=>{
        console.log("Server State: Running Port : "+config.serverListen);
        
    });
} catch (error) {
    console.log("Connection Failed....");
    
}
