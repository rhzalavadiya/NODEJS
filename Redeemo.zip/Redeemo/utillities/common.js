const httpStatus=require("http-status-codes");
const con=require("../config/database");
const constant=require("../config/constant");
const responseCode=require("./responseErrorCode");
const { text }=require("express");
class common{
    response(res,message){
        //res.status(statusCode); statusCode=httpStatus.OK0
        res.json(message);
    }
    generateOtp(){
        return Math.floor(1000+ + Math.random()* 9000).toString();
    }
    generateToken(length=5){
        const possible="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        let token="";
        for(let i=0;i<length;i++){
            token+=possible.charAt(Math.floor(Math.random()*possible.length));
        }
        return token;
    }
    getPaginationData(requestData) {
        let page = requestData<= 0 ? 1 : requestData;
        const limit = constant.itemPerPage;
        const start = (page - 1) * constant.itemPerPage;
        return [start,limit] ;
    }
} 
module.exports= new common;