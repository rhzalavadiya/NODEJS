const { profile } = require("console");
const { email } = require("../language/arbic");
const { signUp, verifyOtp, editProfile, forgotPassword, interestData, setPassword } = require("./V1/user/Models/userModel");
const { rateReview } = require("./V1/merchant/Models/merchant_model");

const checkValidationRules={
    // login:{
    //     email:'required|email',
    //     password:'required|min:4',
    // },
    signUp:{
        email:"required|email",
        phone_no:"required|string|min:10|regex:/^[0-9]+$/",
        password:"required|min:8|",

    },
    verifyOtp:{
        //phone_no:"required|string|min:10|regex:/^[0-9]+$/",
        otp:"required",
    },
    editProfile:{
        first_name:"required",
        last_name:"required",
        address:"required",
        dob:"required", 
        gender:"required",
        profile_pic:"required",
    },
    interestData:{
        interest_id:"required",
        user_id:"required",
    },
    forgotPassword:{
        email:"required|email",
    },
    setPassword:{
        password:"required",
    },
    setPassword:{
        OldPassword:"required",
        Newpassword:"required",
    },
    rateReview:{
        rate:"required",
        review:"required",
    },
}
module.exports = checkValidationRules