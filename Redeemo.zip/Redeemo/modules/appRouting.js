class routing{
    v1(app){
        const user=require("./V1/user/route/route");
        user(app);
        const merchant=require("./V1/merchant/routes/routes");
        merchant(app);
    }
}
module.exports=new routing();