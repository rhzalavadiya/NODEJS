const con = require("../../../../config/database");
const responseCode = require("../../../../utillities/responseErrorCode");
const common = require("../../../../utillities/common");
const constant = require("../../../../config/constant");
const { log, error, Console } = require("console");
const { verify } = require("crypto");
const e = require("express");
const { createGzip } = require("zlib");
const message = require("../../../../language/english");
const { read } = require("fs");
const { console } = require("inspector");
class MerchantModel {
    constructor() { }
    async Home(requestData, callback) {
        try {
            const pagination = common.getPaginationData(requestData.page);
            // console.log(pagination)
            //user Detail
            const user_id = requestData.user_id;
            let FinalResult = {};
            const userDetail = "SELECT profile_pic,CONCAT(first_name,' ',last_name) AS Name,address,latitude,longitude FROM tbl_user WHERE user_id=? AND is_delete='0'";
            const [userResult] = await con.query(userDetail, [user_id]);
            if (!userResult || userResult.length === 0) {
                FinalResult.UserDetail = []
            }
            else {
                FinalResult.UserDetail = userResult;
            }
            //Category Detail
            const categoryDetail = "SELECT name,image FROM tbl_category Limit ?,?";
            const [categoryResult] = await con.query(categoryDetail, [pagination[0], pagination[1]]);
            if (!categoryResult || categoryResult.length === 0) {
                FinalResult.CategoryDetail = []
            }
            else {
                FinalResult.CategoryDetail = categoryResult;
            }
            //Featured Detail
            const featuredDetail = "SELECT m.name,m.logo,m.image,m.avg_rate,m.address,CONCAT(ROUND((6371 * ACOS( COS( RADIANS(?) )  * COS( RADIANS( m.latitude) ) * COS( RADIANS( m.longitude ) - RADIANS(?) )  + SIN( RADIANS(?) )  * SIN( RADIANS( m.latitude ) ) ) ),1) ,' ','KM') as Distance, CASE WHEN EXISTS(SELECT 1 FROM tbl_favourite_merchant as f WHERE f.merchant_id=m.id and f.user_id=?)THEN 'Liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_merchant as m ORDER BY avg_rate DESC Limit ?,?";
            const [featuredResult] = await con.query(featuredDetail, [userResult[0].latitude, userResult[0].longitude, userResult[0].latitude, user_id, pagination[0], pagination[1]]);
            if (!featuredResult || featuredResult.length === 0) {
                FinalResult.FeaturedDetail = []
            }
            else {
                FinalResult.FeaturedDetail = featuredResult;
            }
            //Trending Detail
            const trendingDetail = "SELECT m.name,m.logo,m.image,m.avg_rate,m.address,CONCAT(ROUND((6371 * ACOS( COS( RADIANS(?) )  * COS( RADIANS( m.latitude) ) * COS( RADIANS( m.longitude ) - RADIANS(?) )  + SIN( RADIANS(?) )  * SIN( RADIANS( m.latitude ) ) ) ),1) ,' ','KM') as Distance, CASE WHEN EXISTS(SELECT 1 FROM tbl_favourite_merchant as f WHERE f.merchant_id=m.id and f.user_id=?)THEN 'Liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_merchant as m ORDER BY avg_rate DESC Limit ?,?";
            const [trendingResult] = await con.query(trendingDetail, [userResult[0].latitude, userResult[0].longitude, userResult[0].latitude, user_id, pagination[0], pagination[1]]);
            if (!trendingResult || trendingResult.length === 0) {
                FinalResult.TrendingDetail = []
            }
            else {
                FinalResult.TrendingDetail = trendingResult;
            }
            //Near by Detail
            const nearbyDetail = "SELECT m.name,m.logo,m.image,m.avg_rate,m.address,CONCAT(ROUND((6371 * ACOS( COS( RADIANS(?) )  * COS( RADIANS( m.latitude) ) * COS( RADIANS( m.longitude ) - RADIANS(?) )  + SIN( RADIANS(?) )  * SIN( RADIANS( m.latitude ) ) ) ),1) ,' ','KM') as Distance, CASE WHEN EXISTS(SELECT 1 FROM tbl_favourite_merchant as f WHERE f.merchant_id=m.id and f.user_id=?)THEN 'Liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_merchant as m INNER JOIN tbl_category as c on c.category_id=m.category_id HAVING Distance<10 ORDER BY m.avg_rate DESC Limit ?,?";
            const [nearbyResult] = await con.query(nearbyDetail, [userResult[0].latitude, userResult[0].longitude, userResult[0].latitude, user_id, pagination[0], pagination[1]]);
            if (!trendingResult || trendingResult.length === 0) {
                FinalResult.NearyByDetail = []
            }
            else {
                FinalResult.NearByDetail = nearbyResult;
            }
            if (!FinalResult || FinalResult.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Data Get Successfully",
                data: FinalResult
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async nearBy(requestData, callback) {
        try {
            const pagination = common.getPaginationData(requestData.page);
            const nearbyDetail = "SELECT m.name,m.logo,m.image,m.avg_rate,m.address,CONCAT((SELECT ROUND((6371 * ACOS(COS(RADIANS(u.latitude)) * COS(RADIANS(m.latitude)) * COS(RADIANS(m.longitude) - RADIANS(u.longitude)) + SIN(RADIANS(u.latitude)) * SIN(RADIANS(m.latitude)))), 1) FROM tbl_user AS u WHERE u.user_id = ?),' Km') AS Distance, CASE WHEN EXISTS(SELECT 1 FROM tbl_favourite_merchant as f WHERE f.merchant_id=m.id and f.user_id=?)THEN 'Liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_merchant as m INNER JOIN tbl_category as c on c.category_id=m.category_id HAVING Distance<10 ORDER BY m.avg_rate DESC Limit ?,?";
            const [nearbyResult] = await con.query(nearbyDetail, [requestData.user_id, requestData.user_id, pagination[0], pagination[1]]);
            if (!nearbyResult || nearbyResult.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Data Get Successfully",
                data: nearbyResult
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async featured(requestData, callback) {
        try {
            const pagination = common.getPaginationData(requestData.page);
            //Featured Detail
            //console.log(requestData.user_id, pagination[0], pagination[1]);
            const featuredDetail = "SELECT m.name,m.logo,m.image,m.avg_rate,m.address,CONCAT((SELECT ROUND((6371 * ACOS(COS(RADIANS(u.latitude)) * COS(RADIANS(m.latitude)) * COS(RADIANS(m.longitude) - RADIANS(u.longitude)) + SIN(RADIANS(u.latitude)) * SIN(RADIANS(m.latitude)))), 1) FROM tbl_user AS u WHERE u.user_id = ?),' Km') AS Distance, CASE WHEN EXISTS(SELECT 1 FROM tbl_favourite_merchant as f WHERE f.merchant_id=m.id and f.user_id=?)THEN 'Liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_merchant as m ORDER BY avg_rate DESC Limit ?,?";
            const [featuredResult] = await con.query(featuredDetail, [requestData.user_id, requestData.user_id, pagination[0], pagination[1]]);
            if (!featuredResult || featuredResult.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Data Get Successfully",
                data: featuredResult
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async trending(requestData, callback) {
        try {
            const pagination = common.getPaginationData(requestData.page);
            const trendingDetail = "SELECT m.name,m.logo,m.image,m.avg_rate,m.address,CONCAT((SELECT ROUND((6371 * ACOS(COS(RADIANS(u.latitude)) * COS(RADIANS(m.latitude)) * COS(RADIANS(m.longitude) - RADIANS(u.longitude)) + SIN(RADIANS(u.latitude)) * SIN(RADIANS(m.latitude)))), 1) FROM tbl_user AS u WHERE u.user_id = ?),' Km') AS Distance, CASE WHEN EXISTS(SELECT 1 FROM tbl_favourite_merchant as f WHERE f.merchant_id=m.id and f.user_id=?)THEN 'Liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_merchant as m ORDER BY avg_rate DESC Limit ?,?";
            const [trendingResult] = await con.query(trendingDetail, [requestData.user_id, requestData.user_id, pagination[0], pagination[1]]);
            if (!trendingResult || trendingResult.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Data Get Successfully",
                data: trendingResult
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async category(requestData, callback) {
        try {
            const pagination = common.getPaginationData(requestData.page);
            const categoryDetail = "SELECT name,image FROM tbl_category Limit ?,?";
            const [categoryResult] = await con.query(categoryDetail, [pagination[0], pagination[1]]);
            if (!categoryResult || categoryResult.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Data Get Successfully",
                data: categoryResult
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async search(requestData, callback) {
        try {
            let search = requestData.search;
            search = search.trim();
            if (search != undefined) {
                let searchMerchant = "select * from tbl_merchant where name like ?"
                let [result] = await con.query(searchMerchant, [`%${search}%`]);
                if (result.length > 0) {
                    return callback({
                        code: responseCode.SUCESS,
                        keyword: "Data Get Successfully...",
                        data: result
                    })
                }
                let searchCategory = "select * from tbl_category where name like ?"
                let [category] = await con.query(searchCategory, [`%${search}%`]);
                if (category.length > 0) {
                    return callback({
                        code: responseCode.SUCESS,
                        keyword: "Data Get Successfully...",
                        data: category
                    })
                }
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data Found",
                    data: []
                })
            }
            return callback({
                code: responseCode.NO_DATA_FOUND,
                keyword: " Data Found",
                data: []
            })

        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async filter(requestData, callback) {
        try {
            let data = {
                sort: requestData.sort,
                category: requestData.category,
                distance: requestData.distance,
                amenities: requestData.amenities
            }
            let nearby = `SELECT DISTINCT c.name,m.image ,m.logo,m.name,m.avg_rate,m.address,CONCAT((SELECT ROUND((6371 * ACOS(COS(RADIANS(u.latitude)) * COS(RADIANS(m.latitude)) * COS(RADIANS(m.longitude) - RADIANS(u.longitude)) + SIN(RADIANS(u.latitude)) * SIN(RADIANS(m.latitude)))), 1) FROM tbl_user AS u WHERE u.user_id = ?),' Km away') AS Distance  FROM tbl_merchant as m  INNER JOIN tbl_category as c on c.category_id=m.category_id  INNER JOIN tbl_amenities_merchant AS ma ON ma.merchant_id = m.id INNER JOIN tbl_amenities AS a ON a.id = ma.amenities_id where c.name=? and a.name =? HAVING distance<? ORDER by ? DESC`;
            if (data.category == "all" || data.amenities == "all") {
                if (data.category != "all") {
                    data.category = requestData.category;
                } else {
                    const categoryName = "SELECT name FROM tbl_category";
                    const [category] = await con.query(categoryName);
                    data.category = category.map(row => row.name);
                }

                if (data.amenities != "all") {
                    data.amenities = requestData.amenities;
                } else {
                    const amenitiesName = "SELECT name FROM tbl_amenities";
                    const [amenities] = await con.query(amenitiesName);
                    data.amenities = amenities.map(row => row.name);
                }
                nearby = `SELECT DISTINCT c.name,m.image ,m.logo,m.name,m.avg_rate,m.address,CONCAT((SELECT ROUND((6371 * ACOS(COS(RADIANS(u.latitude)) * COS(RADIANS(m.latitude)) * COS(RADIANS(m.longitude) - RADIANS(u.longitude)) + SIN(RADIANS(u.latitude)) * SIN(RADIANS(m.latitude)))), 1) FROM tbl_user AS u WHERE u.user_id = ?),' Km away') AS Distance  FROM tbl_merchant as m  INNER JOIN tbl_category as c on c.category_id=m.category_id  INNER JOIN tbl_amenities_merchant AS ma ON ma.merchant_id = m.id INNER JOIN tbl_amenities AS a ON a.id = ma.amenities_id WHERE c.name IN (?) and a.name IN (?) HAVING distance <? ORDER BY ? DESC`;
                console.log(data.amenities);
            }
            let [demo] = await con.query(nearby, [requestData.user_id, data.category, data.amenities, data.distance, data.sort]);
            if (demo.length < 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data Found",
                    data: []
                })
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Data get Successfully ",
                data: demo
            })

        } catch (Error) {
            console.log(Error);

            return callback({
                code: responseCode.NO_DATA_FOUND,
                keyword: "no data found",
                data: []
            })
        }
    }
    async merchantDetail(requestData, callback) {
        try {
            let FinalResult = {};
            const type = requestData.type;
            const merchantDetail = "SELECT m.name,m.logo,m.image,m.address,m.latitude, m.longitude,m.avg_rate,CONCAT((SELECT ROUND((6371 * ACOS(COS(RADIANS(u.latitude)) * COS(RADIANS(m.latitude)) * COS(RADIANS(m.longitude) - RADIANS(u.longitude)) + SIN(RADIANS(u.latitude)) * SIN(RADIANS(m.latitude)))), 1) FROM tbl_user AS u WHERE u.user_id = ?),' Km away') AS Distance,CASE WHEN EXISTS(SELECT 1 FROM tbl_favourite_merchant as f WHERE f.merchant_id=m.id and f.user_id=?)THEN 'liked' ELSE 'Not Liked' END as LikeStatus FROM tbl_merchant as m  where id=?";
            const [merchantResult] = await con.query(merchantDetail, [requestData.user_id, requestData.user_id, requestData.id]);
            if (!merchantResult || merchantResult.length === 0) {
                FinalResult.MerchantDetail = []
            }
            else {
                FinalResult.MerchantDetail = merchantResult;
            }
            if (type === "voucher") {
                const voucherDetail = "select v.discount,v.title,v.image,v.description,v.expire_date,CASE WHEN EXISTS (select 1 FROM tbl_voucher_redeemed where voucher_id=v.id and user_id=?)THEN 'Redeemed' ELSE 'Redeem' end as RedeemStatus,CASE WHEN EXISTS (select 1 FROM tbl_favourite_voucher where voucher_id=v.id and user_id=?)THEN 'Lked' ELSE 'Not Liked' end as LikeStatus from tbl_voucher as v WHERE v.expire_date >= CURRENT_TIMESTAMP AND v.merchant_id=?";
                const [voucherResult] = await con.query(voucherDetail, [requestData.user_id, requestData.user_id, requestData.id]);
                if (!voucherResult || voucherResult.length === 0) {
                    FinalResult.VoucherDetail = []
                }
                else {
                    FinalResult.VoucherDetail = voucherResult;
                }
            }
            if (type === "about") {
                const about = "SELECT m.description, CONCAT('[', GROUP_CONCAT(DISTINCT a.name SEPARATOR ', '), ']') AS Amenities, CONCAT('[', GROUP_CONCAT(DISTINCT mi.image SEPARATOR ', '), ']') AS Gallery FROM tbl_merchant AS m INNER JOIN tbl_amenities_merchant AS am ON am.merchant_id = m.id INNER JOIN tbl_amenities AS a ON a.id = am.amenities_id INNER JOIN tbl_merchant_image AS mi ON mi.merchant_id = m.id WHERE m.id = ?";
                const [aboutResult] = await con.query(about, [requestData.id]);
                if (!aboutResult || aboutResult.length === 0) {
                    FinalResult.AboutDetail = []
                }
                else {
                    FinalResult.AboutDetail = aboutResult;
                }
            }
            if (type === "branch") {
                const branch = "SELECT b.name,b.logo,b.address,b.opening_time,b.close_time,b.avg_rate FROM tbl_branch as b INNER JOIN tbl_merchant as m ON m.id=b.merchant_id WHERE m.id=?";
                const [branchResult] = await con.query(branch, [requestData.id]);
                if (!branchResult || branchResult.length === 0) {
                    FinalResult.BranchDetail = []
                }
                else {
                    FinalResult.BranchDetail = branchResult;
                }
            }
            if (type === "rate") {
                const rate = "SELECT CONCAT(u.first_name,' ',u.last_name)AS Name, u.profile_pic,r.rate,r.review,(SELECT review_count FROM tbl_merchant where id=r.merchant_id) AS ReviewCount FROM tbl_rating AS r INNER JOIN tbl_user as u ON r.user_id=u.user_id WHERE r.merchant_id=?";
                const [rateResult] = await con.query(rate, [requestData.id]);
                if (!rateResult || rateResult.length === 0) {
                    FinalResult.RateDetail = []
                }
                else {
                    FinalResult.RateDetail = rateResult;
                }
            }
            if (type === "contact") {
                const contactDetail = "SELECT m.address,m.latitude, m.longitude,m.phone_no,m.email FROM tbl_merchant as m  where id=?";
                const [contactResult] = await con.query(contactDetail, [requestData.user_id, requestData.user_id, requestData.id]);
                if (!contactResult || contactResult.length === 0) {
                    FinalResult.ContactDetail = []
                }
                else {
                    FinalResult.ContactDetail = contactResult;
                }
            }
            if (!FinalResult || FinalResult.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Data Get Successfully",
                data: FinalResult
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async voucherDetail(requestData, callback) {
        try {
            const voucher = "select v.image,v.discount,v.title,v.description,v.expire_date,v.voucher_code,v.merchant_code , CASE WHEN EXISTS (select 1 FROM tbl_voucher_redeemed where voucher_id=v.id and user_id=?)THEN 'Redeemed' ELSE 'Redeem' end as RedeemStatus,CASE WHEN EXISTS (select 1 FROM tbl_favourite_voucher where voucher_id=v.id and user_id=?)THEN 'Liked' ELSE 'Not Liked' end as LikeStatus from tbl_voucher as v WHERE v.expire_date >= CURRENT_TIMESTAMP AND v.id=?";
            const [voucherResult] = await con.query(voucher, [requestData.user_id, requestData.user_id, requestData.id]);
            if (!voucherResult || voucherResult.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Data Get Successfully",
                data: voucherResult
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async rateReview(requestData, callback) {
        try {
            const {
                user_id, merchant_id, rate, review
            } = requestData;

            const insertQuery = "INSERT INTO tbl_rating SET ?";
            const [Result] = await con.query(insertQuery, [requestData]);
            if (!Result.insertId) {
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Rating"
                });
            }
            console.log("Rate Id :", Result.insertId);
            return callback({
                code: responseCode.SUCESS,
                keyword: "Rate Added Successfully",
                //data: Result
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async favorite(requestData, callback) {
        try {
            let FinalResult = {};
            const type = requestData.type;
            if (type === "voucher") {
                const voucherDetail = "select v.discount,v.title,v.image,v.description,v.expire_date,CASE WHEN EXISTS (select 1 FROM tbl_voucher_redeemed where voucher_id=v.id and user_id=?)THEN 'Redeemed' ELSE 'Redeem' end as RedeemStatus from tbl_voucher as v INNER JOIN tbl_favourite_voucher as fv on fv.voucher_id=v.id WHERE v.expire_date >= CURRENT_TIMESTAMP AND fv.user_id=?";
                const [voucherResult] = await con.query(voucherDetail, [requestData.user_id, requestData.user_id]);
                if (!voucherResult || voucherResult.length === 0) {
                    FinalResult.VoucherDetail = []
                }
                else {
                    FinalResult.VoucherDetail = voucherResult;
                }
            }
            if (type === "merchant") {
                const merchantDetail = "SELECT m.name,m.logo,m.image,m.address,m.avg_rate,CONCAT((SELECT ROUND((6371 * ACOS(COS(RADIANS(u.latitude)) * COS(RADIANS(m.latitude)) * COS(RADIANS(m.longitude) - RADIANS(u.longitude)) + SIN(RADIANS(u.latitude)) * SIN(RADIANS(m.latitude)))), 1) FROM tbl_user AS u WHERE u.user_id = ?),' Km away') AS Distance FROM tbl_merchant as m INNER JOIN tbl_favourite_merchant as fm on fm.merchant_id=m.id where fm.user_id=?";
                const [merchantResult] = await con.query(merchantDetail, [requestData.user_id, requestData.user_id]);
                if (!merchantResult || merchantResult.length === 0) {
                    FinalResult.MerchantDetail = []
                }
                else {
                    FinalResult.MerchantDetail = merchantResult;
                }
            }
            if (!FinalResult || FinalResult.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Data Get Successfully",
                data: FinalResult
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async notification(requestData, callback) {
        try {
            const notification = "SELECT notification,create_at FROM tbl_notification WHERE user_id=?";
            const [Result] = await con.query(notification, [requestData.user_id]);
            if (!Result || Result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Data Get Successfully",
                data: Result
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }

}
module.exports = new MerchantModel();