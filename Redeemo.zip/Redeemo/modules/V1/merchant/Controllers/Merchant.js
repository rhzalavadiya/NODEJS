const responseCode = require("../../../../utillities/responseErrorCode");
const constant = require("../../../../config/constant");
const common = require("../../../../utillities/common");
const merchantModel = require("../Models/merchant_model");
const middleware = require("../../../../middeleware/validators");
const validationRules = require("../../../validation_rules");
const { request } = require("express");
const message = require("../../../../language/arbic");
const { t } = require('localizify');
const { required } = require("../../../../language/english");
class Merchant {
    constructor() { }
    Home(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.Home(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    nearBy(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.nearBy(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    featured(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.featured(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    trending(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.trending(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    category(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.category(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    search(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.search(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    filter(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.filter(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    merchantDetail(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.merchantDetail(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    voucherDetail(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.voucherDetail(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    favorite(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.favorite(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    notification(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.notification(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    rateReview(req, res) {
        const requestData = req.body;
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = validationRules.rateReview
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            merchantModel.rateReview(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
}
module.exports = new Merchant;