const Merchant=require("../Controllers/Merchant");
const customeRoute=(app)=>{
    app.get("/v1/merchant/home",Merchant.Home);
    app.get("/v1/merchant/nearby",Merchant.nearBy);
    app.get("/v1/merchant/trending",Merchant.trending);
    app.get("/v1/merchant/featured",Merchant.featured);
    app.get("/v1/merchant/category",Merchant.category);
    app.get("/v1/merchant/search",Merchant.search);
    app.get("/v1/merchant/filter",Merchant.filter);
    app.get("/v1/merchant/merchantdetail",Merchant.merchantDetail);
    app.get("/v1/merchant/voucherdetail",Merchant.voucherDetail);
    app.get("/v1/merchant/favorite",Merchant.favorite);
    app.get("/v1/merchant/notification",Merchant.notification);
    app.post("/v1/merchant/rating",Merchant.rateReview);
    
}
module.exports=customeRoute;