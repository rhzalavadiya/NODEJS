const con = require("../../../../config/database");
const responseCode = require("../../../../utillities/responseErrorCode");
const common = require("../../../../utillities/common");
const constant = require("../../../../config/constant");
const md5 = require("md5");
const { log, error, Console } = require("console");
const { verify } = require("crypto");
const e = require("express");
const { createGzip } = require("zlib");
const message = require("../../../../language/english");
const { read } = require("fs");
class UserModel {
    constructor() { }
    // signup
    async signUp(requestData, callback) {
        try {
            const {
                email, phone_no, password, login_type, social_id, is_step,
                device_type, os_version, app_version
            } = requestData;

            console.log("Signup Request:", requestData);

            let insertQuery = "";
            let userData = {};
            let sendOtpFlag = true; // Flag to control OTP sending

            // **Social Login Handling (Google or Facebook)**
            if (login_type === 'G' || login_type === 'F') {
                userData = { login_type, social_id, is_step };
                insertQuery = "INSERT INTO tbl_user SET ?";
                sendOtpFlag = false; // Do not send OTP for social login

            } else {
                // **Traditional Signup - Validate Required Fields**
                if (!email || !password || !phone_no) {
                    return callback({
                        code: responseCode.REQUEST_ERROR,
                        keyword: "Missing required fields"
                    });
                }

                // **Check if Email or Phone Number Already Exists**
                const checkUserQuery = "SELECT user_id FROM tbl_user WHERE email = ? OR phone_no = ? AND is_delete='0'";
                const [existingUser] = await con.query(checkUserQuery, [email, phone_no]);

                if (existingUser.length > 0) {
                    return callback({
                        code: responseCode.REQUEST_ERROR,
                        keyword: "Email or Phone Number already exists"
                    });
                }

                // **Prepare Data for Insertion**
                userData = { email, phone_no, password: md5(password) };
                insertQuery = "INSERT INTO tbl_user SET ?";
            }

            // **Insert User into Database**
            const [userResult] = await con.query(insertQuery, userData);
            if (!userResult.insertId) {
                return callback({
                    code: responseCode.OPERATION_FAILED,
                    keyword: "Failed To Insert User Data"
                });
            }

            console.log("User Registered With ID:", userResult.insertId);
            const user_id = userResult.insertId;

            // **Insert Device Data**
            const deviceData = {
                user_id,
                device_type,
                device_token: `Device${common.generateToken(4)}`,
                os_version,
                app_version
            };
            const insertDeviceQuery = "INSERT INTO tbl_device SET ?";
            await con.query(insertDeviceQuery, deviceData);

            console.log("Device Data Inserted For User ID:", user_id);

            // **Send OTP only for traditional signup**
            if (sendOtpFlag) {
                await this.sendOtp(user_id, requestData);
                return callback({
                    code: responseCode.SUCCESS,
                    keyword: "OTP Sent Successfully. Please verify to complete signup.",
                    data: { user_id }
                });
            } else {
                return callback({
                    code: responseCode.SUCCESS,
                    keyword: "Signup successful via social login.",
                    data: { user_id }
                });
            }
        } catch (error) {
            console.error("Signup Error:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Signup Process Failed..."
            });
        }
    }

    async sendOtp(user_id, requestData) {
        try {
            const otp = common.generateOtp();
            const email = requestData.email
            const phone_no = requestData.phone_no;
            /*if (!email || !phone_no) {
                throw new Error("No valid contact value provided.");
            }*/
            const otpData = { user_id, otp, email, phone_no };
            const insertOtp = "INSERT INTO tbl_otp SET ?";
            await con.query(insertOtp, otpData);
            console.log("OTP Inserted With User_id:", user_id);
            return {
                code: responseCode.SUCESS,
                keyword: "OTP sent successfully",
                data: []
            };
        } catch (error) {
            console.error("OTP Sending Error:", error);
            return {
                code: responseCode.OPERATION_FAILED,
                keyword: "Failed to send OTP"
            };
        }
    }
    async verifyOtp(requestData, callback) {
        try {
            const { email, otp } = requestData;
            if (!otp) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing Value..."
                });
            }
            console.log("Verify OTP With : ", email);
            const otpQuery = "SELECT * FROM tbl_otp WHERE email=? AND otp=? AND is_verify='0' AND is_delete='0'";
            const [result] = await con.query(otpQuery, [email, otp]);
            console.log(result[0]);
            const user_id = result[0].user_id;
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Invalid OTP...."
                });
            }
            const updateOtpQuery = "UPDATE tbl_otp SET is_verify='1' WHERE email=? AND otp=? AND is_delete='0'";
            await con.query(updateOtpQuery, [email, otp]);

            const step = "SELECT is_step FROM tbl_user WHERE user_id=? AND is_delete='0'";
            const [stepcnt] = await con.query(step, [user_id]);
            const { is_step } = stepcnt[0];
            if (is_step !== '3') {
                const updateQuery = "UPDATE tbl_user SET is_step='2' WHERE user_id=? AND is_delete='0'";
                await con.query(updateQuery, [user_id]);
            }
            const token = "USER" + common.generateToken(4);

            // Update device information in tbl_device
            const updateDeviceQuery = "UPDATE tbl_device SET token = ?WHERE user_id = ? AND is_delete='0'";
            await con.query(updateDeviceQuery, [token, user_id]);

            console.log("Device token updated for user_id:", user_id);
            return callback({
                code: responseCode.SUCESS,
                keyword: "OTP Verified Successfully"
            });
        } catch (error) {
            console.error("OTP Sending Error:", error);
            return {
                code: responseCode.OPERATION_FAILED,
                keyword: "Failed to verify OTP"
            };
        }
    }
    async editProfile(requestData, callback) {
        try {
            const {
                first_name, last_name, address, dob, gender, profile_pic, latitude, longitude, is_step, phone_no
            } = requestData;
            const userId = requestData.user_id;
            console.log("Edit Profile For Request : ", userId);

            const checkQuery = "SELECT is_step FROM tbl_user WHERE user_id=? AND is_delete='0'";
            const [status] = await con.query(checkQuery, [userId]);

            if (!status || status.length === 0) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "User Not Found..."
                });
            }

            if (status[0].is_step < '2') {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Please Complete OTP Verification..."
                });
            }

            // Construct updateData dynamically
            const updateData = {
                first_name, last_name, address, dob, gender, profile_pic, latitude, longitude, is_step
            };

            // Conditionally add phone_number if it exists in requestData
            if (phone_no !== undefined) {
                updateData.phone_no = phone_no;
            }

            const updateQuery = "UPDATE tbl_user SET ? WHERE user_id=? AND is_delete='0'";
            await con.query(updateQuery, [updateData, userId]);
            console.log("User updated with user_id:", userId);

            return callback({
                code: responseCode.SUCESS,
                keyword: "User Profile Updated Successfully."
            });

        } catch (error) {
            console.error("Update Profile Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Failed To Update Profile..."
            });
        }
    }

    async interestData(requestData, callback) {
        try {
            const { interest_id } = requestData;

            const Interested = interest_id.split(',');
            for (const interest of Interested) {
                const interestData = { user_id: requestData.user_id, interest_id: interest.trim() };
                const insertInstQuery = "INSERT INTO tbl_interest_user SET ?";
                await con.query(insertInstQuery, interestData);
            }
            console.log(" data add with ID:", requestData.user_id);
            return callback({
                code: responseCode.SUCESS,
                keyword: "Data Added Successfully."
            });

        } catch (error) {
            console.error("Failed To Add Interest", error);
            return {
                code: responseCode.OPERATION_FAILED,
                keyword: "Failed To Add Interest..."
            };
        }
    }
    async login(requestData, callback) {
        try {
            // Destructure fields from requestData
            const { email, password, login_type, social_id } = requestData;
            console.log("Login request for user:", email || social_id);

            let userQuery, userParams;

            if (login_type === "S") {
                // Validate required fields for normal login
                if (!email || !password) {
                    return callback({
                        code: responseCode.INVALID_REQUEST,
                        keyword: "Email and password are required",
                    });
                }

                // Hash the password and prepare SQL query
                const hashedPassword = md5(password);
                userQuery = "SELECT * FROM tbl_user WHERE email = ? AND password = ? AND is_delete='0'";
                userParams = [email, hashedPassword];

            } else if (login_type === "G" || login_type === "F") {
                // Validate required fields for social login
                if (!social_id) {
                    return callback({
                        code: responseCode.INVALID_REQUEST,
                        keyword: "Social ID is required for social login",
                    });
                }

                // Prepare SQL query for social login
                userQuery = "SELECT * FROM tbl_user WHERE social_id = ? AND login_type = ? AND is_delete='0'";
                userParams = [social_id, login_type];

            } else {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Invalid login type",
                });
            }

            // Execute user query
            const [userResult] = await con.query(userQuery, userParams);

            if (!userResult || userResult.length === 0) {
                return callback({
                    code: responseCode.NOT_REGISTER,
                    keyword: "Invalid credentials or user not registered",
                });
            }

            const { user_id, is_step } = userResult[0];

            // Check if OTP verification is required
            if (is_step !== '3') {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Please complete OTP verification before logging in",
                });
            }

            // Generate tokens
            const token = "USER" + common.generateToken(4);
            const device_token = "DEVICE" + common.generateToken(4);

            // Update device information in tbl_device
            const updateDeviceQuery = "UPDATE tbl_device SET token = ?, device_token = ? WHERE user_id = ?";
            await con.query(updateDeviceQuery, [token, device_token, user_id]);

            console.log("Device token updated for user_id:", user_id);
            return callback({
                code: responseCode.SUCESS,
                keyword: "Login Successful",
                data: { user_id, token, device_token },
            });

        } catch (error) {
            console.error("Error during login:", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred",
            });
        }
    }

    async forgotPassword(requestData, callback) {
        try {
            if (!requestData.email) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing Value...."
                });
            }
            console.log("Forgot Password Request user  : ", requestData.email || requestData.phone_no);
            const frogotPwd = "SELECT user_id FROM tbl_user where email=? AND is_delete='0'";
            const [result] = await con.query(frogotPwd, [requestData.email]);
            console.log(result[0]);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Email Not Found..."
                });
            }
            const { user_id } = result[0];
            //console.log(user_id);
            await this.sendOtp(user_id, requestData);
            return callback({
                code: responseCode.SUCESS,
                keyword: "OTP Sent Successfully. Please verify to complete Process",
            });
        } catch (error) {
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred"
            });
        }
    }
    async setPassword(requestData, callback) {
        const { otp, email, password } = requestData;
        try {
            if (!requestData) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing Value...."
                });
            }
            const checkOTPQuery = "SELECT user_id FROM tbl_otp WHERE email=? AND otp=? AND is_verify=1 AND is_delete='0'";
            console.log("Executing OTP verification query:", checkOTPQuery);
            const [otpResult] = await con.query(checkOTPQuery, [requestData.email, requestData.otp]);
            console.log("OTP Query Result:", otpResult);
            if (!otpResult || otpResult.length === 0) {
                return callback({
                    code: responseCode.INVALID_REQUEST,
                    keyword: "Database Error"
                });
            }

            //console.log("OTP Verified, proceeding to update password.");

            const user_id = otpResult[0].user_id;
            const newpassword = md5(requestData.password); // Ensure you hash passwords
            const updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE user_id=?";

            // Execute password update query
            await con.query(updatePasswordQuery, [newpassword, user_id]);

            return callback({
                code: responseCode.SUCCESS,
                keyword: "Password updated successfully."
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async changePassword(requestData, callback) {
        try {
            const { OldPassword, NewPassword } = requestData;
            const data = {
                OldPassword: md5(OldPassword),
                NewPassword: md5(NewPassword)
            };
            if (!requestData) {
                return callback({
                    code: responseCode.REQUEST_ERROR,
                    keyword: "Missing Value....."
                });
            }
            console.log("Change Password Request:", requestData.user_id);
            const checkPasswordQuery = "SELECT * FROM tbl_user WHERE user_id=? AND is_delete='0'";
            const [result] = await con.query(checkPasswordQuery, [requestData.user_id]);

            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NOT_APPROVE,
                    keyword: "User not found."
                });
            }
            const user = result[0];
            if (user.login_type !== "S") {
                console.log("User logged in with social account");
                return callback({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Login with social ID"
                });
            }

            if (data.OldPassword !== user.password) {
                return callback({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Old password is incorrect!"
                });
            }

            if (data.NewPassword === user.password) {
                return callback({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Old password and new password cannot be the same!"
                });
            }

            const updatePasswordQuery = "UPDATE tbl_user SET password=? WHERE user_id=?";
            const [updateResult] = await con.query(updatePasswordQuery, [data.NewPassword, requestData.user_id]);

            if (updateResult.affectedRows === 0) {
                console.log("Password update failed");
                return callback({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Password update failed"
                });
            }

            console.log("Password changed successfully for user:", requestData.user_id);
            return callback({
                code: responseCode.SUCESS,
                keyword: "Password changed successfully"
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async Logout(requestData, callback) {
        try {
            console.log("Logout Request for : ", requestData.user_id);
            const query = "SELECT u.user_id,u.email,d.token,d.device_token FROM tbl_user as u INNER JOIN tbl_device as d on u.user_id=d.user_id WHERE u.user_id=? AND u.is_delete='0'";
            const [result] = await con.query(query, [requestData.user_id]);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            console.log("User Logout With ID:", result[0].user_id);
            //const user_id = result[0].user_id;
            const updatetoken = "UPDATE tbl_device SET token=NULL, device_token=NULL WHERE user_id=?";
            const [status] = await con.query(updatetoken, [requestData.user_id]);
            //console.log(status);

            if (status.affectedRows === 0) {
                console.log("Token update failed");
                return callback({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Token update failed"
                });
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Logout Successfully",
                //data: result
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async deleteAccount(requestData, callback) {
        try {
            console.log("Logout Request for : ", requestData.user_id);
            const query = "update tbl_user set is_delete='1'WHERE user_id=?";
            const [result] = await con.query(query, [requestData.user_id]);
            if (!result || result.length === 0) {
                return callback({
                    code: responseCode.NO_DATA_FOUND,
                    keyword: "No Data found."
                });
            }
            //console.log("User Delete Account With ID:", result[0].user_id);
            //const user_id = result[0].user_id;
            const updatetoken = "UPDATE tbl_device SET token=NULL, device_token=NULL WHERE user_id=?";
            const [status] = await con.query(updatetoken, [requestData.user_id]);
            //console.log(status);

            if (status.affectedRows === 0) {
                console.log("Token update failed");
                return callback({
                    code: responseCode.NOT_APPROVE,
                    keyword: "Token update failed"
                });
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Logout Successfully",
                //data: result
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
    async editInterest(requestData, callback) {
        try {
            let data = {
                interest: requestData.interest
            }
            let interestArray = data.interest.split(',');
            if (interestArray.length > 0) {
                con.query("delete from tbl_interest_user where user_id='" + requestData.user_id + "'");
            }
            for (let i = 0; i < interestArray.length; i++) {

                let fetchid = "SELECT interest_id FROM tbl_interest WHERE interested IN (?) AND is_delete='0'";
                let [insert] = await con.query(fetchid, [interestArray[i]]);
                let interstdata = {
                    user_id: requestData.user_id,
                    interest_id: insert[0].interest_id
                };
                await con.query("INSERT INTO tbl_interest_user SET ?", [interstdata]);
                console.log(insert[0]);
            }
            return callback({
                code: responseCode.SUCESS,
                keyword: "Interest update successfully"
            });
        } catch (error) {
            console.error("Database Error", error);
            return callback({
                code: responseCode.OPERATION_FAILED,
                keyword: "Database error occurred."
            });
        }
    }
}
module.exports = new UserModel();