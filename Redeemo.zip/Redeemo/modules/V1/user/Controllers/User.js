const responseCode = require("../../../../utillities/responseErrorCode");
const constant = require("../../../../config/constant");
const common = require("../../../../utillities/common");
const userModel = require("../Models/userModel");
const middleware = require("../../../../middeleware/validators");
const validationRules = require("../../../validation_rules");
const { request } = require("express");
const message = require("../../../../language/arbic");
const { t } = require('localizify');
const { required } = require("../../../../language/english");
class User {
    constructor() { }
    signUp(req, res) {
        const requestData = req.body;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = validationRules.signUp
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            /*userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });*/
            // console.log(requestData);

            userModel.signUp(requestData, function (_responseData) {
                //console.log(message);
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    verifyOtp(req, res) {
        const requestData = req.body;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = validationRules.verifyOtp
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            /*userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });*/
            //console.log(requestData);

            userModel.verifyOtp(requestData, function (_responseData) {
                // console.log(message);
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    editProfile(req, res) {
        
        const requestData = req.body;
        console.log("Edi Profile : ",req.user_id);
        requestData.user_id=req.user_id
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = validationRules.editProfile
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            /*userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });*/
            // console.log(requestData);

            userModel.editProfile(requestData, function (_responseData) {
                // console.log(message);
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    interestData(req, res) {
        const requestData = req.body;
        requestData.user_id=req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = validationRules.interestData
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            /*userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });*/
            //console.log(requestData);

            userModel.interestData(requestData, function (_responseData) {
                //console.log(message);
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    login(req, res) {
        const requestData = req.body;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
       //const rules = validationRules.login
       const rules="";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            /*userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });*/
            //console.log(requestData);

            userModel.login(requestData, function (_responseData) {
                //console.log(message);
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    forgotPassword(req, res) {
        const requestData = req.body;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = validationRules.forgotPassword
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            /*userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });*/
            //console.log(requestData);

            userModel.forgotPassword(requestData, function (_responseData) {
                //console.log(message);
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    setPassword(req, res) {
        const requestData = req.body;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = validationRules.setPassword
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            /*userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });*/
            //console.log(requestData);

            userModel.setPassword(requestData, function (_responseData) {
                //console.log(message);
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    changePassword(req, res) {
        const requestData = req.body;
        requestData.user_id=req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = validationRules.changePassword
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            /*userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });*/
            //console.log(requestData);

            userModel.changePassword(requestData, function (_responseData) {
                //console.log(message);
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    Logout(req, res) {
        const requestData = req.body;
        requestData.user_id=req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            /*userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });*/
            //console.log(requestData);

            userModel.Logout(requestData, function (_responseData) {
                //console.log(message);
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    deleteAccount(req, res) {
        const requestData = req.body;
        requestData.user_id=req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {
            'passwords': t('rest_leywords_password')
        }
        const rules = "";
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            /*userModel.login(requestData, (_responseData) => {
                common.response(res, _responseData);
            });*/
            //console.log(requestData);

            userModel.deleteAccount(requestData, function (_responseData) {
                //console.log(message);
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
    editInterest(req, res) {
        const requestData = req.body;
       // console.log("hello");
        
        requestData.user_id = req.user_id;
        let message = {
            required: req.language.required
        }
        let keyword = {}
        const rules = ""
        const valid = middleware.checkValidationRules(req, res, requestData, rules, message, keyword)
        if (valid) {
            userModel.editInterest(requestData, function (_responseData) {
                middleware.sendResponse(req, res, _responseData);
            });
        }
    }
}
module.exports = new User;