const User=require("../Controllers/User");
const customeRoute=(app)=>{
     app.post("/v1/user/signup",User.signUp);
     app.post("/v1/user/verifyotp",User.verifyOtp);
     app.post("/v1/user/editprofile",User.editProfile);
     app.post("/v1/user/login",User.login);
     app.post("/v1/user/interestdata",User.interestData);
     app.post("/v1/user/forgotpassword",User.forgotPassword);
     app.post("/v1/user/setpassword",User.setPassword);
     app.post("/v1/user/changepassword",User.changePassword);
     app.post("/v1/user/logout/",User.Logout);
     app.post("/v1/user/deleteaccount/",User.deleteAccount);
     app.post("/v1/user/editinterest",User.editInterest);
}
module.exports=customeRoute;