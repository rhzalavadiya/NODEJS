function Book(title, author, price, quantity) {
    this.title = title;
    this.author = author;
    this.price = price;
    this.quantity = quantity;
    this.maxQuantity=quantity;
}
// Adding A book Detail 
function addBook() {
    let title = document.getElementById('title').value;
    let author = document.getElementById('author').value;
    let price = document.getElementById('price').value;
    let quantity = document.getElementById('quantity').value;
     // validation
    if (!title || !author || !price || !quantity) {
        alert("Please fill out all fields.");
        return;
    }
    if(price<=0){
        alert("Plese Enter Valid Price...");
        return
    }
    if(quantity<=0){
        alert("Please Enter Valide Quantity");
        return
    }
    let data = JSON.parse(localStorage.getItem("book")) || [];
    let book = {
        title,
        author,
        price: parseFloat(price),
        quantity: parseInt(quantity),
        maxQuantity: parseInt(quantity) 
    };
    data.push(book);
    
    localStorage.setItem("book", JSON.stringify(data));
    alert("Book added successfully!");
    clearData();
}
// Clear Data
function clearData(){
    document.getElementById('title').value = "";
    document.getElementById('author').value = "";
    document.getElementById('price').value = "";
    document.getElementById('quantity').value = "";
}
// Display all The Book From Local Storage
function displayBook() {
    let data = JSON.parse(localStorage.getItem("book")) || []; 
    console.log(data);

    let bookList = document.getElementById('booklist');
    bookList.innerHTML = ''; 

    for (let bookData of data) {
        bookList.innerHTML += `
        <div class="book-card">
            <h3>${bookData.title}</h3>
            <p>by ${bookData.author}</p>
            <p>Price: ₹${bookData.price}</p>
            <p>Available : ${bookData.quantity}</p>
            <button onclick="borrowBook('${bookData.title}')">Borrow</button>
            <button onclick="returnBook('${bookData.title}')">Return</button>
        </div>`;
    }
}
// Borrow Book And Decrese the Quantity
function borrowBook(title) {
    let data = JSON.parse(localStorage.getItem("book")) || [];
    
    for (let book of data) {
        if (book.title === title) {
            if (book.quantity > 0) {
                book.quantity--; // Decrement
                alert(`You Borrowed: '${book.title}'`);
            } else {
                alert(`Sorry, '${book.title}' is out of stock!`);
            }
            break;
        }
    }
    localStorage.setItem("book", JSON.stringify(data)); 
    displayBook(); // Refresh UI
}
// Reruen the Book Ana Increse the Quatity
function returnBook(title) {
    let data = JSON.parse(localStorage.getItem("book")) || [];
    for (let book of data) {
        if (book.title === title) {
            if (book.quantity < book.maxQuantity) {
                book.quantity++; // Increment
                alert(`You Returned: '${book.title}'`);
            } else {
                alert(`Can not return '${book.title}'because the book not Borrow`);
            }
            break;
        }
    }
    localStorage.setItem("book", JSON.stringify(data)); 
    displayBook(); 
}